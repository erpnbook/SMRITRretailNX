---
Document ID: "DEV-052"
Title: "Setup Overrides"
Owner: "Development Team"
Audience: "Developer"
Module: "Core"
Version: "1.0.0"
Status: "Active"
Primary Document: "Yes"
Depends On: ""
Related Modules: ""
Last Updated: "2026-06-25"
Last Reviewed: "2026-06-25"
AI Generated: "Yes"
Reviewed By: "Jawahar R. Mallah"
---

Overrides extend the base compose.yaml with additional services or modify existing behavior. Include them in your compose command using multiple -f flags.

```bash
docker compose -f compose.yaml -f overrides/compose.mariadb.yaml -f overrides/compose.redis.yaml config > compose.custom.yaml
```

| Overrider                      | Purpose                                                                                                                                                             | Additional Info                                                                                                                               |
| ------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------- |
| **Database**                   |                                                                                                                                                                     |                                                                                                                                               |
| compose.mariadb.yaml           | Adds MariaDB database service                                                                                                                                       | set `DB_PASSWORD` or default Password will be used                                                                                            |
| compose.mariadb-secrets.yaml   | Adds MariaDB with password from a secret file instead of environment variable                                                                                       | Set `DB_PASSWORD_SECRETS_FILE` to the path of your secret file                                                                                |
| compose.mariadb-shared.yaml    | Makes MariaDB available on a shared network (mariadb-network) for other services                                                                                    | set `DB_PASSWORD`                                                                                                                             |
| compose.postgres.yaml          | Uses PostgreSQL instead of MariaDB as the database                                                                                                                  | set `DB_PASSWORD`                                                                                                                             |
| **Proxy**                      |                                                                                                                                                                     |                                                                                                                                               |
| compose.noproxy.yaml           | Exposes the application directly on port `:8080` without a reverse proxy                                                                                            |                                                                                                                                               |
| compose.proxy.yaml             | Uses Traefik as HTTP reverse proxy on port `:80`                                                                                                                    | You can change the published port by setting `HTTP_PUBLISH_PORT`                                                                              |
| compose.https.yaml             | Uses Traefik as HTTPS reverse proxy on Port `:443` with automatic HTTP-to-HTTPS redirect                                                                            | `SITES_RULE` and `LETSENCRYPT_EMAIL` must be set. `HTTP_PUBLISH_PORT` and `HTTPS_PUBLISH_PORT` can be set.                                    |
| compose.traefik.yaml           | Runs a standalone Traefik proxy with dashboard (HTTP) on a shared `traefik-public` network                                                                          | Use for multi-stack setups. Requires `TRAEFIK_DOMAIN` and `HASHED_PASSWORD`.                                                                  |
| compose.traefik-ssl.yaml       | Adds HTTPS and Let's Encrypt for the Traefik dashboard                                                                                                              | Use with `compose.traefik.yaml`. Requires `EMAIL` and `TRAEFIK_DOMAIN`. Publishes `HTTPS_PUBLISH_PORT`.                                       |
| compose.nginxproxy.yaml        | Uses nginx-proxy as HTTP reverse proxy on port `:80`                                                                                                                | Set `NGINX_PROXY_HOSTS`. Use with `compose.nginxproxy-ssl.yaml` for HTTPS. You can change the published port by setting `HTTP_PUBLISH_PORT`   |
| compose.nginxproxy-ssl.yaml    | Adds acme-companion for HTTPS on port `:443` with automatic certificates                                                                                            | Requires `compose.nginxproxy.yaml`. Set `NGINX_PROXY_HOSTS` and `LETSENCRYPT_EMAIL`. `HTTP_PUBLISH_PORT` and `HTTPS_PUBLISH_PORT` can be set. |
| **Redis**                      |                                                                                                                                                                     |                                                                                                                                               |
| compose.redis.yaml             | Adds Redis service for caching and background job queuing                                                                                                           |                                                                                                                                               |
| **Services**                   |                                                                                                                                                                     |                                                                                                                                               |
| compose.migrator.yaml          | Runs a dedicated migration container performing `bench --site all migrate` on all sites at every start                                                              | Control migration intent with `MIGRATE_SITES` - defaults to true                                                                              |
| **TBD**                        | **The following overrides are available but lack documentation. If you use them and understand their purpose, please consider contributing to this documentation.** |                                                                                                                                               |
| compose.backup-cron.yaml       |                                                                                                                                                                     |                                                                                                                                               |
| compose.custom-domain-ssl.yaml |                                                                                                                                                                     |                                                                                                                                               |
| compose.custom-domain.yaml     |                                                                                                                                                                     |                                                                                                                                               |
| compose.multi-bench-ssl.yaml   |                                                                                                                                                                     |                                                                                                                                               |
| compose.multi-bench.yaml       |                                                                                                                                                                     |                                                                                                                                               |

## Revision History

| Version | Date | Author | Summary of Changes |
| --- | --- | --- | --- |
| 1.0.0 | 2026-06-25 | Jawahar R. Mallah | Reorganized & standardized |


---

## Author Profile

- **Author**: Jawahar R. Mallah
- **Designation**: Founder & Chief Architect
- **Organization**: AITDL – AI Technology & Development Lab
- **Professional Experience**: 20+ Years of Experience in Software Development, Retail Technology, Distribution Systems, POS Solutions, ERP Implementations, Business Process Automation, and Enterprise Application Design.

> "Always decision-ready."  
> — Jawahar R. Mallah  
> Founder & Chief Architect, AITDL