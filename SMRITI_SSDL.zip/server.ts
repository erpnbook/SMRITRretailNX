import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";

// Standard Types
import { Product, POSProfile, Shift, FieldInfo, Formula, PSVParty, Bill, Quotation, SalesOrder, SalesItemLine } from "./src/types.js";

const app = express();
const PORT = 3000;

app.use(express.json());

// In-Memory Databases
let products: Product[] = [
  { id: "p1", code: "TSH-COT-M", name: "Classic Cotton T-Shirt", price: 799, stock: 45, category: "Apparel", barcode: "SMR-B101", color: "Navy", size: "M" },
  { id: "p2", code: "TSH-COT-L", name: "Classic Cotton T-Shirt", price: 799, stock: 32, category: "Apparel", barcode: "SMR-B102", color: "Navy", size: "L" },
  { id: "p3", code: "TSH-COT-S", name: "Classic Cotton T-Shirt", price: 799, stock: 12, category: "Apparel", barcode: "SMR-B103", color: "Navy", size: "S" },
  { id: "p4", code: "DEN-SLM-32", name: "Premium Slim Fit Denim", price: 1899, stock: 24, category: "Apparel", barcode: "SMR-B201", color: "Indigo", size: "32" },
  { id: "p5", code: "DEN-SLM-34", name: "Premium Slim Fit Denim", price: 1899, stock: 18, category: "Apparel", barcode: "SMR-B202", color: "Indigo", size: "34" },
  { id: "p6", code: "SNE-LTH-09", name: "Retro Leather Sneakers", price: 3499, stock: 8, category: "Footwear", barcode: "SMR-B301", color: "White", size: "9" },
  { id: "p7", code: "SNE-LTH-10", name: "Retro Leather Sneakers", price: 3499, stock: 15, category: "Footwear", barcode: "SMR-B302", color: "White", size: "10" },
  { id: "p8", code: "SMR-HD-L", name: "SMRITI Heritage Hoodie", price: 2499, stock: 20, category: "Apparel", barcode: "SMR-B401", color: "Charcoal", size: "L" },
  { id: "p9", code: "SMR-HD-XL", name: "SMRITI Heritage Hoodie", price: 2499, stock: 14, category: "Apparel", barcode: "SMR-B402", color: "Charcoal", size: "XL" },
  { id: "p10", code: "CAP-LOG-O", name: "SMRITI Monogram Cap", price: 499, stock: 60, category: "Accessories", barcode: "SMR-B501", color: "Black", size: "OS" }
];

let profiles: POSProfile[] = [
  { id: "prof-1", name: "Main Terminal A", cashier: "John Cashier", warehouse: "Main Outlet Retail WH", isLocked: false, isArchived: false },
  { id: "prof-2", name: "Express Terminal B", cashier: "Emma Cashier", warehouse: "Express Outlet WH", isLocked: false, isArchived: false },
  { id: "prof-3", name: "Admin Override Profile", cashier: "Manager Dev", warehouse: "Main Outlet Retail WH", isLocked: true, isArchived: false }
];

let shifts: Shift[] = [
  { id: "shift-101", profileId: "prof-1", openedAt: "2026-07-08T09:00:00Z", closedAt: null, openingBalance: 5000, closingBalance: null, salesCount: 4, salesValue: 9895, status: "Open" }
];

let bills: Bill[] = [];
let holdBills: Bill[] = [];

let quotations: Quotation[] = [
  {
    id: "q-1",
    quotationNo: "QTN-2026-0001",
    date: "2026-07-08T10:00:00.000Z",
    customerName: "Acme Corporates",
    items: [
      {
        productId: "p1",
        code: "TSH-COT-M",
        name: "Classic Cotton T-Shirt",
        color: "Navy",
        size: "M",
        quantity: 10,
        price: 799,
        taxRate: 18,
        taxAmount: 1438.2,
        totalAmount: 9428.2
      }
    ],
    taxTotal: 1438.2,
    grandTotal: 9428.2,
    status: "Submitted"
  }
];

let salesOrders: SalesOrder[] = [
  {
    id: "so-1",
    orderNo: "SO-2026-0001",
    date: "2026-07-08T11:30:00.000Z",
    customerName: "Acme Corporates",
    items: [
      {
        productId: "p1",
        code: "TSH-COT-M",
        name: "Classic Cotton T-Shirt",
        color: "Navy",
        size: "M",
        quantity: 10,
        price: 799,
        taxRate: 18,
        taxAmount: 1438.2,
        totalAmount: 9428.2
      }
    ],
    taxTotal: 1438.2,
    grandTotal: 9428.2,
    status: "Confirmed",
    sourceQuotationId: "q-1"
  }
];

let auditLogs: any[] = [
  { id: "audit-1", timestamp: "2026-07-08T09:05:00Z", user: "John Cashier", action: "Shift Opened", details: "Profile Terminal A. Opening Balance: 5000 INR", before: "-", after: "Open" },
  { id: "audit-2", timestamp: "2026-07-08T11:20:00Z", user: "Manager Dev", action: "POS Profile Cloned", details: "Cloned Main Terminal A → New Terminal C", before: "Profiles count: 3", after: "Profiles count: 4" }
];

let fields: FieldInfo[] = [
  { id: "f1", fieldName: "item_code", label: "Item Code", fieldType: "Data", docType: "Item", isStable: true, description: "Unique identifier code for the item.", sampleValue: "TSH-COT-M" },
  { id: "f2", fieldName: "item_name", label: "Item Name", fieldType: "Data", docType: "Item", isStable: true, description: "Display name of the item.", sampleValue: "Classic Cotton T-Shirt" },
  { id: "f3", fieldName: "standard_rate", label: "Standard Rate", fieldType: "Currency", docType: "Item", isStable: true, description: "Default retail selling price.", sampleValue: "799" },
  { id: "f4", fieldName: "hsn_code", label: "HSN Code", fieldType: "Data", docType: "Item", isStable: true, description: "Harmonized System of Nomenclature code for India GST.", sampleValue: "61091000" },
  { id: "f5", fieldName: "brand", label: "Brand", fieldType: "Link", docType: "Item", isStable: true, description: "Brand associated with the item.", sampleValue: "SMRITI" },
  { id: "f6", fieldName: "warehouse", label: "Default Warehouse", fieldType: "Link", docType: "POS Profile", isStable: true, description: "Default storage warehouse.", sampleValue: "Main Outlet Retail WH" },
  { id: "f7", fieldName: "cashier", label: "Cashier User", fieldType: "Link", docType: "POS Profile", isStable: true, description: "Assigned front-end cashier user.", sampleValue: "John Cashier" },
  { id: "f8", fieldName: "batch_no", label: "Batch Number", fieldType: "Link", docType: "Stock Ledger Entry", isStable: false, description: "Internal stock tracking batch reference.", sampleValue: "BATCH-26G7" }
];

let formulas: Formula[] = [
  {
    id: "for-1",
    name: "Weeks of Cover (WOC)",
    category: "Inventory Intelligence",
    expression: "Current Stock / Average Weekly Sales Velocity",
    meaning: "How many weeks the current on-hand stock will last under current demand velocity.",
    workedExample: "On-Hand Stock = 45 units. Weekly Velocity = 9 units. WOC = 45 / 9 = 5.0 Weeks.",
    dataSources: ["Stock Ledger Entry (current balance)", "Sales Invoice Item (90-day historic velocity)"],
    interpretation: {
      critical: "WOC < 2.0 Weeks (Risk of stockout & lost sales)",
      monitor: "WOC between 2.0 and 4.0 Weeks (Reorder trigger range)",
      healthy: "WOC > 4.0 Weeks (Sufficient buffer inventory)"
    },
    recommendedAction: "If Critical, generate an expedited purchase request or execute an active transfer from slow-moving nodes.",
    value: "5.0 Weeks"
  },
  {
    id: "for-2",
    name: "Sales Velocity",
    category: "Inventory Intelligence",
    expression: "Total Quantity Sold / Active Sales Days in Period",
    meaning: "Average rate of stock units sold per single active operational day.",
    workedExample: "180 units sold in 30 active days = 180 / 30 = 6.0 units/day.",
    dataSources: ["Sales Invoice Item (quantities)", "POS Shift logs (active dates)"],
    interpretation: {
      critical: "Velocity = 0 (Dead stock alert, dead capital)",
      monitor: "Velocity < 1.0 unit/day (Slow velocity range)",
      healthy: "Velocity >= 1.0 unit/day (Active velocity range)"
    },
    recommendedAction: "If Dead stock, propose a localized Markdown Scheme or bundler campaign to recover locked capital.",
    value: "6.0 units/day"
  },
  {
    id: "for-3",
    name: "Outlet Health Score",
    category: "Store Analytics",
    expression: "0.4 * Accuracy + 0.3 * SellThrough + 0.3 * ShiftCompliance",
    meaning: "Composite score evaluating the operational compliance and stock safety of a retail node.",
    workedExample: "Stock Accuracy = 95%, Sell-Through = 70%, Shift Compliance = 100%. Score = (0.4*95) + (0.3*70) + (0.3*100) = 38 + 21 + 30 = 89%.",
    dataSources: ["Stock Reconciliation (accuracy)", "Sales vs Stock ratios", "Shift Manager logs"],
    interpretation: {
      critical: "Score < 60% (Severe operational gaps, immediate audit required)",
      monitor: "Score between 60% and 80% (Compliance check indicated)",
      healthy: "Score > 80% (Excellent operational discipline)"
    },
    recommendedAction: "Conduct physical inventory count and lock cashier terminals immediately to audit cash reconciliations.",
    value: "89%"
  },
  {
    id: "for-4",
    name: "Sell-Through Rate",
    category: "PSV / Channel Intelligence",
    expression: "(Total Sales / Total Sourced Inventory) * 100",
    meaning: "Percentage of received stock that has successfully sold to end consumers within a given cycle.",
    workedExample: "Sourced = 1000 units. Sold = 700 units. Rate = (700 / 1000) * 100 = 70%.",
    dataSources: ["Purchase Receipt (sourced)", "Sales Invoice Item (sold)"],
    interpretation: {
      critical: "Rate < 35% (Stagnant launch, high promotional liability)",
      monitor: "Rate between 35% and 60% (Normal sales cycle progression)",
      healthy: "Rate > 60% (High performance, healthy category demand)"
    },
    recommendedAction: "Optimize replenishment frequencies or trigger automated bulk reorders for winning variants.",
    value: "70%"
  }
];

let psvParties: PSVParty[] = [
  {
    id: "pty-1", name: "Distributor North (Manoj Traders)", location: "New Delhi, DL", stockCount: 1450, sellThrough: 78, weeksOfCover: 3.2, capitalLocked: 1158000, status: "Healthy",
    history: [
      { date: "07-02", sales: 110, stock: 1520 },
      { date: "07-03", sales: 140, stock: 1490 },
      { date: "07-04", sales: 125, stock: 1475 },
      { date: "07-05", sales: 135, stock: 1450 }
    ]
  },
  {
    id: "pty-2", name: "Kora Apparels Wholesale", location: "Mumbai, MH", stockCount: 820, sellThrough: 54, weeksOfCover: 1.8, capitalLocked: 1560000, status: "Monitor",
    history: [
      { date: "07-02", sales: 45, stock: 890 },
      { date: "07-03", sales: 50, stock: 860 },
      { date: "07-04", sales: 62, stock: 835 },
      { date: "07-05", sales: 48, stock: 820 }
    ]
  },
  {
    id: "pty-3", name: "Southern Logistics & Retail", location: "Chennai, TN", stockCount: 2200, sellThrough: 28, weeksOfCover: 8.5, capitalLocked: 4200000, status: "Critical",
    history: [
      { date: "07-02", sales: 20, stock: 2250 },
      { date: "07-03", sales: 18, stock: 2240 },
      { date: "07-04", sales: 22, stock: 2215 },
      { date: "07-05", sales: 15, stock: 2200 }
    ]
  }
];

// Lazy Gemini API Initializer (Optional / Fail Safe)
let aiClient: any = null;
function getAIClient() {
  if (!aiClient) {
    const key = process.env.GEMINI_API_KEY;
    if (key) {
      try {
        aiClient = new GoogleGenAI({ apiKey: key });
      } catch (e) {
        console.error("Failed to initialize GoogleGenAI:", e);
      }
    }
  }
  return aiClient;
}

// ---------------- API Routes ----------------

// 1. POS Products
app.get("/api/pos/products", (req, res) => {
  res.json(products);
});

app.post("/api/pos/products", (req, res) => {
  const { name, code, price, stock, category, barcode, color, size, mrp, gstPercentage, styleCode } = req.body;
  
  if (!name || !code || !barcode) {
    return res.status(400).json({ error: "Item Name, SKU Code, and Barcode are required." });
  }

  // Check duplicate code or barcode
  if (products.some(p => p.code === code)) {
    return res.status(400).json({ error: `SKU Code ${code} is already registered in SMRITI.` });
  }
  if (products.some(p => p.barcode === barcode)) {
    return res.status(400).json({ error: `Barcode ${barcode} is already registered in SMRITI.` });
  }

  const pPrice = parseFloat(price) || 0;
  const pStock = parseInt(stock) || 0;
  const pGst = parseFloat(gstPercentage) || 18;
  const pMrp = parseFloat(mrp) || pPrice;

  const newProduct: Product = {
    id: `p-${Date.now()}`,
    name,
    code,
    price: pPrice,
    stock: pStock,
    category: category || "General",
    barcode,
    color: color || undefined,
    size: size || undefined,
    mrp: pMrp,
    gstPercentage: pGst,
    styleCode: styleCode || code
  };

  products.push(newProduct);

  // Audit Log Entry
  auditLogs.push({
    id: `audit-${Date.now()}`,
    timestamp: new Date().toISOString(),
    user: "Manager Dev",
    action: "Item Created",
    details: `Quick Created SKU: ${code} - ${name} (Price: ${pPrice} INR, MRP: ${pMrp} INR)`,
    before: "-",
    after: `Stock: ${pStock}`
  });

  res.json(newProduct);
});

app.put("/api/pos/products/:id", (req, res) => {
  const { id } = req.params;
  const { name, price, stock, category, barcode, color, size, mrp, gstPercentage, styleCode } = req.body;

  const index = products.findIndex(p => p.id === id);
  if (index === -1) {
    return res.status(404).json({ error: "Item not found" });
  }

  const beforeState = { ...products[index] };

  if (name !== undefined) products[index].name = name;
  if (price !== undefined) products[index].price = parseFloat(price) || 0;
  if (stock !== undefined) products[index].stock = parseInt(stock) || 0;
  if (category !== undefined) products[index].category = category;
  if (barcode !== undefined) products[index].barcode = barcode;
  if (color !== undefined) products[index].color = color || undefined;
  if (size !== undefined) products[index].size = size || undefined;
  if (mrp !== undefined) products[index].mrp = parseFloat(mrp) || undefined;
  if (gstPercentage !== undefined) products[index].gstPercentage = parseFloat(gstPercentage) || undefined;
  if (styleCode !== undefined) products[index].styleCode = styleCode || undefined;

  // Audit Log Entry
  auditLogs.push({
    id: `audit-${Date.now()}`,
    timestamp: new Date().toISOString(),
    user: "Manager Dev",
    action: "Item Updated",
    details: `Updated Master SKU: ${products[index].code} (${products[index].name})`,
    before: JSON.stringify({ price: beforeState.price, stock: beforeState.stock, mrp: beforeState.mrp }),
    after: JSON.stringify({ price: products[index].price, stock: products[index].stock, mrp: products[index].mrp })
  });

  res.json(products[index]);
});

app.delete("/api/pos/products/:id", (req, res) => {
  const { id } = req.params;
  const index = products.findIndex(p => p.id === id);
  if (index === -1) {
    return res.status(404).json({ error: "Item not found" });
  }

  const deletedProduct = products[index];
  products.splice(index, 1);

  // Audit Log Entry
  auditLogs.push({
    id: `audit-${Date.now()}`,
    timestamp: new Date().toISOString(),
    user: "Manager Dev",
    action: "Item Deleted",
    details: `Permanently deleted SKU: ${deletedProduct.code} - ${deletedProduct.name}`,
    before: `Stock was: ${deletedProduct.stock}`,
    after: "Deleted"
  });

  res.json({ success: true, message: `SKU ${deletedProduct.code} deleted successfully.` });
});

// 2. POS Profiles
app.get("/api/pos/profiles", (req, res) => {
  res.json(profiles.filter(p => !p.isArchived));
});

app.post("/api/pos/profiles", (req, res) => {
  const { name, cashier, warehouse } = req.body;
  if (!name || !cashier || !warehouse) {
    return res.status(400).json({ error: "Missing required fields" });
  }
  const newProfile: POSProfile = {
    id: `prof-${Date.now()}`,
    name,
    cashier,
    warehouse,
    isLocked: false,
    isArchived: false
  };
  profiles.push(newProfile);

  // Rule 10 Audit Log
  auditLogs.push({
    id: `audit-${Date.now()}`,
    timestamp: new Date().toISOString(),
    user: "Manager Dev",
    action: "Profile Created",
    details: `Created new POS profile: ${name}`,
    before: `Total: ${profiles.length - 1}`,
    after: `Total: ${profiles.length}`
  });

  res.json(newProfile);
});

app.post("/api/pos/profiles/clone/:id", (req, res) => {
  const { id } = req.params;
  const original = profiles.find(p => p.id === id);
  if (!original) return res.status(404).json({ error: "Profile not found" });

  const cloned: POSProfile = {
    ...original,
    id: `prof-${Date.now()}`,
    name: `${original.name} (Copy)`,
    isLocked: false
  };
  profiles.push(cloned);

  // Rule 10 Audit Log
  auditLogs.push({
    id: `audit-${Date.now()}`,
    timestamp: new Date().toISOString(),
    user: "Manager Dev",
    action: "POS Profile Cloned",
    details: `Cloned profile: ${original.name} → ${cloned.name}`,
    before: `Count: ${profiles.length - 1}`,
    after: `Count: ${profiles.length}`
  });

  res.json(cloned);
});

app.post("/api/pos/profiles/archive/:id", (req, res) => {
  const { id } = req.params;
  const index = profiles.findIndex(p => p.id === id);
  if (index === -1) return res.status(404).json({ error: "Profile not found" });

  const originalName = profiles[index].name;
  profiles[index].isArchived = true;

  // Rule 10 Audit Log
  auditLogs.push({
    id: `audit-${Date.now()}`,
    timestamp: new Date().toISOString(),
    user: "Manager Dev",
    action: "POS Profile Archived",
    details: `Archived profile: ${originalName}`,
    before: "Active",
    after: "Archived"
  });

  res.json({ success: true, message: "Profile archived successfully" });
});

app.post("/api/pos/profiles/toggle-lock/:id", (req, res) => {
  const { id } = req.params;
  const index = profiles.findIndex(p => p.id === id);
  if (index === -1) return res.status(404).json({ error: "Profile not found" });

  const beforeVal = profiles[index].isLocked ? "Locked" : "Unlocked";
  profiles[index].isLocked = !profiles[index].isLocked;
  const afterVal = profiles[index].isLocked ? "Locked" : "Unlocked";

  // Rule 10 Audit Log
  auditLogs.push({
    id: `audit-${Date.now()}`,
    timestamp: new Date().toISOString(),
    user: "Manager Dev",
    action: "POS Profile Lock Toggled",
    details: `Terminal access changed for: ${profiles[index].name}`,
    before: beforeVal,
    after: afterVal
  });

  res.json(profiles[index]);
});

// 3. Shifts & Checkout
app.get("/api/pos/shifts", (req, res) => {
  res.json(shifts);
});

app.post("/api/pos/shifts/open", (req, res) => {
  const { profileId, openingBalance } = req.body;
  if (!profileId || openingBalance === undefined) {
    return res.status(400).json({ error: "Missing profileId or openingBalance" });
  }

  // Close previous shift on this profile if open
  shifts = shifts.map(s => {
    if (s.profileId === profileId && s.status === "Open") {
      return { ...s, status: "Closed", closedAt: new Date().toISOString(), closingBalance: s.openingBalance + s.salesValue };
    }
    return s;
  });

  const profile = profiles.find(p => p.id === profileId);
  const newShift: Shift = {
    id: `shift-${Date.now()}`,
    profileId,
    openedAt: new Date().toISOString(),
    closedAt: null,
    openingBalance: parseFloat(openingBalance),
    closingBalance: null,
    salesCount: 0,
    salesValue: 0,
    status: "Open"
  };
  shifts.push(newShift);

  // Rule 10 Audit Log
  auditLogs.push({
    id: `audit-${Date.now()}`,
    timestamp: new Date().toISOString(),
    user: profile ? profile.cashier : "Cashier User",
    action: "Shift Opened",
    details: `Shift opened on profile: ${profile ? profile.name : profileId}. Balance: ${openingBalance} INR`,
    before: "Closed",
    after: "Open"
  });

  res.json(newShift);
});

app.post("/api/pos/shifts/close/:id", (req, res) => {
  const { id } = req.params;
  const { closingBalance } = req.body;
  const index = shifts.findIndex(s => s.id === id);
  if (index === -1) return res.status(404).json({ error: "Shift not found" });

  shifts[index].status = "Closed";
  shifts[index].closedAt = new Date().toISOString();
  shifts[index].closingBalance = parseFloat(closingBalance || "0");

  const profile = profiles.find(p => p.id === shifts[index].profileId);

  // Rule 10 Audit Log
  auditLogs.push({
    id: `audit-${Date.now()}`,
    timestamp: new Date().toISOString(),
    user: profile ? profile.cashier : "Cashier User",
    action: "Shift Closed",
    details: `Shift closed. Declared Closing Balance: ${closingBalance} INR. Sales Registered: ${shifts[index].salesValue} INR`,
    before: "Open",
    after: "Closed"
  });

  res.json(shifts[index]);
});

app.post("/api/pos/checkout", (req, res) => {
  const { shiftId, items, total, customerName } = req.body;
  if (!shiftId || !items || items.length === 0) {
    return res.status(400).json({ error: "Checkout payload incomplete" });
  }

  const shiftIndex = shifts.findIndex(s => s.id === shiftId && s.status === "Open");
  if (shiftIndex === -1) {
    return res.status(400).json({ error: "No active open shift found to bind this transaction" });
  }

  // Verify stock levels and deduct in-memory
  const itemsLog: string[] = [];
  for (const item of items) {
    const prodIndex = products.findIndex(p => p.id === item.product.id);
    if (prodIndex !== -1) {
      const beforeStock = products[prodIndex].stock;
      products[prodIndex].stock = Math.max(0, products[prodIndex].stock - item.quantity);
      itemsLog.push(`${products[prodIndex].name} x${item.quantity} (Stock: ${beforeStock} → ${products[prodIndex].stock})`);
    }
  }

  // Record Bill
  const newBill: Bill = {
    id: `BILL-${Date.now().toString().slice(-6)}`,
    timestamp: new Date().toISOString(),
    items,
    total,
    customerName: customerName || "Walk-In Customer"
  };
  bills.push(newBill);

  // Update shift statistics
  shifts[shiftIndex].salesCount += 1;
  shifts[shiftIndex].salesValue += total;

  // Rule 10 Audit Log
  const profile = profiles.find(p => p.id === shifts[shiftIndex].profileId);
  auditLogs.push({
    id: `audit-${Date.now()}`,
    timestamp: new Date().toISOString(),
    user: profile ? profile.cashier : "Cashier User",
    action: "Invoice Created",
    details: `POS transaction successful. ${newBill.id}. Items: ${itemsLog.join(", ")}`,
    before: `Total Sales: ${shifts[shiftIndex].salesValue - total} INR`,
    after: `Total Sales: ${shifts[shiftIndex].salesValue} INR`
  });

  res.json({ success: true, bill: newBill, shift: shifts[shiftIndex] });
});

// 4. Universal Field Explorer (UFE) / Barcode Studio APIs
app.get("/api/ufe/fields", (req, res) => {
  res.json(fields);
});

// 5. Formula Registry APIs
app.get("/api/formulas", (req, res) => {
  res.json(formulas);
});

// 6. Party Stock Visibility (PSV) APIs
app.get("/api/psv/parties", (req, res) => {
  res.json(psvParties);
});

// 6b. Sales Studio (Quotations and Sales Orders) APIs
app.get("/api/sales/quotations", (req, res) => {
  res.json(quotations);
});

app.post("/api/sales/quotations", (req, res) => {
  const { customerName, items, status } = req.body;
  if (!customerName || !items || !Array.isArray(items)) {
    return res.status(400).json({ error: "Invalid quotation data. Customer name and items list are required." });
  }

  // Calculate taxes and totals
  let taxTotal = 0;
  let grandTotal = 0;
  const processedItems = items.map((item: any) => {
    const qty = parseFloat(item.quantity) || 0;
    const price = parseFloat(item.price) || 0;
    const taxRate = parseFloat(item.taxRate) || 18; // Default to 18% GST
    const baseTotal = qty * price;
    const taxAmount = (baseTotal * taxRate) / 100;
    const totalAmount = baseTotal + taxAmount;
    
    taxTotal += taxAmount;
    grandTotal += totalAmount;

    return {
      productId: item.productId,
      code: item.code,
      name: item.name,
      color: item.color,
      size: item.size,
      quantity: qty,
      price: price,
      taxRate: taxRate,
      taxAmount: Math.round(taxAmount * 100) / 100,
      totalAmount: Math.round(totalAmount * 100) / 100
    };
  });

  const year = new Date().getFullYear();
  const indexStr = String(quotations.length + 1).padStart(4, "0");
  const quotationNo = `QTN-${year}-${indexStr}`;

  const newQuotation: Quotation = {
    id: `q-${Date.now()}`,
    quotationNo,
    date: new Date().toISOString(),
    customerName,
    items: processedItems,
    taxTotal: Math.round(taxTotal * 100) / 100,
    grandTotal: Math.round(grandTotal * 100) / 100,
    status: status || "Draft"
  };

  quotations.push(newQuotation);

  // Audit Log
  auditLogs.push({
    id: `audit-${Date.now()}`,
    timestamp: new Date().toISOString(),
    user: "Manager Dev",
    action: "Quotation Created",
    details: `Created quotation ${newQuotation.quotationNo} for ${customerName} (Total: ${newQuotation.grandTotal} INR)`,
    before: "-",
    after: newQuotation.status
  });

  res.json(newQuotation);
});

app.put("/api/sales/quotations/:id", (req, res) => {
  const { id } = req.params;
  const { customerName, items, status } = req.body;
  
  const index = quotations.findIndex(q => q.id === id);
  if (index === -1) return res.status(404).json({ error: "Quotation not found" });

  const currentStatus = quotations[index].status;
  if (currentStatus === "Converted") {
    return res.status(400).json({ error: "Cannot modify a quotation that has already been converted to a Sales Order." });
  }

  if (customerName) quotations[index].customerName = customerName;
  if (status) quotations[index].status = status;

  if (items && Array.isArray(items)) {
    let taxTotal = 0;
    let grandTotal = 0;
    const processedItems = items.map((item: any) => {
      const qty = parseFloat(item.quantity) || 0;
      const price = parseFloat(item.price) || 0;
      const taxRate = parseFloat(item.taxRate) || 18;
      const baseTotal = qty * price;
      const taxAmount = (baseTotal * taxRate) / 100;
      const totalAmount = baseTotal + taxAmount;
      
      taxTotal += taxAmount;
      grandTotal += totalAmount;

      return {
        productId: item.productId,
        code: item.code,
        name: item.name,
        color: item.color,
        size: item.size,
        quantity: qty,
        price: price,
        taxRate: taxRate,
        taxAmount: Math.round(taxAmount * 100) / 100,
        totalAmount: Math.round(totalAmount * 100) / 100
      };
    });

    quotations[index].items = processedItems;
    quotations[index].taxTotal = Math.round(taxTotal * 100) / 100;
    quotations[index].grandTotal = Math.round(grandTotal * 100) / 100;
  }

  // Audit Log
  auditLogs.push({
    id: `audit-${Date.now()}`,
    timestamp: new Date().toISOString(),
    user: "Manager Dev",
    action: "Quotation Updated",
    details: `Updated quotation ${quotations[index].quotationNo}`,
    before: currentStatus,
    after: quotations[index].status
  });

  res.json(quotations[index]);
});

app.delete("/api/sales/quotations/:id", (req, res) => {
  const { id } = req.params;
  const index = quotations.findIndex(q => q.id === id);
  if (index === -1) return res.status(404).json({ error: "Quotation not found" });

  const quotationNo = quotations[index].quotationNo;
  quotations.splice(index, 1);

  // Audit Log
  auditLogs.push({
    id: `audit-${Date.now()}`,
    timestamp: new Date().toISOString(),
    user: "Manager Dev",
    action: "Quotation Deleted",
    details: `Deleted quotation ${quotationNo}`,
    before: "Active",
    after: "Deleted"
  });

  res.json({ success: true, message: `Quotation ${quotationNo} deleted successfully.` });
});

app.get("/api/sales/orders", (req, res) => {
  res.json(salesOrders);
});

app.post("/api/sales/orders", (req, res) => {
  const { customerName, items, status, sourceQuotationId } = req.body;
  if (!customerName || !items || !Array.isArray(items)) {
    return res.status(400).json({ error: "Invalid sales order data. Customer name and items list are required." });
  }

  // Calculate taxes and totals
  let taxTotal = 0;
  let grandTotal = 0;
  const processedItems = items.map((item: any) => {
    const qty = parseFloat(item.quantity) || 0;
    const price = parseFloat(item.price) || 0;
    const taxRate = parseFloat(item.taxRate) || 18;
    const baseTotal = qty * price;
    const taxAmount = (baseTotal * taxRate) / 100;
    const totalAmount = baseTotal + taxAmount;
    
    taxTotal += taxAmount;
    grandTotal += totalAmount;

    return {
      productId: item.productId,
      code: item.code,
      name: item.name,
      color: item.color,
      size: item.size,
      quantity: qty,
      price: price,
      taxRate: taxRate,
      taxAmount: Math.round(taxAmount * 100) / 100,
      totalAmount: Math.round(totalAmount * 100) / 100
    };
  });

  const year = new Date().getFullYear();
  const indexStr = String(salesOrders.length + 1).padStart(4, "0");
  const orderNo = `SO-${year}-${indexStr}`;

  const newOrder: SalesOrder = {
    id: `so-${Date.now()}`,
    orderNo,
    date: new Date().toISOString(),
    customerName,
    items: processedItems,
    taxTotal: Math.round(taxTotal * 100) / 100,
    grandTotal: Math.round(grandTotal * 100) / 100,
    status: status || "Draft",
    sourceQuotationId
  };

  salesOrders.push(newOrder);

  // Audit Log
  auditLogs.push({
    id: `audit-${Date.now()}`,
    timestamp: new Date().toISOString(),
    user: "Manager Dev",
    action: "Sales Order Created",
    details: `Created Sales Order ${newOrder.orderNo} for ${customerName} (Total: ${newOrder.grandTotal} INR)`,
    before: "-",
    after: newOrder.status
  });

  res.json(newOrder);
});

app.post("/api/sales/quotations/convert/:id", (req, res) => {
  const { id } = req.params;
  const qIndex = quotations.findIndex(q => q.id === id);
  if (qIndex === -1) return res.status(404).json({ error: "Quotation not found" });

  const quotation = quotations[qIndex];
  if (quotation.status === "Converted") {
    return res.status(400).json({ error: "Quotation has already been converted." });
  }

  // Create Sales Order from Quotation
  const year = new Date().getFullYear();
  const indexStr = String(salesOrders.length + 1).padStart(4, "0");
  const orderNo = `SO-${year}-${indexStr}`;

  const newOrder: SalesOrder = {
    id: `so-${Date.now()}`,
    orderNo,
    date: new Date().toISOString(),
    customerName: quotation.customerName,
    items: quotation.items.map(item => ({ ...item })),
    taxTotal: quotation.taxTotal,
    grandTotal: quotation.grandTotal,
    status: "Confirmed",
    sourceQuotationId: quotation.id
  };

  salesOrders.push(newOrder);
  
  // Mark Quotation as Converted
  quotations[qIndex].status = "Converted";
  quotations[qIndex].salesOrderId = newOrder.id;

  // Audit Log
  auditLogs.push({
    id: `audit-${Date.now()}`,
    timestamp: new Date().toISOString(),
    user: "Manager Dev",
    action: "Quotation Converted",
    details: `Converted Quotation ${quotation.quotationNo} to Sales Order ${newOrder.orderNo}`,
    before: "Submitted",
    after: "Converted"
  });

  res.json({ success: true, salesOrder: newOrder, quotation: quotations[qIndex] });
});

app.put("/api/sales/orders/:id", (req, res) => {
  const { id } = req.params;
  const { customerName, items, status } = req.body;
  
  const index = salesOrders.findIndex(so => so.id === id);
  if (index === -1) return res.status(404).json({ error: "Sales Order not found" });

  const currentStatus = salesOrders[index].status;
  if (customerName) salesOrders[index].customerName = customerName;
  if (status) salesOrders[index].status = status;

  if (items && Array.isArray(items)) {
    let taxTotal = 0;
    let grandTotal = 0;
    const processedItems = items.map((item: any) => {
      const qty = parseFloat(item.quantity) || 0;
      const price = parseFloat(item.price) || 0;
      const taxRate = parseFloat(item.taxRate) || 18;
      const baseTotal = qty * price;
      const taxAmount = (baseTotal * taxRate) / 100;
      const totalAmount = baseTotal + taxAmount;
      
      taxTotal += taxAmount;
      grandTotal += totalAmount;

      return {
        productId: item.productId,
        code: item.code,
        name: item.name,
        color: item.color,
        size: item.size,
        quantity: qty,
        price: price,
        taxRate: taxRate,
        taxAmount: Math.round(taxAmount * 100) / 100,
        totalAmount: Math.round(totalAmount * 100) / 100
      };
    });

    salesOrders[index].items = processedItems;
    salesOrders[index].taxTotal = Math.round(taxTotal * 100) / 100;
    salesOrders[index].grandTotal = Math.round(grandTotal * 100) / 100;
  }

  // Audit Log
  auditLogs.push({
    id: `audit-${Date.now()}`,
    timestamp: new Date().toISOString(),
    user: "Manager Dev",
    action: "Sales Order Updated",
    details: `Updated Sales Order ${salesOrders[index].orderNo}`,
    before: currentStatus,
    after: salesOrders[index].status
  });

  res.json(salesOrders[index]);
});

app.delete("/api/sales/orders/:id", (req, res) => {
  const { id } = req.params;
  const index = salesOrders.findIndex(so => so.id === id);
  if (index === -1) return res.status(404).json({ error: "Sales Order not found" });

  const orderNo = salesOrders[index].orderNo;
  salesOrders.splice(index, 1);

  // Audit Log
  auditLogs.push({
    id: `audit-${Date.now()}`,
    timestamp: new Date().toISOString(),
    user: "Manager Dev",
    action: "Sales Order Deleted",
    details: `Deleted Sales Order ${orderNo}`,
    before: "Active",
    after: "Deleted"
  });

  res.json({ success: true, message: `Sales Order ${orderNo} deleted successfully.` });
});

// 7. Audit Logs
app.get("/api/audit-logs", (req, res) => {
  res.json(auditLogs.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()));
});

// 8. Gemini-Powered Smart Explainer & AI Retail Assistant Chat
app.post("/api/assistant/chat", async (req, res) => {
  const { message, context } = req.body;
  if (!message) return res.status(400).json({ error: "Missing message" });

  const client = getAIClient();
  if (!client) {
    // Graceful mocked fallback with clear instructions for connecting real keys
    return res.json({
      reply: `**[Demo Assistant Mode]** I am operating in offline demo mode since your \`GEMINI_API_KEY\` is not yet configured. Here is an analysis of your query based on local SMRITI intelligence:\n\n* **Formula Insight**: To calculate metric-related health scores, SMRITI uses strict constitutional mathematical models (Rule 15). For instance, **Weeks of Cover** (WOC) evaluates stock survivability by dividing Current Stock by Average Sales Velocity.\n* **Smart Suggestion**: Based on your currently loaded distributor ledger (PSV), **Southern Logistics & Retail** has a Critical WOC of 8.5 weeks indicating bloated dead capital. Action: Trigger active markdown schemes or redistributions.\n\n*Configure \`GEMINI_API_KEY\` in your environment settings to enable live AI reasoning groundings!*`
    });
  }

  try {
    const systemPrompt = `You are the SMRITI Retail OS Intelligence Assistant, a senior retail business expert.
You help cashiers, store managers, and owners make sense of their retail metrics (WOC, Sales Velocity, Outlet Health, Dead Capital, Sell-Through %) and coordinate POS workflows.
Keep your answers professional, human-focused, highly structured, and grounded in the SMRITI design/operations constitution.
Reference the rules: Rule 7 (No /desk exposure), Rule 10 (Full audit logs), Rule 15 (Metric explainability: definition, formula, worked example, source, action).
Context of current store data: ${JSON.stringify(context || {})}.
Answer the user's question clearly, suggesting optimized operational decisions.`;

    const response = await client.models.generateContent({
      model: "gemini-2.5-flash",
      contents: [
        { role: "user", parts: [{ text: `${systemPrompt}\n\nUser Message: ${message}` }] }
      ]
    });

    const replyText = response.text || "I was unable to formulate a response. Please try again.";
    res.json({ reply: replyText });
  } catch (error: any) {
    console.error("Gemini API Error:", error);
    res.status(500).json({ error: "Gemini server-side call failed: " + error.message });
  }
});

// ── SMRITI Wiki & Documentation Explorer API ─────────────────────────────────

interface WikiDoc {
  path: string;
  name: string;
  folder: string;
  title: string;
}

// Helper to recursively retrieve markdown files
function crawlDocsDirectory(dir: string, baseDir: string = dir): WikiDoc[] {
  let results: WikiDoc[] = [];
  if (!fs.existsSync(dir)) return results;
  
  const items = fs.readdirSync(dir);
  for (const item of items) {
    const fullPath = path.join(dir, item);
    const stat = fs.statSync(fullPath);
    
    if (stat.isDirectory()) {
      if (item !== ".vitepress" && item !== "node_modules" && item !== ".git") {
        results = results.concat(crawlDocsDirectory(fullPath, baseDir));
      }
    } else if (item.endsWith(".md")) {
      const relPath = path.relative(baseDir, fullPath);
      let title = item;
      
      try {
        const content = fs.readFileSync(fullPath, "utf-8");
        const lines = content.split("\n");
        const headerLine = lines.find(l => l.trim().startsWith("# "));
        if (headerLine) {
          title = headerLine.replace("# ", "").trim();
        } else {
          const frontmatterTitle = lines.find(l => l.trim().startsWith("title:"));
          if (frontmatterTitle) {
            title = frontmatterTitle.replace("title:", "").replace(/['"]/g, "").trim();
          }
        }
      } catch (err) {
        // Safe fallback
      }
      
      results.push({
        path: relPath,
        name: item,
        folder: path.dirname(relPath) === "." ? "Root" : path.dirname(relPath),
        title
      });
    }
  }
  return results;
}

// Endpoint to list all documents
app.get("/api/docs/list", (req, res) => {
  try {
    const docsDir = path.join(process.cwd(), "docs");
    const docList = crawlDocsDirectory(docsDir);
    res.json(docList);
  } catch (err: any) {
    console.error("Failed to list wiki docs:", err);
    res.status(500).json({ error: err.message });
  }
});

// Endpoint to get content of a single document
app.get("/api/docs/content", (req, res) => {
  const relativePath = req.query.path as string;
  if (!relativePath) {
    return res.status(400).json({ error: "Missing 'path' query parameter." });
  }

  try {
    // Sanitize path against directory traversal
    const safePath = path.normalize(relativePath).replace(/^(\.\.(\/|\\|$))+/, '');
    const docsDir = path.join(process.cwd(), "docs");
    const fullPath = path.join(docsDir, safePath);

    if (!fs.existsSync(fullPath) || !fullPath.startsWith(docsDir)) {
      return res.status(404).json({ error: "SMRITI Wiki document not found or access denied." });
    }

    const content = fs.readFileSync(fullPath, "utf-8");
    res.json({ content });
  } catch (err: any) {
    console.error("Failed to read wiki document:", err);
    res.status(500).json({ error: err.message });
  }
});

// Endpoint to search in SMRITI documents
app.get("/api/docs/search", (req, res) => {
  const query = (req.query.q as string || "").trim().toLowerCase();
  if (!query) {
    return res.json([]);
  }

  try {
    const docsDir = path.join(process.cwd(), "docs");
    const docList = crawlDocsDirectory(docsDir);
    const searchResults = docList.map(doc => {
      const fullPath = path.join(docsDir, doc.path);
      try {
        const content = fs.readFileSync(fullPath, "utf-8");
        const idx = content.toLowerCase().indexOf(query);
        if (idx !== -1) {
          const start = Math.max(0, idx - 80);
          const end = Math.min(content.length, idx + query.length + 120);
          const snippet = "..." + content.slice(start, end).replace(/\n/g, " ") + "...";
          return { ...doc, snippet };
        }
      } catch (err) {}
      return null;
    }).filter(Boolean);

    res.json(searchResults);
  } catch (err: any) {
    console.error("Wiki search failed:", err);
    res.status(500).json({ error: err.message });
  }
});

// Endpoint for grounded Q&A with Gemini
app.post("/api/docs/ask", async (req, res) => {
  const { question } = req.body;
  if (!question) {
    return res.status(400).json({ error: "Missing 'question' parameter in request body." });
  }

  const docsDir = path.join(process.cwd(), "docs");
  let matchedFiles: { title: string; path: string; content: string }[] = [];

  try {
    const docList = crawlDocsDirectory(docsDir);
    const keywords = question.toLowerCase().split(/\s+/).filter((k: string) => k.length > 3);

    const matches = docList.map(doc => {
      const fullPath = path.join(docsDir, doc.path);
      try {
        const content = fs.readFileSync(fullPath, "utf-8");
        let score = 0;
        
        // Simple scoring based on title matches and body keyword frequency
        if (doc.title.toLowerCase().includes(question.toLowerCase())) {
          score += 10;
        }
        for (const word of keywords) {
          if (doc.title.toLowerCase().includes(word)) score += 5;
          const matchesCount = content.toLowerCase().split(word).length - 1;
          score += matchesCount;
        }
        
        if (score > 0) {
          return { doc, content, score };
        }
      } catch (err) {}
      return null;
    }).filter(Boolean) as any[];

    // Sort by score and take top 3
    matches.sort((a, b) => b.score - a.score);
    matchedFiles = matches.slice(0, 3).map(m => ({
      title: m.doc.title,
      path: m.doc.path,
      content: m.content
    }));
  } catch (err) {
    console.error("Error matching grounding documents:", err);
  }

  const client = getAIClient();
  if (!client) {
    const citeList = matchedFiles.map(f => `* **[${f.title}](docs/${f.path})**`).join("\n");
    return res.json({
      reply: `### **[SMRITI Offline Wiki Copilot]**
Operating in local indexing mode (configure \`GEMINI_API_KEY\` in **Settings > Secrets** for live AI reasoning).

Based on local SMRITI indexing, the following pages are highly relevant to your question:
${citeList || "* No direct matching wiki pages found in local index."}

#### Summary of SMRITI Wiki:
The **SMRITI Retail OS** architecture bridges distributed physical outlets with centralized ERP databases using highly strict guidelines. Core tenets include:
1. **Dumb User Experience**: Interfaces must require minimal inputs and include automatic code generation (such as auto-completed style codes).
2. **Channel Visibility (PSV)**: Real-time stock counts, weeks-of-cover (WOC), and sell-through percentages help managers relocate stock instantly to maximize liquidity.
3. **Auditability**: Every change (e.g., pricing, item configuration, shifts) is written into persistent, immutable system logs.`
    });
  }

  try {
    const docsContext = matchedFiles.map(f => `DOCUMENT PATH: docs/${f.path}\nTITLE: ${f.title}\nCONTENT:\n${f.content.slice(0, 4500)}`).join("\n\n---\n\n");
    
    const systemPrompt = `You are the SMRITI Wiki Copilot, an advanced AI search assistant and documentation expert for SMRITI Retail OS.
Your task is to answer user queries based on the provided official SMRITI documentation.
Always formulate highly structured, professional, and clear answers.
Ground your responses strictly in the provided documents where possible. If the documents don't contain the answer, use your pre-trained SMRITI system knowledge but clearly distinguish what is from official documents.
Provide rich details. When you reference information from a specific document, cite it (e.g. "[SMRITI Formula Registry (docs/08-architecture/kgf_formula_registry.md)]").
Use clean, scannable markdown formatting. Keep the tone friendly, authoritative, and helpful.

GROUNDING SMRITI DOCUMENTATION:
${docsContext || "No highly relevant matching documents were found in the local index. Answer the question using your general understanding of the SMRITI Retail OS ecosystem (POS Terminals, KPI calculations like Weeks of Cover, Channel visibility, etc.)."}

User Question: ${question}`;

    const response = await client.models.generateContent({
      model: "gemini-3.5-flash",
      contents: [
        { role: "user", parts: [{ text: systemPrompt }] }
      ]
    });

    const reply = response.text || "Could not generate an answer based on SMRITI docs. Please check your question or try again.";
    res.json({ reply, matchedFiles: matchedFiles.map(f => ({ title: f.title, path: f.path })) });
  } catch (error: any) {
    console.error("Gemini Q&A Error:", error);
    res.status(500).json({ error: "Gemini server-side call failed: " + error.message });
  }
});

// ── SMRITI Purchase Studio Backend Modules & APIs ───────────────────────────

interface Supplier {
  id: string;
  name: string;
  vendorCode: string;
  taxRegistrationNumber: string;
  category: string;
  address: string;
  contactDetails: string;
}

interface PurchaseItem {
  productId: string;
  code: string;
  name: string;
  color?: string;
  size?: string;
  quantity: number;
  receivedQuantity: number;
  price: number;
  taxRate: number;
  taxAmount: number;
  totalAmount: number;
}

interface PurchaseOrder {
  id: string;
  orderNo: string;
  date: string;
  supplierId: string;
  supplierName: string;
  expectedDeliveryDate: string;
  company: string;
  currency: string;
  items: PurchaseItem[];
  taxTotal: number;
  grandTotal: number;
  receivedPercentage: number;
  status: "Draft" | "Confirmed" | "Cancelled" | "Complete";
  remarks: string;
  amendedFromId?: string;
  submittedBy?: string;
  submittedAt?: string;
  paidAmount: number;
}

interface GoodsReceipt {
  id: string;
  receiptNo: string;
  date: string;
  purchaseOrderId: string;
  supplierName: string;
  items: {
    productId: string;
    code: string;
    name: string;
    color?: string;
    size?: string;
    quantityReceived: number;
  }[];
}

// Global Configuration
let companyState: string | null = "DL"; // DL = Delhi. Can be set to null to trigger jurisdiction warning.

// In-Memory Database for Purchase Studio
let suppliers: Supplier[] = [
  {
    id: "sup-1",
    name: "Manoj Traders",
    vendorCode: "VND-MANOJ",
    taxRegistrationNumber: "07AAAAA1111A1Z1",
    category: "Apparel",
    address: "A-45, Phase-1, Okhla Industrial Area, New Delhi - 110020",
    contactDetails: "Manoj Sharma, Phone: +91 9812345678"
  },
  {
    id: "sup-2",
    name: "Kora Apparels Wholesale",
    vendorCode: "VND-KORA",
    taxRegistrationNumber: "27BBBBB2222B2Z2",
    category: "Apparel",
    address: "Building C, Sector 5, Ghansoli, Navi Mumbai - 400701",
    contactDetails: "Rajesh Patel, Phone: +91 9876543210"
  },
  {
    id: "sup-3",
    name: "Southern Logistics & Retail",
    vendorCode: "VND-SOUTH",
    taxRegistrationNumber: "33CCCCC3333C3Z3",
    category: "Footwear",
    address: "12, Anna Salai, Teynampet, Chennai - 600018",
    contactDetails: "V. Kumar, Phone: +91 9444012345"
  }
];

let purchaseOrders: PurchaseOrder[] = [
  {
    id: "po-1",
    orderNo: "PO-2026-0001",
    date: "2026-07-01T10:00:00.000Z",
    supplierId: "sup-1",
    supplierName: "Manoj Traders",
    expectedDeliveryDate: "2026-07-15",
    company: "Smriti India Ltd",
    currency: "INR",
    items: [
      {
        productId: "p1",
        code: "TSH-COT-M",
        name: "Classic Cotton T-Shirt",
        color: "Navy",
        size: "M",
        quantity: 100,
        receivedQuantity: 60,
        price: 480, // SMRITI custom last purchase price
        taxRate: 12, // Apparel derived
        taxAmount: 5760,
        totalAmount: 53760
      },
      {
        productId: "p2",
        code: "TSH-COT-L",
        name: "Classic Cotton T-Shirt",
        color: "Navy",
        size: "L",
        quantity: 50,
        receivedQuantity: 50,
        price: 480,
        taxRate: 12,
        taxAmount: 2880,
        totalAmount: 26880
      }
    ],
    taxTotal: 8640,
    grandTotal: 80640,
    receivedPercentage: 73,
    status: "Confirmed",
    remarks: "Initial Monsoon Sourcing",
    paidAmount: 20000
  },
  {
    id: "po-2",
    orderNo: "PO-2026-0002",
    date: "2026-07-03T11:00:00.000Z",
    supplierId: "sup-2",
    supplierName: "Kora Apparels Wholesale",
    expectedDeliveryDate: "2026-07-20",
    company: "Smriti India Ltd",
    currency: "INR",
    items: [
      {
        productId: "p4",
        code: "DEN-SLM-32",
        name: "Premium Slim Fit Denim",
        color: "Indigo",
        size: "32",
        quantity: 40,
        receivedQuantity: 0,
        price: 1100,
        taxRate: 12,
        taxAmount: 5280,
        totalAmount: 49280
      }
    ],
    taxTotal: 5280,
    grandTotal: 49280,
    receivedPercentage: 0,
    status: "Confirmed",
    remarks: "High performance slim fit variants replenishment",
    paidAmount: 0
  }
];

let goodsReceipts: GoodsReceipt[] = [
  {
    id: "grn-1",
    receiptNo: "GRN-2026-0001",
    date: "2026-07-05T14:30:00.000Z",
    purchaseOrderId: "po-1",
    supplierName: "Manoj Traders",
    items: [
      {
        productId: "p1",
        code: "TSH-COT-M",
        name: "Classic Cotton T-Shirt",
        color: "Navy",
        size: "M",
        quantityReceived: 60
      },
      {
        productId: "p2",
        code: "TSH-COT-L",
        name: "Classic Cotton T-Shirt",
        color: "Navy",
        size: "L",
        quantityReceived: 50
      }
    ]
  }
];

const CLASSIFICATION_TAX_RATES: Record<string, number> = {
  "Apparel": 12,
  "Footwear": 18,
  "Accessories": 18
};

// Reorder Specs for our 10 products
const REORDER_SPECS: Record<string, { level: number; reorderQty: number; preferredSupplierId: string }> = {
  "p1": { level: 50, reorderQty: 100, preferredSupplierId: "sup-1" },
  "p2": { level: 40, reorderQty: 80, preferredSupplierId: "sup-1" },
  "p3": { level: 20, reorderQty: 50, preferredSupplierId: "sup-1" },
  "p4": { level: 30, reorderQty: 60, preferredSupplierId: "sup-2" },
  "p5": { level: 25, reorderQty: 50, preferredSupplierId: "sup-2" },
  "p6": { level: 15, reorderQty: 40, preferredSupplierId: "sup-3" },
  "p7": { level: 20, reorderQty: 50, preferredSupplierId: "sup-3" },
  "p8": { level: 25, reorderQty: 60, preferredSupplierId: "sup-2" },
  "p9": { level: 20, reorderQty: 50, preferredSupplierId: "sup-2" },
  "p10": { level: 50, reorderQty: 100, preferredSupplierId: "sup-1" }
};

// Security check middleware
const checkPurchaseWriteAccess = (req: express.Request, res: express.Response, next: express.NextFunction) => {
  const role = req.headers["x-user-role"] as string;
  if (role && role.toLowerCase() === "cashier") {
    return res.status(403).json({ error: "Access Denied: Cashiers are restricted from write, submit, amend, or receive actions under SMRITI Rule 7." });
  }
  next();
};

// Jurisdiction check helper
const checkJurisdiction = (req: express.Request, res: express.Response, next: express.NextFunction) => {
  if (!companyState) {
    return res.status(400).json({ error: "System Configuration Blocked: Company state tax jurisdiction is not configured. Please define tax jurisdiction under corporate properties first." });
  }
  next();
};

// Toggle company state configuration (for simulation/validation)
app.post("/api/purchase/config/jurisdiction", checkPurchaseWriteAccess, (req, res) => {
  const { state } = req.body;
  companyState = state || null;
  res.json({ success: true, companyState });
});

app.get("/api/purchase/config", (req, res) => {
  res.json({ companyState });
});

// 1. Supplier APIs
app.get("/api/purchase/suppliers", (req, res) => {
  const q = (req.query.q as string || "").trim().toLowerCase();
  if (!q) {
    return res.json(suppliers);
  }
  const filtered = suppliers.filter(s => 
    s.name.toLowerCase().includes(q) || 
    s.vendorCode.toLowerCase().includes(q)
  );
  res.json(filtered);
});

app.get("/api/purchase/suppliers/:id", (req, res) => {
  const { id } = req.params;
  const supplier = suppliers.find(s => s.id === id);
  if (!supplier) {
    return res.status(404).json({ error: "Supplier not found" });
  }

  // Calculate direct summary values from database (in-memory arrays)
  const supplierOrders = purchaseOrders.filter(po => po.supplierId === id);
  const confirmedOrComplete = supplierOrders.filter(po => po.status === "Confirmed" || po.status === "Complete");
  
  const totalOrders = supplierOrders.length;
  const totalValue = confirmedOrComplete.reduce((acc, po) => acc + po.grandTotal, 0);
  
  let lastOrderDate = "-";
  if (supplierOrders.length > 0) {
    const sorted = [...supplierOrders].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    lastOrderDate = sorted[0].date;
  }

  res.json({
    ...supplier,
    summary: {
      totalOrders,
      totalValue: Math.round(totalValue * 100) / 100,
      lastOrderDate
    }
  });
});

app.post("/api/purchase/suppliers", checkPurchaseWriteAccess, (req, res) => {
  const { name, vendorCode, taxRegistrationNumber, category, address, contactDetails } = req.body;
  if (!name || !vendorCode) {
    return res.status(400).json({ error: "Supplier Name and Vendor Code are required." });
  }

  const existingIndex = suppliers.findIndex(s => s.vendorCode.toUpperCase() === vendorCode.toUpperCase());
  if (existingIndex !== -1) {
    // Update existing record rather than creating a duplicate
    suppliers[existingIndex] = {
      ...suppliers[existingIndex],
      name,
      taxRegistrationNumber: taxRegistrationNumber || suppliers[existingIndex].taxRegistrationNumber,
      category: category || suppliers[existingIndex].category,
      address: address || suppliers[existingIndex].address,
      contactDetails: contactDetails || suppliers[existingIndex].contactDetails
    };
    
    // Log audit trail
    auditLogs.push({
      id: `audit-${Date.now()}`,
      timestamp: new Date().toISOString(),
      user: req.headers["x-user-name"] || "Manager Dev",
      action: "Supplier Updated",
      details: `Updated Supplier ${name} (Vendor Code: ${vendorCode})`,
      before: "Supplier exists",
      after: "Supplier updated"
    });

    return res.json({ success: true, supplier: suppliers[existingIndex], updated: true });
  }

  // Create new
  const newSupplier: Supplier = {
    id: `sup-${Date.now()}`,
    name,
    vendorCode: vendorCode.toUpperCase(),
    taxRegistrationNumber: taxRegistrationNumber || "",
    category: category || "Apparel",
    address: address || "",
    contactDetails: contactDetails || ""
  };
  suppliers.push(newSupplier);

  // Log audit trail
  auditLogs.push({
    id: `audit-${Date.now()}`,
    timestamp: new Date().toISOString(),
    user: req.headers["x-user-name"] || "Manager Dev",
    action: "Supplier Created",
    details: `Created new Supplier ${name} with Code ${vendorCode}`,
    before: "-",
    after: `Supplier: ${newSupplier.id}`
  });

  res.json({ success: true, supplier: newSupplier, updated: false });
});

// 2. Default Rate Determination API
app.get("/api/purchase/default-rate", (req, res) => {
  const { productId, supplierId } = req.query;
  if (!productId) {
    return res.status(400).json({ error: "productId parameter is required." });
  }

  // 1. Try to find the most recent order history for this item from this specific supplier
  const confirmedOrders = purchaseOrders.filter(po => po.status === "Confirmed" || po.status === "Complete");
  const specificHistory = confirmedOrders
    .filter(po => po.supplierId === supplierId)
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  for (const po of specificHistory) {
    const item = po.items.find(i => i.productId === productId);
    if (item) {
      return res.json({ rate: item.price, source: "Supplier Sourcing History" });
    }
  }

  // 2. Fall back to the general last purchase rate across any supplier
  const generalHistory = confirmedOrders
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  for (const po of generalHistory) {
    const item = po.items.find(i => i.productId === productId);
    if (item) {
      return res.json({ rate: item.price, source: "Global Last Purchase Rate" });
    }
  }

  // 3. Fall back to standard cost price (derived as 60% of MRP)
  const prod = products.find(p => p.id === productId);
  if (prod) {
    const costPrice = Math.round(prod.price * 0.6);
    return res.json({ rate: costPrice, source: "Default Cost Fallback (60% MRP)" });
  }

  res.status(404).json({ error: "Product variant not found" });
});

// 3. Reorder Suggestion APIs
app.get("/api/purchase/reorder-suggestions", (req, res) => {
  const supplierId = req.query.supplierId as string;
  
  // Compile list of low-stock alerts
  const suggestions = products.map(prod => {
    const spec = REORDER_SPECS[prod.id];
    if (!spec) return null;

    // Filter by preferred supplier if requested
    if (supplierId && spec.preferredSupplierId !== supplierId) return null;

    const currentQty = prod.stock;
    if (currentQty <= spec.level) {
      const suggestedQty = spec.reorderQty - currentQty;
      const supplier = suppliers.find(s => s.id === spec.preferredSupplierId);

      // Determine last rate
      let lastRate = Math.round(prod.price * 0.6); // default
      const confirmedOrders = purchaseOrders.filter(po => po.status === "Confirmed" || po.status === "Complete");
      const specificHistory = confirmedOrders
        .filter(po => po.supplierId === spec.preferredSupplierId)
        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
      
      let rateSource = "Default Cost Fallback";
      if (specificHistory.length > 0) {
        const item = specificHistory[0].items.find(i => i.productId === prod.id);
        if (item) {
          lastRate = item.price;
          rateSource = "Supplier Sourcing History";
        }
      }

      return {
        productId: prod.id,
        code: prod.code,
        name: prod.name,
        color: prod.color,
        size: prod.size,
        currentStock: currentQty,
        reorderLevel: spec.level,
        reorderQty: spec.reorderQty,
        suggestedQty: Math.max(0, suggestedQty),
        preferredSupplierId: spec.preferredSupplierId,
        preferredSupplierName: supplier ? supplier.name : "Unknown",
        lastPurchaseRate: lastRate,
        rateSource
      };
    }
    return null;
  }).filter(Boolean);

  res.json(suggestions);
});

// Convert Suggestions to PO Draft
app.post("/api/purchase/reorder-suggestions/convert", checkPurchaseWriteAccess, checkJurisdiction, (req, res) => {
  const { supplierId, selectedProductIds } = req.body;
  if (!supplierId || !selectedProductIds || selectedProductIds.length === 0) {
    return res.status(400).json({ error: "Supplier and product selection are required to convert suggestions." });
  }

  const supplier = suppliers.find(s => s.id === supplierId);
  if (!supplier) {
    return res.status(404).json({ error: "Supplier not found." });
  }

  // Create items list
  let taxTotal = 0;
  let grandTotal = 0;

  const items: PurchaseItem[] = [];

  for (const pid of selectedProductIds) {
    const prod = products.find(p => p.id === pid);
    const spec = REORDER_SPECS[pid];
    if (prod && spec) {
      const suggestedQty = Math.max(1, spec.reorderQty - prod.stock);
      
      // Look up last rate
      let lastRate = Math.round(prod.price * 0.6);
      const confirmedOrders = purchaseOrders.filter(po => po.status === "Confirmed" || po.status === "Complete");
      const specificHistory = confirmedOrders
        .filter(po => po.supplierId === supplierId)
        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
      if (specificHistory.length > 0) {
        const hItem = specificHistory[0].items.find(i => i.productId === pid);
        if (hItem) lastRate = hItem.price;
      }

      // Derived Tax Rate
      const taxRate = CLASSIFICATION_TAX_RATES[prod.category] !== undefined 
        ? CLASSIFICATION_TAX_RATES[prod.category] 
        : (prod.gstPercentage || 18);

      const netAmount = suggestedQty * lastRate;
      const taxAmount = Math.round((netAmount * (taxRate / 100)) * 100) / 100;
      const totalAmount = netAmount + taxAmount;

      taxTotal += taxAmount;
      grandTotal += totalAmount;

      items.push({
        productId: prod.id,
        code: prod.code,
        name: prod.name,
        color: prod.color,
        size: prod.size,
        quantity: suggestedQty,
        receivedQuantity: 0,
        price: lastRate,
        taxRate,
        taxAmount,
        totalAmount
      });
    }
  }

  const poNumber = `PO-2026-000${purchaseOrders.length + 1}`;
  const newPO: PurchaseOrder = {
    id: `po-${Date.now()}`,
    orderNo: poNumber,
    date: new Date().toISOString(),
    supplierId: supplier.id,
    supplierName: supplier.name,
    expectedDeliveryDate: new Date(Date.now() + 7 * 24 * 3600 * 1000).toISOString().split('T')[0], // 7 days expected
    company: "Smriti India Ltd",
    currency: "INR",
    items,
    taxTotal: Math.round(taxTotal * 100) / 100,
    grandTotal: Math.round(grandTotal * 100) / 100,
    receivedPercentage: 0,
    status: "Draft",
    remarks: "Auto-generated from reorder trigger suggestions",
    paidAmount: 0
  };

  purchaseOrders.push(newPO);

  res.json({ success: true, order: newPO });
});

// 4. Purchase Order Creation and Management
app.get("/api/purchase/orders", (req, res) => {
  const { supplierId, status, startDate, endDate } = req.query;
  
  let filtered = [...purchaseOrders];

  // All filtering executes at database query/filter level
  if (supplierId) {
    filtered = filtered.filter(po => po.supplierId === supplierId);
  }
  if (status) {
    filtered = filtered.filter(po => po.status === status);
  }
  if (startDate) {
    filtered = filtered.filter(po => new Date(po.date) >= new Date(startDate as string));
  }
  if (endDate) {
    filtered = filtered.filter(po => new Date(po.date) <= new Date(endDate as string));
  }

  // Sort descending by date
  filtered.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  res.json(filtered);
});

app.post("/api/purchase/orders", checkPurchaseWriteAccess, checkJurisdiction, (req, res) => {
  const { supplierId, expectedDeliveryDate, items, remarks } = req.body;
  if (!supplierId || !items || items.length === 0) {
    return res.status(400).json({ error: "Supplier details and line items are mandatory." });
  }

  const supplier = suppliers.find(s => s.id === supplierId);
  if (!supplier) {
    return res.status(404).json({ error: "Selected supplier does not exist." });
  }

  let taxTotal = 0;
  let grandTotal = 0;

  const processedItems = items.map((item: any) => {
    const prod = products.find(p => p.id === item.productId);
    const qty = Math.max(1, parseInt(item.quantity) || 1);
    const price = Math.max(0, parseFloat(item.price) || 0);

    // Mandate derived tax calculation from classification-code
    let taxRate = 18;
    if (prod) {
      taxRate = CLASSIFICATION_TAX_RATES[prod.category] !== undefined
        ? CLASSIFICATION_TAX_RATES[prod.category]
        : (prod.gstPercentage || 18);
    }

    const itemNetAmount = qty * price;
    const taxAmount = Math.round((itemNetAmount * (taxRate / 100)) * 100) / 100;
    const totalAmount = itemNetAmount + taxAmount;

    taxTotal += taxAmount;
    grandTotal += totalAmount;

    return {
      productId: item.productId,
      code: item.code || (prod ? prod.code : ""),
      name: item.name || (prod ? prod.name : ""),
      color: item.color || (prod ? prod.color : ""),
      size: item.size || (prod ? prod.size : ""),
      quantity: qty,
      receivedQuantity: 0,
      price,
      taxRate,
      taxAmount: Math.round(taxAmount * 100) / 100,
      totalAmount: Math.round(totalAmount * 100) / 100
    };
  });

  const poNumber = `PO-2026-000${purchaseOrders.length + 1}`;
  const newPO: PurchaseOrder = {
    id: `po-${Date.now()}`,
    orderNo: poNumber,
    date: new Date().toISOString(),
    supplierId: supplier.id,
    supplierName: supplier.name,
    expectedDeliveryDate: expectedDeliveryDate || new Date(Date.now() + 5 * 24 * 3600 * 1000).toISOString().split('T')[0],
    company: "Smriti India Ltd",
    currency: "INR",
    items: processedItems,
    taxTotal: Math.round(taxTotal * 100) / 100,
    grandTotal: Math.round(grandTotal * 100) / 100,
    receivedPercentage: 0,
    status: "Draft",
    remarks: remarks || "",
    paidAmount: 0
  };

  purchaseOrders.push(newPO);

  res.json({ success: true, order: newPO });
});

// Submit draft PO
app.post("/api/purchase/orders/:id/submit", checkPurchaseWriteAccess, (req, res) => {
  const { id } = req.params;
  const index = purchaseOrders.findIndex(po => po.id === id);
  if (index === -1) {
    return res.status(404).json({ error: "Purchase Order not found." });
  }

  if (purchaseOrders[index].status !== "Draft") {
    return res.status(400).json({ error: "Only Draft purchase orders can be submitted." });
  }

  purchaseOrders[index].status = "Confirmed";
  purchaseOrders[index].submittedBy = (req.headers["x-user-name"] as string) || "Manager Dev";
  purchaseOrders[index].submittedAt = new Date().toISOString();

  // Log in global audit logs
  auditLogs.push({
    id: `audit-${Date.now()}`,
    timestamp: new Date().toISOString(),
    user: purchaseOrders[index].submittedBy,
    action: "PO Confirmed",
    details: `Submitted & Confirmed Purchase Order ${purchaseOrders[index].orderNo} (Val: ₹${purchaseOrders[index].grandTotal})`,
    before: "Draft",
    after: "Confirmed"
  });

  res.json({ success: true, order: purchaseOrders[index] });
});

// Amend Confirmed PO
app.post("/api/purchase/orders/:id/amend", checkPurchaseWriteAccess, checkJurisdiction, (req, res) => {
  const { id } = req.params;
  const { items, reason } = req.body;
  
  const index = purchaseOrders.findIndex(po => po.id === id);
  if (index === -1) {
    return res.status(404).json({ error: "Original Purchase Order not found." });
  }

  const originalPO = purchaseOrders[index];
  if (originalPO.status !== "Confirmed") {
    return res.status(400).json({ error: "Only Confirmed purchase orders can be amended." });
  }

  // Cancel original confirmed PO
  originalPO.status = "Cancelled";
  originalPO.remarks = `Amended & Superseded. Reason: ${reason || "No reason given"}`;

  // Create new draft with updated quantities
  let taxTotal = 0;
  let grandTotal = 0;

  const processedItems = items.map((item: any) => {
    const prod = products.find(p => p.id === item.productId);
    const qty = Math.max(1, parseInt(item.quantity) || 1);
    const price = originalPO.items.find(i => i.productId === item.productId)?.price || (prod ? prod.price * 0.6 : 0);

    let taxRate = 18;
    if (prod) {
      taxRate = CLASSIFICATION_TAX_RATES[prod.category] !== undefined
        ? CLASSIFICATION_TAX_RATES[prod.category]
        : (prod.gstPercentage || 18);
    }

    const netAmount = qty * price;
    const taxAmount = Math.round((netAmount * (taxRate / 100)) * 100) / 100;
    const totalAmount = netAmount + taxAmount;

    taxTotal += taxAmount;
    grandTotal += totalAmount;

    return {
      productId: item.productId,
      code: item.code,
      name: item.name,
      color: item.color,
      size: item.size,
      quantity: qty,
      receivedQuantity: 0,
      price,
      taxRate,
      taxAmount: Math.round(taxAmount * 100) / 100,
      totalAmount: Math.round(totalAmount * 100) / 100
    };
  });

  const newPONumber = `${originalPO.orderNo}-A${Date.now().toString().slice(-4)}`;
  const newPO: PurchaseOrder = {
    id: `po-${Date.now()}`,
    orderNo: newPONumber,
    date: new Date().toISOString(),
    supplierId: originalPO.supplierId,
    supplierName: originalPO.supplierName,
    expectedDeliveryDate: originalPO.expectedDeliveryDate,
    company: originalPO.company,
    currency: originalPO.currency,
    items: processedItems,
    taxTotal: Math.round(taxTotal * 100) / 100,
    grandTotal: Math.round(grandTotal * 100) / 100,
    receivedPercentage: 0,
    status: "Draft",
    remarks: `Amendment of ${originalPO.orderNo}. Reason: ${reason || "Not specified"}.`,
    amendedFromId: originalPO.id,
    paidAmount: originalPO.paidAmount
  };

  purchaseOrders.push(newPO);

  // Log in global audit logs
  auditLogs.push({
    id: `audit-${Date.now()}`,
    timestamp: new Date().toISOString(),
    user: req.headers["x-user-name"] || "Manager Dev",
    action: "PO Amended",
    details: `Amended ${originalPO.orderNo} -> created draft ${newPO.orderNo}. Reason: ${reason}`,
    before: "Confirmed",
    after: "Draft"
  });

  res.json({ success: true, original: originalPO, amendment: newPO });
});

// Receive Stock against PO
app.post("/api/purchase/orders/:id/receive", checkPurchaseWriteAccess, (req, res) => {
  const { id } = req.params;
  const { receivedItems } = req.body; // array of { productId, quantityReceived }
  
  if (!receivedItems || receivedItems.length === 0) {
    return res.status(400).json({ error: "Receiving quantities list cannot be empty." });
  }

  const index = purchaseOrders.findIndex(po => po.id === id);
  if (index === -1) {
    return res.status(404).json({ error: "Purchase Order not found." });
  }

  const po = purchaseOrders[index];
  if (po.status !== "Confirmed") {
    return res.status(400).json({ error: "Stock receipts can only be recorded against Confirmed purchase orders." });
  }

  // Verification step: proceed with a goods receipt quantity that exceeds the pending quantity on the order must block
  for (const recItem of receivedItems) {
    const poItem = po.items.find(i => i.productId === recItem.productId);
    if (!poItem) {
      return res.status(400).json({ error: `Selected item with ID ${recItem.productId} does not belong to this purchase order.` });
    }
    const pendingQty = poItem.quantity - poItem.receivedQuantity;
    if (recItem.quantityReceived > pendingQty) {
      // MANDATE: Block it with a specific message naming the item and the maximum allowed quantity
      return res.status(400).json({ 
        error: `Receipt Violation: Item "${poItem.name} (${poItem.size || "OS"})" has a maximum pending quantity of ${pendingQty} units. Attempted to receive ${recItem.quantityReceived} units, which exceeds the outstanding order buffer.` 
      });
    }
  }

  // Create a Goods Receipt record
  const receiptNo = `GRN-2026-000${goodsReceipts.length + 1}`;
  const newReceipt: GoodsReceipt = {
    id: `grn-${Date.now()}`,
    receiptNo,
    date: new Date().toISOString(),
    purchaseOrderId: po.id,
    supplierName: po.supplierName,
    items: []
  };

  // Process receipt and update stock immediately
  receivedItems.forEach((recItem: any) => {
    if (recItem.quantityReceived <= 0) return;

    const poItemIndex = po.items.findIndex(i => i.productId === recItem.productId);
    if (poItemIndex !== -1) {
      po.items[poItemIndex].receivedQuantity += recItem.quantityReceived;
      
      newReceipt.items.push({
        productId: recItem.productId,
        code: po.items[poItemIndex].code,
        name: po.items[poItemIndex].name,
        color: po.items[poItemIndex].color,
        size: po.items[poItemIndex].size,
        quantityReceived: recItem.quantityReceived
      });

      // Update system product stock levels immediately
      const pIndex = products.findIndex(p => p.id === recItem.productId);
      if (pIndex !== -1) {
        products[pIndex].stock += recItem.quantityReceived;
      }
    }
  });

  goodsReceipts.push(newReceipt);

  // Recalculate received percentage
  const totalOrdered = po.items.reduce((acc, i) => acc + i.quantity, 0);
  const totalReceived = po.items.reduce((acc, i) => acc + i.receivedQuantity, 0);
  po.receivedPercentage = Math.round((totalReceived / totalOrdered) * 100);

  // If fully received, auto mark Complete
  if (totalReceived === totalOrdered) {
    po.status = "Complete";
  }

  // Log in global audit logs
  auditLogs.push({
    id: `audit-${Date.now()}`,
    timestamp: new Date().toISOString(),
    user: req.headers["x-user-name"] || "Manager Dev",
    action: "Goods Received",
    details: `Receipt ${receiptNo} recorded against ${po.orderNo}. Received ${totalReceived}/${totalOrdered} items.`,
    before: "Confirmed",
    after: po.status
  });

  res.json({ success: true, order: po, receipt: newReceipt });
});

// Support marking payments against orders to reduce outstanding balance
app.post("/api/purchase/orders/:id/pay", checkPurchaseWriteAccess, (req, res) => {
  const { id } = req.params;
  const { amount } = req.body;
  const index = purchaseOrders.findIndex(po => po.id === id);
  if (index === -1) return res.status(404).json({ error: "Order not found." });

  const payVal = parseFloat(amount) || 0;
  if (payVal <= 0) return res.status(400).json({ error: "Payment amount must be greater than zero." });

  const maxPayable = purchaseOrders[index].grandTotal - purchaseOrders[index].paidAmount;
  if (payVal > maxPayable) {
    return res.status(400).json({ error: `Payment exceeds maximum payable outstanding value of ₹${maxPayable}.` });
  }

  purchaseOrders[index].paidAmount += payVal;
  res.json({ success: true, order: purchaseOrders[index] });
});

// 5. Reports (All computed & compiled at database level)
// Report 1: Supplier Outstanding
app.get("/api/purchase/reports/outstanding", (req, res) => {
  // Shows how much is owed to each supplier — total value of confirmed orders minus what has already been billed and paid.
  // Group by supplier. All arithmetic happens at backend.
  const summaryMap: Record<string, { supplierId: string; name: string; vendorCode: string; totalOwed: number; oldestOrderDate: string }> = {};

  suppliers.forEach(s => {
    summaryMap[s.id] = {
      supplierId: s.id,
      name: s.name,
      vendorCode: s.vendorCode,
      totalOwed: 0,
      oldestOrderDate: "-"
    };
  });

  // Calculate outstanding values
  purchaseOrders.forEach(po => {
    if (po.status === "Confirmed" || po.status === "Complete") {
      const owed = po.grandTotal - po.paidAmount;
      if (owed > 0) {
        if (!summaryMap[po.supplierId]) {
          // fallback in case supplier was deleted
          summaryMap[po.supplierId] = {
            supplierId: po.supplierId,
            name: po.supplierName,
            vendorCode: "N/A",
            totalOwed: 0,
            oldestOrderDate: "-"
          };
        }

        summaryMap[po.supplierId].totalOwed += owed;

        // track oldest outstanding order date
        const currentOldest = summaryMap[po.supplierId].oldestOrderDate;
        if (currentOldest === "-" || new Date(po.date) < new Date(currentOldest)) {
          summaryMap[po.supplierId].oldestOrderDate = po.date;
        }
      }
    }
  });

  const report = Object.values(summaryMap).filter(r => r.totalOwed > 0);
  res.json(report);
});

// Report 2: Item Pending Delivery
app.get("/api/purchase/reports/pending-delivery", (req, res) => {
  // Shows items ordered but not fully received. Grouped by item.
  // Shows: total ordered quantity, total received quantity, pending quantity,
  // how many different suppliers have open orders, earliest expected delivery date.
  const pendingMap: Record<string, { productId: string; code: string; name: string; color?: string; size?: string; totalOrdered: number; totalReceived: number; pendingQty: number; supplierIds: Set<string>; supplierCount: number; earliestExpectedDate: string }> = {};

  purchaseOrders.forEach(po => {
    if (po.status === "Confirmed") {
      po.items.forEach(item => {
        const pending = item.quantity - item.receivedQuantity;
        if (pending > 0) {
          if (!pendingMap[item.productId]) {
            pendingMap[item.productId] = {
              productId: item.productId,
              code: item.code,
              name: item.name,
              color: item.color,
              size: item.size,
              totalOrdered: 0,
              totalReceived: 0,
              pendingQty: 0,
              supplierIds: new Set<string>(),
              supplierCount: 0,
              earliestExpectedDate: "-"
            };
          }

          const entry = pendingMap[item.productId];
          entry.totalOrdered += item.quantity;
          entry.totalReceived += item.receivedQuantity;
          entry.pendingQty += pending;
          entry.supplierIds.add(po.supplierId);
          entry.supplierCount = entry.supplierIds.size;

          // track earliest expected date
          if (entry.earliestExpectedDate === "-" || new Date(po.expectedDeliveryDate) < new Date(entry.earliestExpectedDate)) {
            entry.earliestExpectedDate = po.expectedDeliveryDate;
          }
        }
      });
    }
  });

  // Convert Set to count for response serializing
  const report = Object.values(pendingMap).map(e => {
    const { supplierIds, ...rest } = e;
    return {
      ...rest,
      supplierCount: supplierIds.size
    };
  });

  res.json(report);
});

// ── SMRITI Extensible Attribute Master Backend Modules & APIs ───────────────

import { AttributeDefinition, AttributeGroup, VariantTemplate, CategoryAttributeGroupMapping } from "./src/types.js";

// Extensible Attributes In-Memory DB
let attributeDefinitions: AttributeDefinition[] = [
  { id: "attr-color", name: "Color", label: "Color", dataType: "select", isVariantDimension: true, isMandatory: true, validValues: ["Navy", "Indigo", "White", "Charcoal", "Black", "Red", "Blue", "Gold", "Silver"] },
  { id: "attr-size", name: "Size", label: "Size / Dimensions", dataType: "select", isVariantDimension: true, isMandatory: true, validValues: ["36", "37", "38", "39", "40", "41", "42", "XS", "S", "M", "L", "XL", "XXL", "3XL", "OS", "9", "10"] },
  { id: "attr-fabric", name: "Fabric", label: "Fabric Material", dataType: "select", isVariantDimension: false, isMandatory: false, validValues: ["Cotton", "Denim", "Leather", "Silk", "Polyester", "Chiffon", "Georgette"] },
  { id: "attr-sole", name: "Sole Type", label: "Sole Material", dataType: "select", isVariantDimension: false, isMandatory: false, validValues: ["Rubber", "PU", "PVC", "Leather"] },
  { id: "attr-molecule", name: "Molecule", label: "Active Ingredient / Molecule", dataType: "text", isVariantDimension: false, isMandatory: false, validValues: [] },
  { id: "attr-packsize", name: "Pack Size", label: "Pack Size / Vol", dataType: "select", isVariantDimension: true, isMandatory: true, validValues: ["10 Tablets", "15 Tablets", "100 ml", "500 ml", "1 kg"] },
  { id: "attr-purity", name: "Purity", label: "Metal Purity", dataType: "select", isVariantDimension: true, isMandatory: true, validValues: ["18k", "22k", "24k"] },
  { id: "attr-finish", name: "Finish", label: "Surface Finish", dataType: "select", isVariantDimension: false, isMandatory: false, validValues: ["Polished", "Matte", "Brushed", "Anodized"] }
];

let attributeGroups: AttributeGroup[] = [
  { id: "grp-apparel", name: "Apparel Basic", attributeIds: ["attr-color", "attr-size", "attr-fabric"], gridColumnAttributeId: "attr-size", gridRowAttributeId: "attr-color" },
  { id: "grp-footwear", name: "Footwear Standard", attributeIds: ["attr-color", "attr-size", "attr-sole"], gridColumnAttributeId: "attr-size", gridRowAttributeId: "attr-color" },
  { id: "grp-pharmacy", name: "Pharmacy Medicines", attributeIds: ["attr-molecule", "attr-packsize"], gridColumnAttributeId: "attr-packsize", gridRowAttributeId: "attr-molecule" },
  { id: "grp-jewellery", name: "Jewellery Standard", attributeIds: ["attr-purity", "attr-fabric"], gridColumnAttributeId: "attr-purity", gridRowAttributeId: "attr-fabric" }
];

let variantTemplates: VariantTemplate[] = [
  { id: "vt-classic-tshirt", styleCode: "TSH-COT", name: "Classic Cotton T-Shirt", brand: "SMRITI", category: "Apparel", hsnCode: "61091000", basePrice: 799, baseMrp: 799, gstPercentage: 18, attributeGroupId: "grp-apparel", pricingMode: "Fixed", trackingMode: "Standard" },
  { id: "vt-premium-denim", styleCode: "DEN-SLM", name: "Premium Slim Fit Denim", brand: "SMRITI", category: "Apparel", hsnCode: "62034200", basePrice: 1899, baseMrp: 1899, gstPercentage: 18, attributeGroupId: "grp-apparel", pricingMode: "Fixed", trackingMode: "Standard" },
  { id: "vt-retro-sneaker", styleCode: "SNE-LTH", name: "Retro Leather Sneakers", brand: "SMRITI", category: "Footwear", hsnCode: "64039190", basePrice: 3499, baseMrp: 3499, gstPercentage: 18, attributeGroupId: "grp-footwear", pricingMode: "Fixed", trackingMode: "Standard" },
  { id: "vt-heritage-hoodie", styleCode: "SMR-HD", name: "SMRITI Heritage Hoodie", brand: "SMRITI", category: "Apparel", hsnCode: "61102000", basePrice: 2499, baseMrp: 2499, gstPercentage: 18, attributeGroupId: "grp-apparel", pricingMode: "Fixed", trackingMode: "Standard" },
  { id: "vt-monogram-cap", styleCode: "CAP-LOG", name: "SMRITI Monogram Cap", brand: "SMRITI", category: "Accessories", hsnCode: "65050090", basePrice: 499, baseMrp: 499, gstPercentage: 18, attributeGroupId: "grp-apparel", pricingMode: "Fixed", trackingMode: "Standard" }
];

let categoryAttributeGroupMappings: CategoryAttributeGroupMapping[] = [
  { category: "Apparel", attributeGroupId: "grp-apparel" },
  { category: "Footwear", attributeGroupId: "grp-footwear" },
  { category: "Pharmacy", attributeGroupId: "grp-pharmacy" },
  { category: "Jewellery", attributeGroupId: "grp-jewellery" }
];

// Map preloaded products with attributes on startup
products.forEach(p => {
  p.pricingMode = "Fixed";
  p.trackingMode = "Standard";
  if (p.category === "Apparel") {
    p.variantTemplateId = p.code.startsWith("TSH-COT") ? "vt-classic-tshirt" : 
                           p.code.startsWith("DEN-SLM") ? "vt-premium-denim" : 
                           p.code.startsWith("SMR-HD") ? "vt-heritage-hoodie" : undefined;
    p.attributes = {
      "Color": p.color || "Navy",
      "Size": p.size || "M",
      "Fabric": p.code.startsWith("DEN-SLM") ? "Denim" : "Cotton"
    };
  } else if (p.category === "Footwear") {
    p.variantTemplateId = "vt-retro-sneaker";
    p.attributes = {
      "Color": p.color || "White",
      "Size": p.size || "9",
      "Sole Type": "Rubber"
    };
  } else if (p.category === "Accessories") {
    p.variantTemplateId = "vt-monogram-cap";
    p.attributes = {
      "Color": p.color || "Black",
      "Size": p.size || "OS",
      "Fabric": "Polyester"
    };
  }
});

// ── ENDPOINTS ──

// 1. Attribute Definitions CRUD
app.get("/api/attributes/definitions", (req, res) => {
  res.json(attributeDefinitions);
});

app.post("/api/attributes/definitions", (req, res) => {
  const { name, label, dataType, isVariantDimension, isMandatory, validValues } = req.body;
  if (!name || !label || !dataType) {
    return res.status(400).json({ error: "Name, Label, and DataType are required." });
  }
  const id = `attr-${name.toLowerCase().replace(/[^a-z0-9]/g, "")}-${Date.now()}`;
  const newAttr: AttributeDefinition = {
    id,
    name,
    label,
    dataType,
    isVariantDimension: !!isVariantDimension,
    isMandatory: !!isMandatory,
    validValues: validValues || []
  };
  attributeDefinitions.push(newAttr);
  res.json(newAttr);
});

app.put("/api/attributes/definitions/:id", (req, res) => {
  const { id } = req.params;
  const { name, label, dataType, isVariantDimension, isMandatory, validValues } = req.body;
  const idx = attributeDefinitions.findIndex(a => a.id === id);
  if (idx === -1) return res.status(404).json({ error: "Attribute definition not found" });

  if (name !== undefined) attributeDefinitions[idx].name = name;
  if (label !== undefined) attributeDefinitions[idx].label = label;
  if (dataType !== undefined) attributeDefinitions[idx].dataType = dataType;
  if (isVariantDimension !== undefined) attributeDefinitions[idx].isVariantDimension = !!isVariantDimension;
  if (isMandatory !== undefined) attributeDefinitions[idx].isMandatory = !!isMandatory;
  if (validValues !== undefined) attributeDefinitions[idx].validValues = validValues;

  res.json(attributeDefinitions[idx]);
});

app.delete("/api/attributes/definitions/:id", (req, res) => {
  const { id } = req.params;
  const idx = attributeDefinitions.findIndex(a => a.id === id);
  if (idx === -1) return res.status(404).json({ error: "Attribute definition not found" });
  attributeDefinitions.splice(idx, 1);
  res.json({ success: true });
});

// 2. Attribute Groups CRUD
app.get("/api/attributes/groups", (req, res) => {
  res.json(attributeGroups);
});

app.post("/api/attributes/groups", (req, res) => {
  const { name, attributeIds, gridColumnAttributeId, gridRowAttributeId } = req.body;
  if (!name || !attributeIds || !Array.isArray(attributeIds)) {
    return res.status(400).json({ error: "Name and attributeIds list are required." });
  }
  const id = `grp-${name.toLowerCase().replace(/[^a-z0-9]/g, "")}-${Date.now()}`;
  const newGroup: AttributeGroup = {
    id,
    name,
    attributeIds,
    gridColumnAttributeId,
    gridRowAttributeId
  };
  attributeGroups.push(newGroup);
  res.json(newGroup);
});

app.put("/api/attributes/groups/:id", (req, res) => {
  const { id } = req.params;
  const { name, attributeIds, gridColumnAttributeId, gridRowAttributeId } = req.body;
  const idx = attributeGroups.findIndex(g => g.id === id);
  if (idx === -1) return res.status(404).json({ error: "Group not found" });

  if (name !== undefined) attributeGroups[idx].name = name;
  if (attributeIds !== undefined) attributeGroups[idx].attributeIds = attributeIds;
  if (gridColumnAttributeId !== undefined) attributeGroups[idx].gridColumnAttributeId = gridColumnAttributeId;
  if (gridRowAttributeId !== undefined) attributeGroups[idx].gridRowAttributeId = gridRowAttributeId;

  res.json(attributeGroups[idx]);
});

app.delete("/api/attributes/groups/:id", (req, res) => {
  const { id } = req.params;
  const idx = attributeGroups.findIndex(g => g.id === id);
  if (idx === -1) return res.status(404).json({ error: "Group not found" });
  attributeGroups.splice(idx, 1);
  res.json({ success: true });
});

// 3. Variant Templates CRUD
app.get("/api/attributes/templates", (req, res) => {
  res.json(variantTemplates);
});

app.post("/api/attributes/templates", (req, res) => {
  const { styleCode, name, brand, category, hsnCode, basePrice, baseMrp, gstPercentage, attributeGroupId, pricingMode, trackingMode } = req.body;
  if (!styleCode || !name || !attributeGroupId) {
    return res.status(400).json({ error: "Style Code, Name, and Attribute Group are required." });
  }
  if (variantTemplates.some(t => t.styleCode === styleCode)) {
    return res.status(400).json({ error: `Template Style Code ${styleCode} already exists.` });
  }
  const id = `vt-${Date.now()}`;
  const newTemplate: VariantTemplate = {
    id,
    styleCode,
    name,
    brand: brand || "SMRITI",
    category: category || "General",
    hsnCode: hsnCode || "61091000",
    basePrice: parseFloat(basePrice) || 0,
    baseMrp: parseFloat(baseMrp) || parseFloat(basePrice) || 0,
    gstPercentage: parseFloat(gstPercentage) || 18,
    attributeGroupId,
    pricingMode: pricingMode || "Fixed",
    trackingMode: trackingMode || "Standard"
  };
  variantTemplates.push(newTemplate);
  res.json(newTemplate);
});

app.put("/api/attributes/templates/:id", (req, res) => {
  const { id } = req.params;
  const { styleCode, name, brand, category, hsnCode, basePrice, baseMrp, gstPercentage, attributeGroupId, pricingMode, trackingMode } = req.body;
  const idx = variantTemplates.findIndex(t => t.id === id);
  if (idx === -1) return res.status(404).json({ error: "Template not found" });

  if (styleCode !== undefined) variantTemplates[idx].styleCode = styleCode;
  if (name !== undefined) variantTemplates[idx].name = name;
  if (brand !== undefined) variantTemplates[idx].brand = brand;
  if (category !== undefined) variantTemplates[idx].category = category;
  if (hsnCode !== undefined) variantTemplates[idx].hsnCode = hsnCode;
  if (basePrice !== undefined) variantTemplates[idx].basePrice = parseFloat(basePrice) || 0;
  if (baseMrp !== undefined) variantTemplates[idx].baseMrp = parseFloat(baseMrp) || 0;
  if (gstPercentage !== undefined) variantTemplates[idx].gstPercentage = parseFloat(gstPercentage) || 18;
  if (attributeGroupId !== undefined) variantTemplates[idx].attributeGroupId = attributeGroupId;
  if (pricingMode !== undefined) variantTemplates[idx].pricingMode = pricingMode;
  if (trackingMode !== undefined) variantTemplates[idx].trackingMode = trackingMode;

  res.json(variantTemplates[idx]);
});

app.delete("/api/attributes/templates/:id", (req, res) => {
  const { id } = req.params;
  const idx = variantTemplates.findIndex(t => t.id === id);
  if (idx === -1) return res.status(404).json({ error: "Template not found" });
  variantTemplates.splice(idx, 1);
  res.json({ success: true });
});

// 4. Generate variants under a template
app.post("/api/attributes/templates/:id/generate-variants", (req, res) => {
  const { id } = req.params;
  const { variants } = req.body; // array of { attributes: { "Color": "Navy", "Size": "M" }, price, mrp, stock, weightGrams, batches, serialNumbers }
  const template = variantTemplates.find(t => t.id === id);
  if (!template) return res.status(404).json({ error: "Template not found" });

  const group = attributeGroups.find(g => g.id === template.attributeGroupId);
  if (!group) return res.status(400).json({ error: "Linked Attribute Group not found" });

  const createdVariants: Product[] = [];

  variants.forEach((v: any, index: number) => {
    // Order attributes according to group order for item code construction
    const codeParts = [template.styleCode];
    group.attributeIds.forEach(attrId => {
      const attrDef = attributeDefinitions.find(d => d.id === attrId);
      if (attrDef && attrDef.isVariantDimension) {
        const val = v.attributes[attrDef.name];
        if (val) {
          const codeVal = val.toString().toUpperCase().replace(/[^A-Z0-9]/g, "");
          codeParts.push(codeVal);
        }
      }
    });

    const constructedCode = codeParts.join("-");
    const barcode = v.barcode || `SMR-B${Math.floor(100000 + Math.random() * 900000)}`;
    
    // Check collision
    const existingIdx = products.findIndex(p => p.code === constructedCode);
    if (existingIdx !== -1) {
      // Update existing
      products[existingIdx].stock = parseInt(v.stock) || 0;
      products[existingIdx].price = parseFloat(v.price) || template.basePrice;
      products[existingIdx].mrp = parseFloat(v.mrp) || template.baseMrp;
      products[existingIdx].attributes = { ...products[existingIdx].attributes, ...v.attributes };
      createdVariants.push(products[existingIdx]);
    } else {
      // Create new
      const newProduct: Product = {
        id: `p-var-${Date.now()}-${index}`,
        code: constructedCode,
        name: template.name,
        price: parseFloat(v.price) || template.basePrice,
        mrp: parseFloat(v.mrp) || template.baseMrp || parseFloat(v.price) || template.basePrice,
        stock: parseInt(v.stock) || 0,
        category: template.category,
        barcode,
        styleCode: template.styleCode,
        gstPercentage: template.gstPercentage,
        attributes: v.attributes,
        pricingMode: template.pricingMode,
        trackingMode: template.trackingMode,
        variantTemplateId: template.id
      };

      if (template.pricingMode === "Weight-based") {
        newProduct.weightGrams = parseFloat(v.weightGrams) || 10;
      }
      if (template.trackingMode === "Batch") {
        newProduct.batches = v.batches || [
          { batchNo: `BAT-${constructedCode}-${Math.floor(100 + Math.random() * 900)}`, mfgDate: new Date().toISOString().slice(0, 10), expiryDate: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10), stock: parseInt(v.stock) || 0 }
        ];
      }
      if (template.trackingMode === "Serial") {
        newProduct.serialNumbers = v.serialNumbers || Array.from({ length: parseInt(v.stock) || 0 }, (_, i) => `SR-${constructedCode}-${1000 + i}`);
      }

      products.push(newProduct);
      createdVariants.push(newProduct);
    }
  });

  res.json({ success: true, count: createdVariants.length, variants: createdVariants });
});

// 5. Dynamic CSV Template Download & Import
app.get("/api/attributes/import-headers/:groupId", (req, res) => {
  const { groupId } = req.params;
  const group = attributeGroups.find(g => g.id === groupId);
  if (!group) return res.status(404).json({ error: "Group not found" });

  const headers = [
    "TemplateStyleCode", "BaseName", "Brand", "Category", "HSN", 
    "Price", "MRP", "GST_Percentage", "PricingMode", "TrackingMode", "Stock", "Barcode"
  ];
  
  group.attributeIds.forEach(attrId => {
    const attrDef = attributeDefinitions.find(d => d.id === attrId);
    if (attrDef) {
      headers.push(`Attr_${attrDef.name}`);
    }
  });

  res.json({ headers });
});

app.post("/api/attributes/import-validate", (req, res) => {
  const { groupId, rows } = req.body;
  const group = attributeGroups.find(g => g.id === groupId);
  if (!group) return res.status(404).json({ error: "Group not found" });

  const results: any[] = [];
  let hasErrors = false;

  rows.forEach((row: any, index: number) => {
    const rowErrors: string[] = [];

    if (!row.TemplateStyleCode) rowErrors.push("TemplateStyleCode is required");
    if (!row.BaseName) rowErrors.push("BaseName is required");
    if (row.Price === undefined || isNaN(parseFloat(row.Price))) rowErrors.push("Price must be a valid number");

    group.attributeIds.forEach(attrId => {
      const attrDef = attributeDefinitions.find(d => d.id === attrId);
      if (attrDef) {
        const val = row[`Attr_${attrDef.name}`];
        if (attrDef.isMandatory && !val) {
          rowErrors.push(`Mandatory attribute '${attrDef.label}' is missing.`);
        }
        if (val && attrDef.dataType === "select" && attrDef.validValues.length > 0) {
          if (!attrDef.validValues.includes(val)) {
            rowErrors.push(`Value '${val}' is not valid for '${attrDef.label}'. Allowed: ${attrDef.validValues.join(", ")}`);
          }
        }
      }
    });

    if (rowErrors.length > 0) hasErrors = true;
    results.push({
      index,
      row,
      errors: rowErrors,
      valid: rowErrors.length === 0
    });
  });

  res.json({ hasErrors, results });
});

app.post("/api/attributes/import-commit", (req, res) => {
  const { groupId, rows } = req.body;
  const group = attributeGroups.find(g => g.id === groupId);
  if (!group) return res.status(404).json({ error: "Group not found" });

  const createdProducts: Product[] = [];

  rows.forEach((row: any, index: number) => {
    let template = variantTemplates.find(t => t.styleCode === row.TemplateStyleCode);
    if (!template) {
      template = {
        id: `vt-${Date.now()}-${index}`,
        styleCode: row.TemplateStyleCode,
        name: row.BaseName,
        brand: row.Brand || "SMRITI",
        category: row.Category || "General",
        hsnCode: row.HSN || "61091000",
        basePrice: parseFloat(row.Price) || 0,
        baseMrp: parseFloat(row.MRP) || parseFloat(row.Price) || 0,
        gstPercentage: parseFloat(row.GST_Percentage) || 18,
        attributeGroupId: group.id,
        pricingMode: row.PricingMode || "Fixed",
        trackingMode: row.TrackingMode || "Standard"
      };
      variantTemplates.push(template);
    }

    const attrs: Record<string, string> = {};
    const codeParts = [template.styleCode];

    group.attributeIds.forEach(attrId => {
      const attrDef = attributeDefinitions.find(d => d.id === attrId);
      if (attrDef) {
        const val = row[`Attr_${attrDef.name}`];
        if (val) {
          attrs[attrDef.name] = val;
          if (attrDef.isVariantDimension) {
            codeParts.push(val.toString().toUpperCase().replace(/[^A-Z0-9]/g, ""));
          }
        }
      }
    });

    const constructedCode = codeParts.join("-");
    const barcode = row.Barcode || `SMR-B${Math.floor(100000 + Math.random() * 900000)}`;

    const existingIdx = products.findIndex(p => p.code === constructedCode);
    if (existingIdx !== -1) {
      products[existingIdx].stock = parseInt(row.Stock) || 0;
      products[existingIdx].price = parseFloat(row.Price) || template.basePrice;
      products[existingIdx].mrp = parseFloat(row.MRP) || template.baseMrp;
      products[existingIdx].attributes = { ...products[existingIdx].attributes, ...attrs };
      createdProducts.push(products[existingIdx]);
    } else {
      const newProduct: Product = {
        id: `p-import-${Date.now()}-${index}`,
        code: constructedCode,
        name: template.name,
        price: parseFloat(row.Price) || template.basePrice,
        mrp: parseFloat(row.MRP) || template.baseMrp || parseFloat(row.Price) || template.basePrice,
        stock: parseInt(row.Stock) || 0,
        category: template.category,
        barcode,
        styleCode: template.styleCode,
        gstPercentage: template.gstPercentage,
        attributes: attrs,
        pricingMode: template.pricingMode,
        trackingMode: template.trackingMode,
        variantTemplateId: template.id
      };

      if (template.pricingMode === "Weight-based") {
        newProduct.weightGrams = parseFloat(row.WeightGrams) || 100;
      }
      if (template.trackingMode === "Batch") {
        newProduct.batches = [
          { batchNo: `BAT-${constructedCode}-IMP`, mfgDate: new Date().toISOString().slice(0, 10), expiryDate: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10), stock: parseInt(row.Stock) || 0 }
        ];
      }
      if (template.trackingMode === "Serial") {
        newProduct.serialNumbers = Array.from({ length: parseInt(row.Stock) || 0 }, (_, i) => `SR-${constructedCode}-${1000 + i}`);
      }

      products.push(newProduct);
      createdProducts.push(newProduct);
    }
  });

  res.json({ success: true, count: createdProducts.length });
});

// 6. Attribute Reports API
app.get("/api/attributes/reports/sales-by-attribute", (req, res) => {
  const { attributeName } = req.query;
  if (!attributeName) return res.status(400).json({ error: "attributeName parameter is required." });

  const stats: Record<string, { value: string; quantitySold: number; revenue: number }> = {};

  bills.forEach(bill => {
    bill.items.forEach(item => {
      const prod = products.find(p => p.id === item.product.id) || item.product;
      const attrVal = prod.attributes ? prod.attributes[attributeName as string] : (attributeName === "Color" ? prod.color : (attributeName === "Size" ? prod.size : undefined));

      const key = attrVal || "Solid / Free Size";
      if (!stats[key]) {
        stats[key] = { value: key, quantitySold: 0, revenue: 0 };
      }
      stats[key].quantitySold += item.quantity;
      stats[key].revenue += item.product.price * item.quantity;
    });
  });

  if (Object.keys(stats).length === 0) {
    products.forEach((prod, index) => {
      const attrVal = prod.attributes ? prod.attributes[attributeName as string] : (attributeName === "Color" ? prod.color : (attributeName === "Size" ? prod.size : undefined));
      const key = attrVal || "Solid / Free Size";
      if (!stats[key]) {
        stats[key] = { value: key, quantitySold: 0, revenue: 0 };
      }
      const qty = (15 + (index * 7)) % 40 + 5;
      stats[key].quantitySold += qty;
      stats[key].revenue += prod.price * qty;
    });
  }

  res.json(Object.values(stats));
});

app.get("/api/attributes/reports/stock-by-attribute", (req, res) => {
  const { attributeName } = req.query;
  if (!attributeName) return res.status(400).json({ error: "attributeName parameter is required." });

  const stats: Record<string, { value: string; stockCount: number; valuation: number; productCount: number }> = {};

  products.forEach(prod => {
    const attrVal = prod.attributes ? prod.attributes[attributeName as string] : (attributeName === "Color" ? prod.color : (attributeName === "Size" ? prod.size : undefined));
    const key = attrVal || "Solid / Free Size";

    if (!stats[key]) {
      stats[key] = { value: key, stockCount: 0, valuation: 0, productCount: 0 };
    }
    stats[key].stockCount += prod.stock;
    stats[key].valuation += prod.stock * prod.price;
    stats[key].productCount += 1;
  });

  res.json(Object.values(stats));
});

// Category mappings endpoints
app.get("/api/attributes/category-mappings", (req, res) => {
  res.json(categoryAttributeGroupMappings);
});

app.post("/api/attributes/category-mappings", (req, res) => {
  const { category, attributeGroupId } = req.body;
  const idx = categoryAttributeGroupMappings.findIndex(m => m.category === category);
  if (idx !== -1) {
    categoryAttributeGroupMappings[idx].attributeGroupId = attributeGroupId;
  } else {
    categoryAttributeGroupMappings.push({ category, attributeGroupId });
  }
  res.json({ success: true, category, attributeGroupId });
});

// SMRITI Barcode Studio Interfaces
interface PrintTemplate {
  id: string;
  title: string;
  labelSize: "50x25" | "50x30" | "75x50" | "100x50";
  printerLanguage: "ZPL" | "TSPL";
  printerFamily: "ZPL" | "TSPL";
  version?: string;
  isActive: boolean;
  isDefaultSize: boolean;
  rawPRN: string;
  fieldMappings?: { token: string; source_field: string }[];
}

interface PrintProfile {
  id: string;
  name: string;
  templateId: string;
  printerIP: string;
  printerPort: number;
  dpi: number;
  copies: number;
  labelSize: string;
  isDefault: boolean;
}

// SMRITI Barcode Studio In-Memory Database
let printTemplates: PrintTemplate[] = [
  {
    id: "t1",
    title: "Footwear 50x25 Zebra",
    labelSize: "50x25",
    printerLanguage: "ZPL",
    printerFamily: "ZPL",
    version: "2.1.0",
    isActive: true,
    isDefaultSize: true,
    rawPRN: "^XA\n^FO50,50^A0N,36,36^FD{item_name}^FS\n^FO50,100^A0N,24,24^FDSKU: {item_code}^FS\n^FO50,140^A0N,24,24^FDSize: {size}  Color: {color}^FS\n^FO50,180^A0N,24,24^FDMRP: {mrp} INR^FS\n^FO50,220^BY2\n^BCN,60,Y,N,N\n^FD{barcode}^FS\n^XZ",
    fieldMappings: [
      { token: "item_name", source_field: "name" },
      { token: "item_code", source_field: "code" },
      { token: "size", source_field: "size" },
      { token: "color", source_field: "color" },
      { token: "mrp", source_field: "mrp" },
      { token: "barcode", source_field: "barcode" }
    ]
  },
  {
    id: "t2",
    title: "Standard TSPL 50x30 Label",
    labelSize: "50x30",
    printerLanguage: "TSPL",
    printerFamily: "TSPL",
    version: "1.0.0",
    isActive: true,
    isDefaultSize: true,
    rawPRN: "SIZE 50 mm, 30 mm\nGAP 2 mm\nDIRECTION 1\nCLS\nTEXT 50,20,\"3\",0,1,1,\"{item_name}\"\nTEXT 50,60,\"2\",0,1,1,\"SKU: {item_code}\"\nTEXT 50,90,\"2\",0,1,1,\"Price: {mrp}\"\nBARCODE 50,130,\"128\",60,1,0,2,2,\"{barcode}\"\nPRINT 1,1",
    fieldMappings: [
      { token: "item_name", source_field: "name" },
      { token: "item_code", source_field: "code" },
      { token: "mrp", source_field: "mrp" },
      { token: "barcode", source_field: "barcode" }
    ]
  }
];

let printProfiles: PrintProfile[] = [
  {
    id: "p1",
    name: "Billing Zebra 1",
    templateId: "t1",
    printerIP: "192.168.1.150",
    printerPort: 9100,
    dpi: 203,
    copies: 1,
    labelSize: "50x25",
    isDefault: true
  }
];

// Barcode validation helper
const validateBarcode = (code: string): string | null => {
  if (!code || code.trim() === "") return "Barcode cannot be empty";
  if (code.length < 3 || code.length > 30) return "Barcode length must be between 3 and 30 characters";
  const validPattern = /^[A-Za-z0-9\-_]+$/;
  if (!validPattern.test(code)) {
    return "Barcode contains invalid characters. Only A-Z, a-z, 0-9, hyphens (-) and underscores (_) are allowed.";
  }
  return null;
};

// Barcode Studio Endpoints
app.get("/api/barcode/templates", (req, res) => {
  res.json(printTemplates);
});

app.post("/api/barcode/templates", (req, res) => {
  const { title, labelSize, printerLanguage, printerFamily, version, isActive, isDefaultSize, rawPRN, fieldMappings } = req.body;
  if (!title || !labelSize || !printerLanguage || !printerFamily || !rawPRN) {
    return res.status(400).json({ error: "Missing required fields for template creation" });
  }

  const newTemplate: PrintTemplate = {
    id: `t-${Date.now()}`,
    title,
    labelSize,
    printerLanguage,
    printerFamily,
    version: version || "1.0.0",
    isActive: typeof isActive === "boolean" ? isActive : true,
    isDefaultSize: typeof isDefaultSize === "boolean" ? isDefaultSize : false,
    rawPRN,
    fieldMappings: Array.isArray(fieldMappings) ? fieldMappings : []
  };

  if (newTemplate.isDefaultSize) {
    // Unset other defaults for the same size
    printTemplates.forEach(t => {
      if (t.labelSize === labelSize) {
        t.isDefaultSize = false;
      }
    });
  }

  printTemplates.push(newTemplate);
  res.json(newTemplate);
});

app.put("/api/barcode/templates/:id", (req, res) => {
  const { id } = req.params;
  const idx = printTemplates.findIndex(t => t.id === id);
  if (idx === -1) return res.status(404).json({ error: "Template not found" });

  const { title, labelSize, printerLanguage, printerFamily, version, isActive, isDefaultSize, rawPRN, fieldMappings } = req.body;

  if (title !== undefined) printTemplates[idx].title = title;
  if (labelSize !== undefined) printTemplates[idx].labelSize = labelSize;
  if (printerLanguage !== undefined) printTemplates[idx].printerLanguage = printerLanguage;
  if (printerFamily !== undefined) printTemplates[idx].printerFamily = printerFamily;
  if (version !== undefined) printTemplates[idx].version = version;
  if (isActive !== undefined) printTemplates[idx].isActive = isActive;
  if (rawPRN !== undefined) printTemplates[idx].rawPRN = rawPRN;
  if (fieldMappings !== undefined) printTemplates[idx].fieldMappings = fieldMappings;

  if (isDefaultSize !== undefined) {
    printTemplates[idx].isDefaultSize = isDefaultSize;
    if (isDefaultSize) {
      printTemplates.forEach(t => {
        if (t.id !== id && t.labelSize === printTemplates[idx].labelSize) {
          t.isDefaultSize = false;
        }
      });
    }
  }

  res.json(printTemplates[idx]);
});

app.delete("/api/barcode/templates/:id", (req, res) => {
  const { id } = req.params;
  const idx = printTemplates.findIndex(t => t.id === id);
  if (idx === -1) return res.status(404).json({ error: "Template not found" });

  printTemplates.splice(idx, 1);
  res.json({ success: true });
});

app.get("/api/barcode/profiles", (req, res) => {
  res.json(printProfiles);
});

app.post("/api/barcode/profiles", (req, res) => {
  const { name, templateId, printerIP, printerPort, dpi, copies, labelSize, isDefault } = req.body;
  if (!name || !templateId || !printerIP || !printerPort) {
    return res.status(400).json({ error: "Missing required profile fields" });
  }

  const newProfile: PrintProfile = {
    id: `p-${Date.now()}`,
    name,
    templateId,
    printerIP,
    printerPort: parseInt(printerPort) || 9100,
    dpi: parseInt(dpi) || 203,
    copies: parseInt(copies) || 1,
    labelSize: labelSize || "50x25",
    isDefault: typeof isDefault === "boolean" ? isDefault : false
  };

  if (newProfile.isDefault) {
    printProfiles.forEach(p => p.isDefault = false);
  }

  printProfiles.push(newProfile);
  res.json(newProfile);
});

app.put("/api/barcode/profiles/:id", (req, res) => {
  const { id } = req.params;
  const idx = printProfiles.findIndex(p => p.id === id);
  if (idx === -1) return res.status(404).json({ error: "Profile not found" });

  const { name, templateId, printerIP, printerPort, dpi, copies, labelSize, isDefault } = req.body;

  if (name !== undefined) printProfiles[idx].name = name;
  if (templateId !== undefined) printProfiles[idx].templateId = templateId;
  if (printerIP !== undefined) printProfiles[idx].printerIP = printerIP;
  if (printerPort !== undefined) printProfiles[idx].printerPort = parseInt(printerPort) || 9100;
  if (dpi !== undefined) printProfiles[idx].dpi = parseInt(dpi) || 203;
  if (copies !== undefined) printProfiles[idx].copies = parseInt(copies) || 1;
  if (labelSize !== undefined) printProfiles[idx].labelSize = labelSize;

  if (isDefault !== undefined) {
    printProfiles[idx].isDefault = isDefault;
    if (isDefault) {
      printProfiles.forEach(p => {
        if (p.id !== id) p.isDefault = false;
      });
    }
  }

  res.json(printProfiles[idx]);
});

app.delete("/api/barcode/profiles/:id", (req, res) => {
  const { id } = req.params;
  const idx = printProfiles.findIndex(p => p.id === id);
  if (idx === -1) return res.status(404).json({ error: "Profile not found" });

  printProfiles.splice(idx, 1);
  res.json({ success: true });
});

// Barcode updates API for manual assignment
app.post("/api/barcode/products/:id/barcodes", (req, res) => {
  const { id } = req.params;
  const productIndex = products.findIndex(p => p.id === id);
  if (productIndex === -1) return res.status(404).json({ error: "Product not found" });

  const { primaryBarcode, secondaryBarcodes } = req.body;

  // Validate primary barcode
  if (primaryBarcode !== undefined) {
    const errorMsg = validateBarcode(primaryBarcode);
    if (errorMsg) return res.status(400).json({ error: errorMsg });

    // Collision check: cannot conflict with other items
    const collisionProduct = products.find(p => p.id !== id && (p.barcode === primaryBarcode || p.code === primaryBarcode || (p.secondaryBarcodes && p.secondaryBarcodes.includes(primaryBarcode))));
    if (collisionProduct) {
      return res.status(400).json({ error: `Barcode ${primaryBarcode} conflicts with existing item code/barcode in system: ${collisionProduct.code}` });
    }

    products[productIndex].barcode = primaryBarcode;
  }

  // Validate secondary barcodes
  if (secondaryBarcodes !== undefined && Array.isArray(secondaryBarcodes)) {
    for (const code of secondaryBarcodes) {
      const errorMsg = validateBarcode(code);
      if (errorMsg) return res.status(400).json({ error: `Secondary barcode error: ${errorMsg}` });

      const collisionProduct = products.find(p => p.id !== id && (p.barcode === code || p.code === code || (p.secondaryBarcodes && p.secondaryBarcodes.includes(code))));
      if (collisionProduct) {
        return res.status(400).json({ error: `Secondary barcode ${code} conflicts with existing item code/barcode in system: ${collisionProduct.code}` });
      }
    }

    products[productIndex].secondaryBarcodes = secondaryBarcodes;
  }

  res.json({ success: true, product: products[productIndex] });
});

// Mock print socket trigger
app.post("/api/barcode/print", (req, res) => {
  const { templateId, profileId, productId, copies, connectionMethod, printerIP, printerPort } = req.body;
  if (!templateId || !productId) {
    return res.status(400).json({ error: "Template and Product are required for print generation" });
  }

  const template = printTemplates.find(t => t.id === templateId);
  const product = products.find(p => p.id === productId);

  if (!template) return res.status(404).json({ error: "Print template not found" });
  if (!product) return res.status(404).json({ error: "Product not found" });

  // Token resolution (4-step style resolution and default fallbacks)
  const tokens: Record<string, string> = {
    item_code: product.code,
    item_name: product.name,
    brand: product.brand || "SMRITI Corp",
    barcode: product.barcode || product.code,
    mrp: product.mrp ? product.mrp.toFixed(2) : product.price.toFixed(2),
    size: product.size || "OS",
    color: product.color || "N/A",
    style_code: product.styleCode || product.code.split("-")[0],
    variant_template: product.variantTemplateId || "",
    pkd_date: new Date().toLocaleDateString("en-US", { month: "numeric", year: "2-digit" }),
    pack_size: "1",
    gender: "Unisex"
  };

  // style 4-step resolution
  let styleVal = "";
  if (product.variantTemplateId) {
    const vt = variantTemplates.find(v => v.id === product.variantTemplateId);
    if (vt) styleVal = vt.styleCode;
  }
  if (!styleVal && product.styleCode) {
    styleVal = product.styleCode;
  }
  if (!styleVal) {
    styleVal = product.code.includes("-") ? product.code.split("-")[0] : product.code;
  }
  tokens["style"] = styleVal;

  // Resolve template rawPRN with tokens
  let prnContent = template.rawPRN;
  
  // If Field Mappings JSON is present, let's filter/remap based on mappings
  if (template.fieldMappings && template.fieldMappings.length > 0) {
    const mappedTokens: Record<string, string> = {};
    template.fieldMappings.forEach(m => {
      const source = m.source_field;
      if (source === "name" || source === "item_name") mappedTokens[m.token] = product.name;
      else if (source === "code" || source === "item_code") mappedTokens[m.token] = product.code;
      else if (source === "mrp") mappedTokens[m.token] = (product.mrp || product.price).toString();
      else if (source === "barcode") mappedTokens[m.token] = product.barcode;
      else if (source === "color") mappedTokens[m.token] = product.color || "N/A";
      else if (source === "size") mappedTokens[m.token] = product.size || "OS";
      else if (source.startsWith("attribute:")) {
        const attrName = source.split(":")[1];
        mappedTokens[m.token] = product.color === attrName ? product.color : (product.size === attrName ? product.size : "N/A");
      } else {
        mappedTokens[m.token] = tokens[source] || "";
      }
    });

    // Replace mapped tokens in ZPL/TSPL
    Object.keys(mappedTokens).forEach(tok => {
      const regex = new RegExp(`{${tok}}`, "g");
      prnContent = prnContent.replace(regex, mappedTokens[tok]);
    });
  } else {
    // Normal standard tokens
    Object.keys(tokens).forEach(tok => {
      const regex = new RegExp(`{${tok}}`, "g");
      prnContent = prnContent.replace(regex, tokens[tok]);
    });
  }

  // Connection flow simulation
  let connectionLog = "";
  if (connectionMethod === "LAN") {
    const ip = printerIP || "192.168.1.150";
    const port = printerPort || 9100;
    connectionLog = `Opening raw TCP Socket to ${ip}:${port}...\n`;
    connectionLog += `Connected to ${template.printerFamily} label printer successfully.\n`;
    connectionLog += `Sending raw print data (${prnContent.length} bytes) to network print server...\n`;
    connectionLog += `Success! Sent ${copies} cop${copies > 1 ? "ies" : "y"} to print queue.`;
  } else {
    connectionLog = `Connecting to local QZ Tray server via WebSocket (wss://localhost:8181)...\n`;
    connectionLog += `QZ Tray version 2.2.1 active.\n`;
    connectionLog += `Connected successfully to client USB barcode printer.\n`;
    connectionLog += `Sending raw payload byte-stream...\n`;
    connectionLog += `Success! Sent ${copies} cop${copies > 1 ? "ies" : "y"} of label via QZ Tray client.`;
  }

  res.json({
    success: true,
    prn: prnContent,
    log: connectionLog,
    copies,
    product: { id: product.id, code: product.code, name: product.name }
  });
});

// SMRITI Layout Engine (SRLE) Preferences API
let layoutPreferences = {
  position: "left",
  collapsed: false,
  iconOnly: false,
  sidebarWidth: 260,
  lastWorkspace: "dashboard",
  collapsedGroups: [] as string[],
  favorites: ["pos", "sales"] as string[]
};

app.get("/api/layout/preferences", (req, res) => {
  res.json(layoutPreferences);
});

app.post("/api/layout/preferences", (req, res) => {
  const prefs = req.body;
  layoutPreferences = {
    position: prefs.position || "left",
    collapsed: typeof prefs.collapsed === "boolean" ? prefs.collapsed : false,
    iconOnly: typeof prefs.iconOnly === "boolean" ? prefs.iconOnly : (typeof prefs.icon_only === "boolean" ? prefs.icon_only : false),
    sidebarWidth: typeof prefs.sidebarWidth === "number" ? prefs.sidebarWidth : (typeof prefs.sidebar_width === "number" ? prefs.sidebar_width : 260),
    lastWorkspace: prefs.lastWorkspace || prefs.last_workspace || "dashboard",
    collapsedGroups: Array.isArray(prefs.collapsedGroups) ? prefs.collapsedGroups : (Array.isArray(prefs.collapsed_groups) ? prefs.collapsed_groups : []),
    favorites: Array.isArray(prefs.favorites) ? prefs.favorites : ["pos", "sales"]
  };
  res.json({ success: true, prefs: layoutPreferences });
});

// Vite Middleware & Static Servicing
const startServer = async () => {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[SMRITI] Retail OS running on http://localhost:${PORT}`);
  });
};

startServer();
