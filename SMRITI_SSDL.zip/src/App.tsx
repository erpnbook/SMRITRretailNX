import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Product, POSProfile, Shift, FieldInfo, Formula, PSVParty } from "./types.js";

// Import Layout Engine
import { LayoutEngineProvider, useLayoutEngine } from "./layout_engine/layout_store.tsx";
import { LayoutManager } from "./layout_engine/layout_manager.tsx";

// Import tabs components
import { DashboardTab } from "./components/DashboardTab.tsx";
import { PosTerminalTab } from "./components/PosTerminalTab.tsx";
import { FieldExplorerTab } from "./components/FieldExplorerTab.tsx";
import { FormulaRegistryTab } from "./components/FormulaRegistryTab.tsx";
import { PsvTab } from "./components/PsvTab.tsx";
import { PosProfilesTab } from "./components/PosProfilesTab.tsx";
import { SalesStudioTab } from "./components/SalesStudioTab.tsx";
import { ItemMasterTab } from "./components/ItemMasterTab.tsx";
import { WikiTab } from "./components/WikiTab.tsx";
import { PurchaseStudioTab } from "./components/PurchaseStudioTab.tsx";
import { BarcodeStudioTab } from "./components/BarcodeStudioTab.tsx";
import { ExplainModal } from "./components/ExplainModal.tsx";

interface AppNotification {
  id: string;
  title: string;
  message: string;
  type: "success" | "error";
}

const AppContent: React.FC = () => {
  const { preferences, addToRecentlyUsed } = useLayoutEngine();
  const activeTab = preferences.lastWorkspace || "dashboard";
  const setActiveTab = (tab: string) => {
    addToRecentlyUsed(tab);
  };

  const [products, setProducts] = useState<Product[]>([]);
  const [profiles, setProfiles] = useState<POSProfile[]>([]);
  const [shifts, setShifts] = useState<Shift[]>([]);
  const [fields, setFields] = useState<FieldInfo[]>([]);
  const [formulas, setFormulas] = useState<Formula[]>([]);
  const [psvParties, setPsvParties] = useState<PSVParty[]>([]);
  const [selectedFormula, setSelectedFormula] = useState<Formula | null>(null);

  // Notifications State
  const [notifications, setNotifications] = useState<AppNotification[]>([]);

  const addNotification = (title: string, message: string, type: "success" | "error" = "success") => {
    const id = Date.now().toString();
    setNotifications(prev => [...prev, { id, title, message, type }]);
    setTimeout(() => {
      setNotifications(prev => prev.filter(n => n.id !== id));
    }, 4000);
  };

  // Fetch initial system state
  const fetchSystemState = async () => {
    try {
      const [pRes, profRes, sRes, fldRes, formRes, psvRes] = await Promise.all([
        fetch("/api/pos/products"),
        fetch("/api/pos/profiles"),
        fetch("/api/pos/shifts"),
        fetch("/api/ufe/fields"),
        fetch("/api/formulas"),
        fetch("/api/psv/parties")
      ]);

      if (pRes.ok) setProducts(await pRes.json());
      if (profRes.ok) setProfiles(await profRes.json());
      if (sRes.ok) setShifts(await sRes.json());
      if (fldRes.ok) setFields(await fldRes.json());
      if (formRes.ok) setFormulas(await formRes.json());
      if (psvRes.ok) setPsvParties(await psvRes.json());
    } catch (error) {
      console.error("Critical error syncing system data:", error);
    }
  };

  useEffect(() => {
    fetchSystemState();
  }, []);

  return (
    <div className="relative w-full h-full">
      {/* Toast Notification Stack */}
      <div className="fixed top-4 right-4 z-50 space-y-2 pointer-events-none">
        <AnimatePresence>
          {notifications.map(n => (
            <motion.div
              key={n.id}
              initial={{ opacity: 0, y: -20, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.2 }}
              className={`pointer-events-auto p-4 rounded-xl shadow-2xl border flex items-start space-x-3 max-w-sm backdrop-blur ${
                n.type === "success" 
                  ? "bg-emerald-950 bg-opacity-95 border-emerald-500 text-emerald-200" 
                  : "bg-rose-950 bg-opacity-95 border-rose-500 text-rose-200"
              }`}
            >
              <span className="material-symbols-outlined mt-0.5">
                {n.type === "success" ? "check_circle" : "error"}
              </span>
              <div>
                <h5 className="font-bold text-xs uppercase tracking-wide font-display">{n.title}</h5>
                <p className="text-[11px] mt-0.5 leading-relaxed opacity-90">{n.message}</p>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* SMRITI Layout Manager Shell */}
      <LayoutManager activeTab={activeTab} onTabSelect={setActiveTab}>
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.15 }}
            className="h-full"
          >
            {activeTab === "dashboard" && (
              <DashboardTab 
                products={products}
                formulas={formulas}
                psvParties={psvParties}
                onSelectFormula={(f) => setSelectedFormula(f)}
              />
            )}

            {activeTab === "pos" && (
              <PosTerminalTab
                products={products}
                profiles={profiles}
                shifts={shifts}
                onRefreshData={fetchSystemState}
                onNotification={addNotification}
              />
            )}

            {activeTab === "ufe" && (
              <FieldExplorerTab fields={fields} />
            )}

            {activeTab === "formulas" && (
              <FormulaRegistryTab
                formulas={formulas}
                onSelectFormula={(f) => setSelectedFormula(f)}
              />
            )}

            {activeTab === "psv" && (
              <PsvTab psvParties={psvParties} />
            )}

            {activeTab === "sales" && (
              <SalesStudioTab
                products={products}
                onNotification={addNotification}
              />
            )}

            {activeTab === "purchase" && (
              <PurchaseStudioTab
                products={products}
                onRefreshProducts={fetchSystemState}
                onNotification={addNotification}
              />
            )}

            {activeTab === "item-master" && (
              <ItemMasterTab
                products={products}
                onRefreshProducts={fetchSystemState}
                onNotification={addNotification}
              />
            )}

            {activeTab === "profiles" && (
              <PosProfilesTab
                profiles={profiles}
                onRefreshData={fetchSystemState}
                onNotification={addNotification}
              />
            )}

            {activeTab === "wiki" && (
              <WikiTab
                onNotification={addNotification}
              />
            )}

            {activeTab === "barcode" && (
              <BarcodeStudioTab
                onNotification={addNotification}
              />
            )}
          </motion.div>
        </AnimatePresence>
      </LayoutManager>

      {/* Formula Explanation drawer portal overlay */}
      <ExplainModal 
        formula={selectedFormula} 
        onClose={() => setSelectedFormula(null)} 
      />
    </div>
  );
};

const App: React.FC = () => {
  return (
    <LayoutEngineProvider>
      <AppContent />
    </LayoutEngineProvider>
  );
};

export default App;
