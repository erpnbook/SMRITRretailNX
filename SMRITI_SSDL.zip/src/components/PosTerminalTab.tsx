import React, { useState, useEffect } from "react";
import { Product, POSProfile, Shift, Bill } from "../types";
import { SmritiScrollArea } from "./SmritiScrollArea.tsx";
import { AdvancedBillingEngine } from "./AdvancedBillingEngine.tsx";

interface PosTerminalTabProps {
  products: Product[];
  profiles: POSProfile[];
  shifts: Shift[];
  onRefreshData: () => void;
  onNotification: (title: string, msg: string, type: "success" | "error") => void;
}

export const PosTerminalTab: React.FC<PosTerminalTabProps> = ({
  products,
  profiles,
  shifts,
  onRefreshData,
  onNotification
}) => {
  const [activeProfileId, setActiveProfileId] = useState<string>("");
  const [openingBalance, setOpeningBalance] = useState("5000");
  const [activeShift, setActiveShift] = useState<Shift | null>(null);

  // POS State
  const [cart, setCart] = useState<{ product: Product; quantity: number }[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [customerName, setCustomerName] = useState("Walk-In Customer");
  const [cashTendered, setCashTendered] = useState("");
  const [heldBills, setHeldBills] = useState<Bill[]>([]);
  const [closingBalance, setClosingBalance] = useState("");
  const [showCloseModal, setShowCloseModal] = useState(false);
  const [showAdvancedBilling, setShowAdvancedBilling] = useState(false);

  // Set initial active profile
  useEffect(() => {
    if (profiles.length > 0 && !activeProfileId) {
      setActiveProfileId(profiles[0].id);
    }
  }, [profiles]);

  // Find active open shift for active profile
  useEffect(() => {
    if (activeProfileId) {
      const openShift = shifts.find(s => s.profileId === activeProfileId && s.status === "Open");
      setActiveShift(openShift || null);
    } else {
      setActiveShift(null);
    }
  }, [activeProfileId, shifts]);

  // Filter products
  const filteredProducts = products.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          p.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          p.barcode.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCat = selectedCategory === "All" || p.category === selectedCategory;
    return matchesSearch && matchesCat;
  });

  // Categories
  const categories = ["All", ...Array.from(new Set(products.map(p => p.category)))];

  // Cart operations
  const addToCart = (product: Product) => {
    if (product.stock <= 0) {
      onNotification("OutOfStock", `Stock exhausted for item ${product.code}`, "error");
      return;
    }
    setCart(prev => {
      const existing = prev.find(item => item.product.id === product.id);
      if (existing) {
        if (existing.quantity >= product.stock) {
          onNotification("LimitExceeded", "Cannot exceed on-hand warehouse stock limit", "error");
          return prev;
        }
        return prev.map(item => item.product.id === product.id ? { ...item, quantity: item.quantity + 1 } : item);
      }
      return [...prev, { product, quantity: 1 }];
    });
  };

  const updateQuantity = (productId: string, quantity: number) => {
    const product = products.find(p => p.id === productId);
    if (!product) return;

    if (quantity <= 0) {
      setCart(prev => prev.filter(item => item.product.id !== productId));
      return;
    }

    if (quantity > product.stock) {
      onNotification("StockCap", `Only ${product.stock} units available in Main warehouse`, "error");
      return;
    }

    setCart(prev => prev.map(item => item.product.id === productId ? { ...item, quantity } : item));
  };

  const totalCartValue = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);

  // Hold / Recall Bills
  const handleHoldBill = () => {
    if (cart.length === 0) return;
    const newHold: Bill = {
      id: `HOLD-${Date.now().toString().slice(-4)}`,
      timestamp: new Date().toISOString(),
      items: [...cart],
      total: totalCartValue,
      customerName
    };
    setHeldBills(prev => [...prev, newHold]);
    setCart([]);
    onNotification("Bill Held", `Bill logged under temporary slot: ${newHold.id}`, "success");
  };

  const handleRecallBill = (held: Bill) => {
    setCart(held.items);
    setCustomerName(held.customerName || "Walk-In Customer");
    setHeldBills(prev => prev.filter(b => b.id !== held.id));
    onNotification("Bill Recalled", `Slot ${held.id} loaded back to terminal`, "success");
  };

  // Open Shift
  const handleOpenShift = async () => {
    if (!activeProfileId || !openingBalance) return;
    try {
      const res = await fetch("/api/pos/shifts/open", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ profileId: activeProfileId, openingBalance })
      });
      if (res.ok) {
        onNotification("Shift Opened", "Drawer register successfully opened and validated.", "success");
        onRefreshData();
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Close Shift
  const handleCloseShift = async () => {
    if (!activeShift || !closingBalance) return;
    try {
      const res = await fetch(`/api/pos/shifts/close/${activeShift.id}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ closingBalance })
      });
      if (res.ok) {
        onNotification("Shift Closed", "Shift transactions archived and registered in core audits.", "success");
        setShowCloseModal(false);
        setClosingBalance("");
        onRefreshData();
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Checkout Bill
  const handleCheckout = async () => {
    if (cart.length === 0 || !activeShift) return;
    try {
      const res = await fetch("/api/pos/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          shiftId: activeShift.id,
          items: cart,
          total: totalCartValue,
          customerName
        })
      });
      if (res.ok) {
        onNotification("Success", "Bill successfully paid, printed to lane queue, and recorded.", "success");
        setCart([]);
        setCustomerName("Walk-In Customer");
        setCashTendered("");
        onRefreshData();
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Tender change calculation
  const tenderCash = parseFloat(cashTendered || "0");
  const changeDue = tenderCash > totalCartValue ? tenderCash - totalCartValue : 0;

  return (
    <div className="space-y-6">
      
      {/* Shift Register Control Bar */}
      <div className="bg-[#16213e] p-5 rounded-xl border border-[#2a3a5c]">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="flex items-center space-x-3">
            <span className="material-symbols-outlined text-blue-500 text-3xl">point_of_sale</span>
            <div>
              <h3 className="font-display font-semibold text-lg text-white">Billing Workspace</h3>
              <p className="text-xs text-[#8892a4]">Operational Terminal Configuration Layer</p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-4">
            {/* Profile Selector */}
            <div className="flex items-center space-x-2">
              <label className="text-xs font-semibold text-[#8892a4] uppercase font-display">Active Terminal:</label>
              <select
                value={activeProfileId}
                onChange={(e) => setActiveProfileId(e.target.value)}
                className="bg-[#1a2744] border border-[#2a3a5c] text-white text-xs rounded px-2.5 py-1.5 focus:outline-none"
              >
                {profiles.map(p => (
                  <option key={p.id} value={p.id}>{p.name} ({p.cashier})</option>
                ))}
              </select>
            </div>

            {/* Shift Indicators */}
            {activeShift ? (
              <div className="flex items-center space-x-3 bg-[#1a2744] px-4 py-1.5 rounded border border-[#2a3a5c]">
                <div className="flex items-center space-x-1.5 text-xs text-emerald-400 font-semibold font-mono">
                  <span className="w-2 h-2 bg-emerald-500 rounded-full animate-ping"></span>
                  <span>SHIFT OPEN (ID: {activeShift.id})</span>
                </div>
                <button
                  onClick={() => setShowCloseModal(true)}
                  className="bg-rose-500 hover:bg-rose-600 text-white text-[10px] font-bold uppercase px-3 py-1 rounded transition-colors"
                >
                  Close Register
                </button>
              </div>
            ) : (
              <div className="flex items-center space-x-3 bg-[#1a2744] px-4 py-1.5 rounded border border-rose-900 border-opacity-50">
                <span className="text-xs text-rose-400 font-semibold font-mono uppercase">LANE REGISTER CLOSED</span>
                <div className="flex items-center space-x-2">
                  <input
                    type="number"
                    value={openingBalance}
                    onChange={(e) => setOpeningBalance(e.target.value)}
                    className="bg-[#16213e] border border-[#2a3a5c] text-white text-xs rounded px-2 py-1 w-24"
                    placeholder="Opening Balance"
                  />
                  <button
                    onClick={handleOpenShift}
                    className="bg-[#2563EB] hover:bg-opacity-95 text-white text-[10px] font-bold uppercase px-3 py-1.5 rounded transition-all"
                  >
                    Open Shift
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {activeShift ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* Left Area: Product list (Col span 7) */}
          <div className="lg:col-span-7 space-y-4">
            
            {/* Filters Bar */}
            <div className="flex flex-col sm:flex-row gap-3">
              <input
                type="text"
                placeholder="Lookup Name, Item Code, or Scan Barcode..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="flex-1 bg-[#16213e] border border-[#2a3a5c] text-white text-xs px-3 py-2 rounded focus:outline-none focus:border-[#2563EB]"
              />
              <div className="flex gap-2">
                {categories.map(cat => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`text-xs px-3 py-2 rounded font-semibold border transition-all ${
                      selectedCategory === cat 
                        ? "bg-[#2563EB] border-[#2563EB] text-white" 
                        : "bg-[#16213e] border-[#2a3a5c] text-[#8892a4] hover:border-[#2563EB]"
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* Products grid */}
            <SmritiScrollArea maxHeight={460} fadeColorClass="from-[#16213e]">
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 pr-1">
                {filteredProducts.map(prod => (
                  <div
                    key={prod.id}
                    onClick={() => addToCart(prod)}
                    className="bg-[#16213e] border border-[#2a3a5c] rounded-lg p-4 cursor-pointer hover:border-[#2563EB] group transition-all flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex justify-between text-[10px] text-[#8892a4] font-mono">
                        <span>{prod.code}</span>
                        <span>{prod.barcode}</span>
                      </div>
                      <h4 className="mt-1 font-semibold text-sm text-white group-hover:text-[#2563EB] transition-colors">{prod.name}</h4>
                      
                      {/* Attributes */}
                      <div className="mt-2 flex gap-1.5">
                        {prod.color && (
                          <span className="text-[10px] bg-[#1a2744] text-[#8892a4] px-1.5 py-0.5 rounded border border-[#2a3a5c]">
                            Color: {prod.color}
                          </span>
                        )}
                        {prod.size && (
                          <span className="text-[10px] bg-[#1a2744] text-[#8892a4] px-1.5 py-0.5 rounded border border-[#2a3a5c]">
                            Size: {prod.size}
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="mt-4 flex items-center justify-between border-t border-[#2a3a5c] pt-2">
                      <span className="text-emerald-400 font-bold text-sm">₹{prod.price}</span>
                      <span className={`text-[10px] font-bold uppercase ${prod.stock < 10 ? "text-rose-500 animate-pulse" : "text-emerald-500"}`}>
                        {prod.stock} units
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </SmritiScrollArea>

            {/* Holds list */}
            {heldBills.length > 0 && (
              <div className="bg-[#16213e] p-4 rounded-xl border border-[#2a3a5c]">
                <h4 className="text-xs font-semibold text-[#8892a4] uppercase font-display mb-3">Temporary Hold Slots</h4>
                <div className="flex flex-wrap gap-2">
                  {heldBills.map(b => (
                    <button
                      key={b.id}
                      onClick={() => handleRecallBill(b)}
                      className="text-xs bg-[#1a2744] border border-amber-500 border-opacity-40 text-amber-500 hover:bg-[#2563EB] hover:text-white hover:border-[#2563EB] px-3 py-1.5 rounded transition-all flex items-center space-x-1"
                    >
                      <span className="material-symbols-outlined text-sm">folder_open</span>
                      <span>Recall {b.id} (₹{b.total})</span>
                    </button>
                  ))}
                </div>
              </div>
            )}

          </div>

          {/* Right Area: Cashier Desk (Col span 5) */}
          <div className="lg:col-span-5 bg-[#16213e] border border-[#2a3a5c] rounded-xl p-5 flex flex-col justify-between min-h-[500px]">
            <div>
              <div className="flex justify-between items-center mb-4 pb-3 border-b border-[#2a3a5c]">
                <h4 className="font-display font-semibold text-sm text-white">Active Cart</h4>
                <button
                  onClick={handleHoldBill}
                  disabled={cart.length === 0}
                  className="text-xs text-amber-500 hover:text-amber-400 font-semibold flex items-center space-x-1 disabled:opacity-40"
                >
                  <span className="material-symbols-outlined text-sm">pause_circle</span>
                  <span>Hold Slot</span>
                </button>
              </div>

              {/* Cart List */}
              <SmritiScrollArea maxHeight={180} fadeColorClass="from-[#16213e]">
                <div className="space-y-3 pr-1">
                  {cart.length === 0 ? (
                    <div className="py-8 text-center text-[#8892a4] text-xs">
                      <span className="material-symbols-outlined text-3xl block mb-2 opacity-50">shopping_cart</span>
                      Cart is empty. Tap items to checkout.
                    </div>
                  ) : (
                    cart.map(item => (
                      <div key={item.product.id} className="flex justify-between items-center bg-[#1a2744] p-3 rounded-lg border border-[#2a3a5c]">
                        <div className="flex-1 min-w-0 pr-3">
                          <h5 className="font-semibold text-white text-xs truncate">{item.product.name}</h5>
                          <p className="text-[10px] text-[#8892a4] font-mono">₹{item.product.price} / unit</p>
                        </div>
                        <div className="flex items-center space-x-3 shrink-0">
                          <div className="flex items-center bg-[#16213e] rounded border border-[#2a3a5c]">
                            <button
                              onClick={() => updateQuantity(item.product.id, item.quantity - 1)}
                              className="text-white hover:bg-[#1a2744] px-2 py-0.5"
                            >
                              -
                            </button>
                            <span className="text-white text-xs font-mono font-bold px-3">{item.quantity}</span>
                            <button
                              onClick={() => updateQuantity(item.product.id, item.quantity + 1)}
                              className="text-white hover:bg-[#1a2744] px-2 py-0.5"
                            >
                              +
                            </button>
                          </div>
                          <span className="text-emerald-400 font-bold text-xs w-16 text-right">
                            ₹{item.product.price * item.quantity}
                          </span>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </SmritiScrollArea>
            </div>

            {/* Customer & Checkout controls */}
            <div className="mt-4 pt-4 border-t border-[#2a3a5c] space-y-4">
              
              {/* Customer input */}
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-semibold text-[#8892a4] uppercase font-display shrink-0">Loyalty Account:</span>
                <input
                  type="text"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="flex-1 bg-[#1a2744] border border-[#2a3a5c] text-white text-xs rounded px-2 py-1 w-full"
                />
              </div>

              {/* Total display */}
              <div className="bg-[#1a2744] p-4 rounded-lg border border-[#2a3a5c] space-y-1.5">
                <div className="flex justify-between text-xs text-[#8892a4]">
                  <span>Subtotal:</span>
                  <span>₹{totalCartValue}</span>
                </div>
                <div className="flex justify-between text-xs text-[#8892a4]">
                  <span>GST/CGST (18% inclusive):</span>
                  <span>₹{Math.round(totalCartValue * 0.18)}</span>
                </div>
                <div className="flex justify-between text-base font-bold text-white border-t border-[#2a3a5c] pt-1.5 mt-1.5">
                  <span>Grand Total:</span>
                  <span className="text-emerald-400">₹{totalCartValue}</span>
                </div>
              </div>

              {/* Cash tendered calculator */}
              {cart.length > 0 && (
                <div className="bg-[#1a2744] bg-opacity-50 p-3 rounded-lg border border-[#2a3a5c] flex items-center justify-between gap-3">
                  <div className="flex items-center space-x-2">
                    <span className="material-symbols-outlined text-xs text-[#8892a4]">calculate</span>
                    <span className="text-[11px] text-[#8892a4]">Cash Tendered:</span>
                  </div>
                  <input
                    type="number"
                    value={cashTendered}
                    onChange={(e) => setCashTendered(e.target.value)}
                    placeholder="₹ Received"
                    className="bg-[#16213e] border border-[#2a3a5c] text-white text-xs rounded px-2.5 py-1 w-24 text-right focus:outline-none"
                  />
                  {changeDue > 0 && (
                    <div className="text-xs text-[#22c55e] font-mono font-bold">
                      Change: ₹{Math.round(changeDue)}
                    </div>
                  )}
                </div>
              )}

              {/* Hotkey Indicator */}
              <div className="flex justify-between text-[10px] text-[#8892a4] font-mono px-1">
                <span>[Esc] Clear</span>
                <span>[F2] Hold Bill</span>
                <span>[F12] Trigger checkout</span>
              </div>

              {/* Submit checkout button */}
              <div className="space-y-2">
                <button
                  onClick={handleCheckout}
                  disabled={cart.length === 0}
                  className="w-full bg-[#1e293b] hover:bg-slate-800 text-white font-bold uppercase py-2.5 rounded-lg border border-[#334155] transition-all flex items-center justify-center space-x-2 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer text-xs"
                >
                  <span className="material-symbols-outlined text-base">payments</span>
                  <span>Standard Checkout (F12)</span>
                </button>

                <button
                  onClick={() => setShowAdvancedBilling(true)}
                  disabled={cart.length === 0}
                  className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-bold uppercase py-3.5 rounded-lg transition-all flex items-center justify-center space-x-2 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer shadow-lg shadow-blue-950/20 text-xs"
                >
                  <span className="material-symbols-outlined text-base">receipt_long</span>
                  <span>Advanced GST Invoicing</span>
                </button>
              </div>

            </div>

          </div>

        </div>
      ) : (
        <div className="bg-[#16213e] border border-[#2a3a5c] rounded-xl p-12 text-center max-w-lg mx-auto mt-12">
          <span className="material-symbols-outlined text-6xl text-rose-500 animate-pulse block mb-4">lock</span>
          <h3 className="text-xl font-bold font-display text-white mb-2">Cash Lane Register Locked</h3>
          <p className="text-xs text-[#8892a4] leading-relaxed mb-6">
            An active opening balance must be declared to unlock POS layouts. Enter your starting drawer cashier float cash in the header above and trigger <strong>Open Shift</strong> to proceed.
          </p>
        </div>
      )}

      {/* Close Register Dialog Modal */}
      {showCloseModal && activeShift && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black bg-opacity-70" onClick={() => setShowCloseModal(false)}></div>
          <div className="bg-[#16213e] border border-[#2a3a5c] rounded-xl p-6 max-w-md w-full relative z-10 space-y-4">
            <h4 className="font-display font-semibold text-lg text-white">Declare Drawer Close Float Balance</h4>
            <p className="text-xs text-[#8892a4]">
              Input your total drawer cash to close Shift Register <span className="font-mono text-white text-xs font-bold">#{activeShift.id}</span>. SMRITI will audit discrepancies in closing ledger logs.
            </p>
            
            <div className="bg-[#1a2744] p-4 rounded border border-[#2a3a5c] space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-[#8892a4]">Opening Float Cash:</span>
                <span className="font-bold text-white">₹{activeShift.openingBalance}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#8892a4]">Sales Registered (Value):</span>
                <span className="font-bold text-[#22c55e]">+₹{activeShift.salesValue}</span>
              </div>
              <div className="flex justify-between border-t border-[#2a3a5c] pt-2 mt-2">
                <span className="text-white font-semibold">Expected Closing Drawer Value:</span>
                <span className="font-bold text-white">₹{activeShift.openingBalance + activeShift.salesValue}</span>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#8892a4] uppercase font-display mb-2">Declared Physical Cash:</label>
              <input
                type="number"
                value={closingBalance}
                onChange={(e) => setClosingBalance(e.target.value)}
                className="bg-[#1a2744] border border-[#2a3a5c] text-white text-sm rounded px-3 py-2 w-full focus:outline-none"
                placeholder="₹ Amount in drawer"
              />
            </div>

            <div className="flex justify-end space-x-3 pt-4">
              <button
                onClick={() => setShowCloseModal(false)}
                className="bg-[#1a2744] text-[#8892a4] hover:text-white px-4 py-2 rounded text-xs font-semibold transition-colors"
              >
                Abort
              </button>
              <button
                onClick={handleCloseShift}
                disabled={!closingBalance}
                className="bg-rose-500 hover:bg-rose-600 text-white px-4 py-2 rounded text-xs font-semibold transition-colors disabled:opacity-40"
              >
                Archive & Close
              </button>
            </div>
          </div>
        </div>
      )}

      {showAdvancedBilling && (
        <AdvancedBillingEngine
          cart={cart}
          onClearCart={() => setCart([])}
          activeShift={activeShift}
          activeProfile={profiles.find(p => p.id === activeProfileId) || null}
          onCheckoutSuccess={(bill) => {
            onRefreshData();
          }}
          onNotification={onNotification}
          onClose={() => setShowAdvancedBilling(false)}
        />
      )}

    </div>
  );
};
