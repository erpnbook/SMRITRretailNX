import React, { useState, useEffect } from "react";
import { 
  Plus, Settings, Trash2, Edit3, Sliders, Check, 
  HelpCircle, Sparkles, Folder, Layers, Info
} from "lucide-react";
import { AttributeDefinition, AttributeGroup } from "../types.js";

interface AttributeManagerSectionProps {
  onNotification: (title: string, message: string, type?: "success" | "error") => void;
}

export const AttributeManagerSection: React.FC<AttributeManagerSectionProps> = ({ 
  onNotification 
}) => {
  const [definitions, setDefinitions] = useState<AttributeDefinition[]>([]);
  const [groups, setGroups] = useState<AttributeGroup[]>([]);
  const [categoryMappings, setCategoryMappings] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  // Form states for Definitions
  const [defName, setDefName] = useState("");
  const [defLabel, setDefLabel] = useState("");
  const [defDataType, setDefDataType] = useState<"text" | "number" | "date" | "select">("select");
  const [defIsVariant, setDefIsVariant] = useState(true);
  const [defIsMandatory, setDefIsMandatory] = useState(true);
  const [defValues, setDefValues] = useState("");
  const [editingDefId, setEditingDefId] = useState<string | null>(null);

  // Form states for Groups
  const [grpName, setGrpName] = useState("");
  const [grpSelectedAttrs, setGrpSelectedAttrs] = useState<string[]>([]);
  const [grpGridCol, setGrpGridCol] = useState("");
  const [grpGridRow, setGrpGridRow] = useState("");
  const [editingGrpId, setEditingGrpId] = useState<string | null>(null);

  // Form states for Mappings
  const [mappingCategory, setMappingCategory] = useState("Apparel");
  const [mappingGroupId, setMappingGroupId] = useState("");

  const fetchAll = async () => {
    setLoading(true);
    try {
      const [res1, res2, res3] = await Promise.all([
        fetch("/api/attributes/definitions"),
        fetch("/api/attributes/groups"),
        fetch("/api/attributes/category-mappings")
      ]);
      if (res1.ok) setDefinitions(await res1.json());
      if (res2.ok) setGroups(await res2.json());
      if (res3.ok) setCategoryMappings(await res3.json());
    } catch (e) {
      console.error(e);
      onNotification("Fetch Error", "Failed to load attribute configurations.", "error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAll();
  }, []);

  const handleSaveDef = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!defName.trim() || !defLabel.trim()) {
      onNotification("Missing Fields", "Attribute Name and Label are required.", "error");
      return;
    }

    const valueList = defValues
      .split(",")
      .map(v => v.trim())
      .filter(v => v.length > 0);

    const payload = {
      name: defName.trim(),
      label: defLabel.trim(),
      dataType: defDataType,
      isVariantDimension: defIsVariant,
      isMandatory: defIsMandatory,
      validValues: valueList
    };

    try {
      const url = editingDefId 
        ? `/api/attributes/definitions/${editingDefId}`
        : "/api/attributes/definitions";
      const method = editingDefId ? "PUT" : "POST";

      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      if (res.ok) {
        onNotification("Saved", `Attribute "${defLabel}" registered successfully.`, "success");
        setDefName("");
        setDefLabel("");
        setDefDataType("select");
        setDefValues("");
        setEditingDefId(null);
        fetchAll();
      } else {
        const err = await res.json();
        onNotification("Error", err.error || "Failed to save attribute.", "error");
      }
    } catch (err) {
      onNotification("Connection Error", "Failed to connect to backend.", "error");
    }
  };

  const handleDeleteDef = async (id: string) => {
    if (!confirm("Are you sure you want to delete this attribute definition? It may affect templates.")) return;
    try {
      const res = await fetch(`/api/attributes/definitions/${id}`, { method: "DELETE" });
      if (res.ok) {
        onNotification("Deleted", "Attribute definition deleted.", "success");
        fetchAll();
      }
    } catch (e) {
      onNotification("Connection Error", "Failed to connect to backend.", "error");
    }
  };

  const handleEditDef = (def: AttributeDefinition) => {
    setEditingDefId(def.id);
    setDefName(def.name);
    setDefLabel(def.label);
    setDefDataType(def.dataType);
    setDefIsVariant(def.isVariantDimension);
    setDefIsMandatory(def.isMandatory);
    setDefValues(def.validValues.join(", "));
  };

  const handleSaveGroup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!grpName.trim() || grpSelectedAttrs.length === 0) {
      onNotification("Missing Fields", "Group name and at least one attribute are required.", "error");
      return;
    }

    const payload = {
      name: grpName.trim(),
      attributeIds: grpSelectedAttrs,
      gridColumnAttributeId: grpGridCol || undefined,
      gridRowAttributeId: grpGridRow || undefined
    };

    try {
      const url = editingGrpId 
        ? `/api/attributes/groups/${editingGrpId}`
        : "/api/attributes/groups";
      const method = editingGrpId ? "PUT" : "POST";

      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      if (res.ok) {
        onNotification("Saved", `Group "${grpName}" registered successfully.`, "success");
        setGrpName("");
        setGrpSelectedAttrs([]);
        setGrpGridCol("");
        setGrpGridRow("");
        setEditingGrpId(null);
        fetchAll();
      } else {
        const err = await res.json();
        onNotification("Error", err.error || "Failed to save group.", "error");
      }
    } catch (err) {
      onNotification("Connection Error", "Failed to save group.", "error");
    }
  };

  const handleDeleteGroup = async (id: string) => {
    if (!confirm("Are you sure you want to delete this attribute group?")) return;
    try {
      const res = await fetch(`/api/attributes/groups/${id}`, { method: "DELETE" });
      if (res.ok) {
        onNotification("Deleted", "Attribute group deleted.", "success");
        fetchAll();
      }
    } catch (e) {
      onNotification("Connection Error", "Failed to delete group.", "error");
    }
  };

  const handleEditGroup = (g: AttributeGroup) => {
    setEditingGrpId(g.id);
    setGrpName(g.name);
    setGrpSelectedAttrs(g.attributeIds);
    setGrpGridCol(g.gridColumnAttributeId || "");
    setGrpGridRow(g.gridRowAttributeId || "");
  };

  const handleSaveMapping = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!mappingGroupId) {
      onNotification("Missing Fields", "Please select an attribute group for the mapping.", "error");
      return;
    }

    try {
      const res = await fetch("/api/attributes/category-mappings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          category: mappingCategory,
          attributeGroupId: mappingGroupId
        })
      });
      if (res.ok) {
        onNotification("Saved", `Category "${mappingCategory}" mapped successfully.`, "success");
        fetchAll();
      }
    } catch (e) {
      onNotification("Connection Error", "Failed to map category.", "error");
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Dynamic Information Banner */}
      <div className="bg-[#121c35] border border-blue-900/40 p-4 rounded-xl flex items-start space-x-3 text-blue-300">
        <Info className="shrink-0 mt-0.5" size={16} />
        <div className="text-xs space-y-1">
          <p className="font-bold">SMRITI Data-Driven Extensible Architecture</p>
          <p className="text-[#8892a4] leading-relaxed">
            Avoid hardcoding columns. Define attributes, order them inside groups, and let SMRITI auto-generate item codes, validation spreadsheets, size matrix grids, and aggregate reports automatically!
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Left Column: Attribute Definitions */}
        <div className="space-y-6">
          <div className="bg-[#16213e] border border-[#2a3a5c] rounded-2xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-[#2a3a5c]/50 pb-3">
              <h3 className="font-display font-bold text-sm text-white flex items-center space-x-2">
                <Sliders size={16} className="text-blue-400" />
                <span>1. Attribute Definitions</span>
              </h3>
              <span className="text-[10px] font-mono text-[#8892a4]">{definitions.length} Active</span>
            </div>

            {/* List of Definitions */}
            <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
              {definitions.map(def => (
                <div key={def.id} className="bg-[#121c35] p-3 rounded-xl border border-[#2a3a5c]/60 flex items-center justify-between">
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="text-xs font-bold text-white">{def.label}</span>
                      <span className="text-[9px] font-mono px-1.5 py-0.2 bg-indigo-950 text-indigo-400 border border-indigo-900 rounded uppercase font-bold">
                        {def.dataType}
                      </span>
                      {def.isVariantDimension && (
                        <span className="text-[9px] font-mono px-1.5 py-0.2 bg-emerald-950 text-emerald-400 border border-emerald-900 rounded font-bold uppercase">
                          Variant Segment
                        </span>
                      )}
                    </div>
                    {def.validValues.length > 0 && (
                      <p className="text-[10px] text-[#8892a4] mt-1 font-mono truncate max-w-sm">
                        Values: {def.validValues.join(", ")}
                      </p>
                    )}
                  </div>
                  <div className="flex items-center space-x-1">
                    <button onClick={() => handleEditDef(def)} className="p-1 hover:bg-[#1a2744] text-sky-400 rounded transition-colors">
                      <Edit3 size={12} />
                    </button>
                    <button onClick={() => handleDeleteDef(def.id)} className="p-1 hover:bg-rose-950/40 text-rose-400 rounded transition-colors">
                      <Trash2 size={12} />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* Form to Create/Edit Definition */}
            <form onSubmit={handleSaveDef} className="bg-[#121c35]/50 border border-dashed border-[#2a3a5c] p-4 rounded-xl space-y-3">
              <span className="text-[10px] font-mono uppercase tracking-wider text-indigo-400 font-bold block">
                {editingDefId ? "Modify Attribute" : "Add New Attribute Definition"}
              </span>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[9px] font-mono text-[#8892a4] uppercase block mb-1">Internal Name *</label>
                  <input
                    type="text"
                    required
                    value={defName}
                    onChange={(e) => setDefName(e.target.value)}
                    placeholder="e.g. sole_type"
                    className="w-full bg-[#121c35] border border-[#2a3a5c] rounded-lg px-2.5 py-1.5 text-xs text-white placeholder-[#8892a4] focus:outline-none focus:border-blue-500 font-mono"
                  />
                </div>
                <div>
                  <label className="text-[9px] font-mono text-[#8892a4] uppercase block mb-1">Display Label *</label>
                  <input
                    type="text"
                    required
                    value={defLabel}
                    onChange={(e) => setDefLabel(e.target.value)}
                    placeholder="e.g. Sole Material"
                    className="w-full bg-[#121c35] border border-[#2a3a5c] rounded-lg px-2.5 py-1.5 text-xs text-white placeholder-[#8892a4] focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="text-[9px] font-mono text-[#8892a4] uppercase block mb-1">Data Type</label>
                  <select
                    value={defDataType}
                    onChange={(e: any) => setDefDataType(e.target.value)}
                    className="w-full bg-[#121c35] border border-[#2a3a5c] rounded-lg px-2 py-1.5 text-xs text-white focus:outline-none focus:border-blue-500"
                  >
                    <option value="select">Select Option List</option>
                    <option value="text">Free Text</option>
                    <option value="number">Numeric</option>
                    <option value="date">Date picker</option>
                  </select>
                </div>
                <div className="flex flex-col justify-end">
                  <label className="flex items-center space-x-1.5 text-xs text-[#8892a4] py-2 cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={defIsVariant}
                      onChange={(e) => setDefIsVariant(e.target.checked)}
                      className="rounded bg-[#121c35] border-[#2a3a5c]"
                    />
                    <span>Variant Code Dimension</span>
                  </label>
                </div>
                <div className="flex flex-col justify-end">
                  <label className="flex items-center space-x-1.5 text-xs text-[#8892a4] py-2 cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={defIsMandatory}
                      onChange={(e) => setDefIsMandatory(e.target.checked)}
                      className="rounded bg-[#121c35] border-[#2a3a5c]"
                    />
                    <span>Mandatory</span>
                  </label>
                </div>
              </div>

              {defDataType === "select" && (
                <div>
                  <label className="text-[9px] font-mono text-[#8892a4] uppercase block mb-1">
                    Allowed Values (Comma-separated)
                  </label>
                  <input
                    type="text"
                    value={defValues}
                    onChange={(e) => setDefValues(e.target.value)}
                    placeholder="e.g. Rubber, PU, PVC, Leather"
                    className="w-full bg-[#121c35] border border-[#2a3a5c] rounded-lg px-2.5 py-1.5 text-xs text-white placeholder-[#8892a4] focus:outline-none focus:border-blue-500 font-mono"
                  />
                </div>
              )}

              <div className="flex justify-end space-x-2 pt-1">
                {editingDefId && (
                  <button
                    type="button"
                    onClick={() => {
                      setEditingDefId(null);
                      setDefName("");
                      setDefLabel("");
                      setDefDataType("select");
                      setDefValues("");
                    }}
                    className="px-3 py-1 bg-slate-800 text-xs text-slate-300 rounded"
                  >
                    Cancel
                  </button>
                )}
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded text-xs font-bold transition-colors cursor-pointer"
                >
                  {editingDefId ? "Update Attribute" : "Save Definition"}
                </button>
              </div>
            </form>
          </div>
        </div>

        {/* Right Column: Attribute Groups & Category Mappings */}
        <div className="space-y-6">
          <div className="bg-[#16213e] border border-[#2a3a5c] rounded-2xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-[#2a3a5c]/50 pb-3">
              <h3 className="font-display font-bold text-sm text-white flex items-center space-x-2">
                <Folder size={16} className="text-violet-400" />
                <span>2. Attribute Groups</span>
              </h3>
              <span className="text-[10px] font-mono text-[#8892a4]">{groups.length} Groups</span>
            </div>

            {/* List of Groups */}
            <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
              {groups.map(g => {
                const attrNames = g.attributeIds
                  .map(aid => definitions.find(d => d.id === aid)?.label || aid)
                  .join(", ");
                return (
                  <div key={g.id} className="bg-[#121c35] p-3 rounded-xl border border-[#2a3a5c]/60 flex items-center justify-between">
                    <div>
                      <span className="text-xs font-bold text-white block">{g.name}</span>
                      <span className="text-[10px] text-[#8892a4] mt-0.5 block">
                        Attributes: <span className="text-[#a5b4fc]">{attrNames}</span>
                      </span>
                      {(g.gridColumnAttributeId || g.gridRowAttributeId) && (
                        <div className="flex items-center space-x-2 mt-1.5">
                          {g.gridColumnAttributeId && (
                            <span className="text-[9px] bg-sky-950 text-sky-400 px-1 py-0.2 border border-sky-900 rounded font-mono">
                              Col: {definitions.find(d => d.id === g.gridColumnAttributeId)?.label}
                            </span>
                          )}
                          {g.gridRowAttributeId && (
                            <span className="text-[9px] bg-indigo-950 text-indigo-400 px-1 py-0.2 border border-indigo-900 rounded font-mono">
                              Row: {definitions.find(d => d.id === g.gridRowAttributeId)?.label}
                            </span>
                          )}
                        </div>
                      )}
                    </div>
                    <div className="flex items-center space-x-1">
                      <button onClick={() => handleEditGroup(g)} className="p-1 hover:bg-[#1a2744] text-sky-400 rounded transition-colors">
                        <Edit3 size={12} />
                      </button>
                      <button onClick={() => handleDeleteGroup(g.id)} className="p-1 hover:bg-rose-950/40 text-rose-400 rounded transition-colors">
                        <Trash2 size={12} />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Form to Create/Edit Group */}
            <form onSubmit={handleSaveGroup} className="bg-[#121c35]/50 border border-dashed border-[#2a3a5c] p-4 rounded-xl space-y-3">
              <span className="text-[10px] font-mono uppercase tracking-wider text-indigo-400 font-bold block">
                {editingGrpId ? "Modify Attribute Group" : "Create Attribute Group"}
              </span>

              <div>
                <label className="text-[9px] font-mono text-[#8892a4] uppercase block mb-1">Group Name *</label>
                <input
                  type="text"
                  required
                  value={grpName}
                  onChange={(e) => setGrpName(e.target.value)}
                  placeholder="e.g. Footwear Standard"
                  className="w-full bg-[#121c35] border border-[#2a3a5c] rounded-lg px-2.5 py-1.5 text-xs text-white placeholder-[#8892a4] focus:outline-none focus:border-blue-500"
                />
              </div>

              {/* Multi-select attributes list */}
              <div>
                <label className="text-[9px] font-mono text-[#8892a4] uppercase block mb-1">
                  Select Attributes to Include (In Code Order)
                </label>
                <div className="grid grid-cols-2 gap-1.5 bg-[#121c35] border border-[#2a3a5c] p-2.5 rounded-lg max-h-32 overflow-y-auto">
                  {definitions.map(d => {
                    const isSelected = grpSelectedAttrs.includes(d.id);
                    return (
                      <label key={d.id} className="flex items-center space-x-2 text-xs text-[#8892a4] cursor-pointer hover:text-white select-none">
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={() => {
                            if (isSelected) {
                              setGrpSelectedAttrs(prev => prev.filter(aid => aid !== d.id));
                            } else {
                              setGrpSelectedAttrs(prev => [...prev, d.id]);
                            }
                          }}
                          className="rounded bg-[#121c35] border-[#2a3a5c]"
                        />
                        <span>{d.label}</span>
                      </label>
                    );
                  })}
                </div>
              </div>

              {/* Matrix Row and Column definitions */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[9px] font-mono text-[#8892a4] uppercase block mb-1">Grid Matrix Column</label>
                  <select
                    value={grpGridCol}
                    onChange={(e) => setGrpGridCol(e.target.value)}
                    className="w-full bg-[#121c35] border border-[#2a3a5c] rounded-lg px-2 py-1.5 text-xs text-white focus:outline-none focus:border-blue-500 font-mono"
                  >
                    <option value="">-- None --</option>
                    {grpSelectedAttrs.map(aid => {
                      const d = definitions.find(x => x.id === aid);
                      return d ? <option key={d.id} value={d.id}>{d.label}</option> : null;
                    })}
                  </select>
                </div>
                <div>
                  <label className="text-[9px] font-mono text-[#8892a4] uppercase block mb-1">Grid Matrix Row</label>
                  <select
                    value={grpGridRow}
                    onChange={(e) => setGrpGridRow(e.target.value)}
                    className="w-full bg-[#121c35] border border-[#2a3a5c] rounded-lg px-2 py-1.5 text-xs text-white focus:outline-none focus:border-blue-500 font-mono"
                  >
                    <option value="">-- None --</option>
                    {grpSelectedAttrs.map(aid => {
                      const d = definitions.find(x => x.id === aid);
                      return d ? <option key={d.id} value={d.id}>{d.label}</option> : null;
                    })}
                  </select>
                </div>
              </div>

              <div className="flex justify-end space-x-2 pt-1">
                {editingGrpId && (
                  <button
                    type="button"
                    onClick={() => {
                      setEditingGrpId(null);
                      setGrpName("");
                      setGrpSelectedAttrs([]);
                      setGrpGridCol("");
                      setGrpGridRow("");
                    }}
                    className="px-3 py-1 bg-slate-800 text-xs text-slate-300 rounded"
                  >
                    Cancel
                  </button>
                )}
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-violet-600 hover:bg-violet-500 text-white rounded text-xs font-bold transition-colors cursor-pointer"
                >
                  {editingGrpId ? "Update Group" : "Save Group Configuration"}
                </button>
              </div>
            </form>
          </div>

          {/* Category-to-Group Mappings */}
          <div className="bg-[#16213e] border border-[#2a3a5c] rounded-2xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-[#2a3a5c]/50 pb-3">
              <h3 className="font-display font-bold text-sm text-white flex items-center space-x-2">
                <Check size={16} className="text-emerald-400" />
                <span>3. Category Mapping Defaults</span>
              </h3>
            </div>

            <div className="space-y-2 max-h-32 overflow-y-auto pr-1">
              {categoryMappings.map(m => (
                <div key={m.category} className="bg-[#121c35] p-2.5 rounded-xl border border-[#2a3a5c]/50 flex items-center justify-between text-xs">
                  <span className="text-white font-semibold">{m.category}</span>
                  <span className="text-emerald-400 font-mono">
                    {groups.find(g => g.id === m.attributeGroupId)?.name || m.attributeGroupId}
                  </span>
                </div>
              ))}
            </div>

            <form onSubmit={handleSaveMapping} className="grid grid-cols-3 gap-2 bg-[#121c35]/50 p-3 rounded-xl border border-[#2a3a5c]/40">
              <div>
                <select
                  value={mappingCategory}
                  onChange={(e) => setMappingCategory(e.target.value)}
                  className="w-full bg-[#121c35] border border-[#2a3a5c] rounded px-1.5 py-1 text-xs text-white"
                >
                  <option value="Apparel">Apparel</option>
                  <option value="Footwear">Footwear</option>
                  <option value="Pharmacy">Pharmacy</option>
                  <option value="Jewellery">Jewellery</option>
                  <option value="General">General</option>
                </select>
              </div>
              <div>
                <select
                  value={mappingGroupId}
                  onChange={(e) => setMappingGroupId(e.target.value)}
                  className="w-full bg-[#121c35] border border-[#2a3a5c] rounded px-1.5 py-1 text-xs text-white"
                >
                  <option value="">Select Group...</option>
                  {groups.map(g => (
                    <option key={g.id} value={g.id}>{g.name}</option>
                  ))}
                </select>
              </div>
              <button
                type="submit"
                className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[10px] rounded cursor-pointer transition-colors"
              >
                Assign Default
              </button>
            </form>
          </div>

        </div>

      </div>

    </div>
  );
};
