import React, { useState } from "react";
import { Formula } from "../types";

interface FormulaRegistryTabProps {
  formulas: Formula[];
  onSelectFormula: (f: Formula) => void;
}

export const FormulaRegistryTab: React.FC<FormulaRegistryTabProps> = ({ 
  formulas, 
  onSelectFormula 
}) => {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");

  const categories = ["All", ...Array.from(new Set(formulas.map(f => f.category)))];

  const filteredFormulas = formulas.filter(f => {
    const matchesSearch = f.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          f.meaning.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          f.expression.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCat = selectedCategory === "All" || f.category === selectedCategory;
    return matchesSearch && matchesCat;
  });

  return (
    <div className="space-y-6">
      
      {/* Description Header */}
      <div className="bg-[#16213e] p-6 rounded-xl border border-[#2a3a5c] flex justify-between items-start">
        <div className="space-y-1">
          <h3 className="font-display font-semibold text-lg text-white">SMRITI Formula Registry</h3>
          <p className="text-xs text-[#8892a4]">
            Locked, single-source of truth computed KPI mathematical definitions complying with SMRITI Explainability DOC-01 standards.
          </p>
        </div>
        <span className="text-xs bg-emerald-500 bg-opacity-20 text-emerald-400 font-mono font-bold px-2 py-0.5 rounded border border-emerald-500">RULE 15 ACTIVE</span>
      </div>

      {/* Filter and Lookup controls */}
      <div className="flex flex-col sm:flex-row gap-3">
        <input
          type="text"
          placeholder="Lookup active formula variables, math, descriptions..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="flex-1 bg-[#16213e] border border-[#2a3a5c] text-white text-xs px-3 py-2.5 rounded focus:outline-none"
        />
        <div className="flex gap-2">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`text-xs px-3.5 py-2 rounded font-semibold border transition-all ${
                selectedCategory === cat 
                  ? "bg-[#2563EB] border-[#2563EB] text-white" 
                  : "bg-[#16213e] border-[#2a3a5c] text-[#8892a4] hover:border-[#2563EB]"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Grid of registered formula cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredFormulas.map(f => (
          <div key={f.id} className="bg-[#16213e] rounded-xl p-5 border border-[#2a3a5c] flex flex-col justify-between hover:border-[#2563EB] transition-all">
            <div className="space-y-3">
              <div className="flex justify-between items-start">
                <span className="text-[10px] bg-[#1a2744] text-[#8892a4] px-2 py-0.5 rounded border border-[#2a3a5c]">
                  {f.category}
                </span>
                <span className="font-mono text-xs text-[#8892a4]">{f.id}</span>
              </div>

              <div>
                <h4 className="font-bold text-white text-base font-display">{f.name}</h4>
                <p className="mt-1.5 text-xs text-[#8892a4] leading-relaxed">{f.meaning}</p>
              </div>

              {/* Expression */}
              <div className="bg-[#1a2744] p-3 rounded font-mono text-xs text-[#2563EB] flex items-center justify-center text-center">
                {f.expression}
              </div>
            </div>

            <div className="mt-5 pt-3 border-t border-[#2a3a5c] flex items-center justify-between">
              <div className="flex flex-col">
                <span className="text-[10px] text-[#8892a4]">Live Output:</span>
                <span className="text-white text-sm font-bold font-mono">{f.value}</span>
              </div>

              <button
                onClick={() => onSelectFormula(f)}
                className="bg-[#2563EB] hover:bg-opacity-95 text-white text-xs font-semibold px-3 py-1.5 rounded flex items-center space-x-1"
              >
                <span className="material-symbols-outlined text-xs">info</span>
                <span>ⓘ Explain</span>
              </button>
            </div>
          </div>
        ))}
      </div>

    </div>
  );
};
