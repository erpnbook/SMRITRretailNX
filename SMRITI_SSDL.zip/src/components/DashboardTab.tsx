import React, { useState, useEffect } from "react";
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from "recharts";
import { Product, Formula, PSVParty } from "../types";

interface DashboardTabProps {
  products: Product[];
  formulas: Formula[];
  psvParties: PSVParty[];
  onSelectFormula: (f: Formula) => void;
}

export const DashboardTab: React.FC<DashboardTabProps> = ({ 
  products, 
  formulas, 
  psvParties,
  onSelectFormula 
}) => {
  const [auditLogs, setAuditLogs] = useState<any[]>([]);
  const [chatMessage, setChatMessage] = useState("");
  const [chatReplies, setChatReplies] = useState<{ sender: "user" | "ai"; text: string }[]>([
    { sender: "ai", text: "Hello! I am your SMRITI Operational Intelligence assistant. Ask me anything about your stock velocity, Weeks of Cover, or how to resolve dead capital issues." }
  ]);
  const [isSending, setIsSending] = useState(false);

  // Fetch Audit Logs
  const fetchAuditLogs = async () => {
    try {
      const response = await fetch("/api/audit-logs");
      const data = await response.json();
      setAuditLogs(data);
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    fetchAuditLogs();
    const interval = setInterval(fetchAuditLogs, 5000);
    return () => clearInterval(interval);
  }, []);

  // Send AI message
  const handleSendMessage = async (msgText?: string) => {
    const textToSend = msgText || chatMessage;
    if (!textToSend.trim() || isSending) return;

    if (!msgText) setChatMessage("");

    setChatReplies(prev => [...prev, { sender: "user", text: textToSend }]);
    setIsSending(true);

    try {
      const response = await fetch("/api/assistant/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: textToSend,
          context: {
            stockStatus: products.map(p => ({ code: p.code, name: p.name, stock: p.stock })),
            distributors: psvParties.map(p => ({ name: p.name, stock: p.stockCount, status: p.status }))
          }
        })
      });
      const data = await response.json();
      setChatReplies(prev => [...prev, { sender: "ai", text: data.reply }]);
    } catch (error) {
      setChatReplies(prev => [...prev, { sender: "ai", text: "Error connecting to server-side AI reasoning." }]);
    } finally {
      setIsSending(false);
      fetchAuditLogs();
    }
  };

  // Pre-calculated Dashboard Metrics
  const totalLiveSales = auditLogs
    .filter(log => log.action === "Invoice Created")
    .reduce((sum, log) => {
      const match = log.after.match(/Total Sales: (\d+) INR/);
      return match ? parseInt(match[1]) : sum;
    }, 9895);

  const totalCapitalLocked = psvParties.reduce((sum, p) => sum + p.capitalLocked, 0);
  const deadStockPercent = 24.5; // Fixed mockup calculation representing items with zero 30d sales

  // Format INR Currencies
  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
      maximumFractionDigits: 0
    }).format(val);
  };

  return (
    <div className="space-y-6">
      {/* KPI Section */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 xl:grid-cols-5 gap-4">
        {/* Metric 1 */}
        <div className="bg-[#16213e] rounded-xl p-5 border border-[#2a3a5c] relative group hover:border-[#2563EB] transition-all">
          <div className="flex justify-between items-start">
            <span className="text-xs font-semibold text-[#8892a4] uppercase font-display">Outlet Health Score</span>
            <button 
              onClick={() => {
                const f = formulas.find(f => f.id === "for-3");
                if (f) onSelectFormula(f);
              }}
              className="text-[#8892a4] hover:text-[#2563EB] flex items-center space-x-0.5"
            >
              <span className="material-symbols-outlined text-sm">info</span>
              <span className="text-xs font-medium">Explain</span>
            </button>
          </div>
          <div className="mt-3 flex items-baseline justify-between">
            <span className="text-3xl font-bold font-display text-emerald-400">89%</span>
            <span className="text-xs text-emerald-400 flex items-center font-semibold">
              <span className="material-symbols-outlined text-sm mr-1">trending_up</span>+1.2%
            </span>
          </div>
          <p className="mt-2 text-xs text-[#8892a4]">Operational Safety & Accuracy</p>
        </div>

        {/* Metric 2 */}
        <div className="bg-[#16213e] rounded-xl p-5 border border-[#2a3a5c] relative group hover:border-[#2563EB] transition-all">
          <div className="flex justify-between items-start">
            <span className="text-xs font-semibold text-[#8892a4] uppercase font-display">Weeks of Cover</span>
            <button 
              onClick={() => {
                const f = formulas.find(f => f.id === "for-1");
                if (f) onSelectFormula(f);
              }}
              className="text-[#8892a4] hover:text-[#2563EB] flex items-center space-x-0.5"
            >
              <span className="material-symbols-outlined text-sm">info</span>
              <span className="text-xs font-medium">Explain</span>
            </button>
          </div>
          <div className="mt-3 flex items-baseline justify-between">
            <span className="text-3xl font-bold font-display text-white">5.0 W</span>
            <span className="text-xs text-amber-500 font-semibold">Trigger Range</span>
          </div>
          <p className="mt-2 text-xs text-[#8892a4]">Average inventory runway</p>
        </div>

        {/* Metric 3 */}
        <div className="bg-[#16213e] rounded-xl p-5 border border-[#2a3a5c] relative group hover:border-[#2563EB] transition-all">
          <div className="flex justify-between items-start">
            <span className="text-xs font-semibold text-[#8892a4] uppercase font-display">Dead Stock %</span>
            <button 
              onClick={() => {
                const f = formulas.find(f => f.id === "for-2");
                if (f) onSelectFormula(f);
              }}
              className="text-[#8892a4] hover:text-[#2563EB] flex items-center space-x-0.5"
            >
              <span className="material-symbols-outlined text-sm">info</span>
              <span className="text-xs font-medium">Explain</span>
            </button>
          </div>
          <div className="mt-3 flex items-baseline justify-between">
            <span className="text-3xl font-bold font-display text-rose-500">{deadStockPercent}%</span>
            <span className="text-xs text-rose-400 flex items-center font-semibold">
              <span className="material-symbols-outlined text-sm mr-1">warning</span>Critical
            </span>
          </div>
          <p className="mt-2 text-xs text-[#8892a4]">Unsold in past 30 days</p>
        </div>

        {/* Metric 4 */}
        <div className="bg-[#16213e] rounded-xl p-5 border border-[#2a3a5c] relative group hover:border-[#2563EB] transition-all">
          <span className="text-xs font-semibold text-[#8892a4] uppercase font-display block">Live Sales Value</span>
          <div className="mt-3 flex items-baseline justify-between">
            <span className="text-3xl font-bold font-display text-blue-400">{formatCurrency(totalLiveSales)}</span>
            <span className="text-xs text-emerald-400 font-semibold">Active Shift</span>
          </div>
          <p className="mt-2 text-xs text-[#8892a4]">Aggregated shift totals</p>
        </div>

        {/* Metric 5 */}
        <div className="bg-[#16213e] rounded-xl p-5 border border-[#2a3a5c] relative group hover:border-[#2563EB] transition-all">
          <div className="flex justify-between items-start">
            <span className="text-xs font-semibold text-[#8892a4] uppercase font-display">Channel Capital</span>
            <button 
              onClick={() => {
                const f = formulas.find(f => f.id === "for-4");
                if (f) onSelectFormula(f);
              }}
              className="text-[#8892a4] hover:text-[#2563EB] flex items-center space-x-0.5"
            >
              <span className="material-symbols-outlined text-sm">info</span>
              <span className="text-xs font-medium">Explain</span>
            </button>
          </div>
          <div className="mt-3 flex items-baseline justify-between">
            <span className="text-3xl font-bold font-display text-white">{formatCurrency(totalCapitalLocked)}</span>
            <span className="text-xs text-rose-400 font-semibold">Locked in PSV</span>
          </div>
          <p className="mt-2 text-xs text-[#8892a4]">Downstream partner stock</p>
        </div>
      </div>

      {/* Main Grid: Visuals and AI Assistant */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left column: Visual Distributor Chart */}
        <div className="lg:col-span-2 space-y-6">
          
          <div className="bg-[#16213e] rounded-xl p-6 border border-[#2a3a5c]">
            <div className="flex justify-between items-center mb-6">
              <h3 className="font-display font-semibold text-lg text-white">Distributor Stock Allocations</h3>
              <span className="text-xs text-[#8892a4] font-mono">Channel Ledger (PSV)</span>
            </div>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={psvParties} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#2a3a5c" />
                  <XAxis dataKey="name" stroke="#8892a4" fontSize={11} tickFormatter={(val) => val.split(" ")[0]} />
                  <YAxis stroke="#8892a4" fontSize={11} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: "#16213e", borderColor: "#2a3a5c", borderRadius: 8 }}
                    labelStyle={{ color: "white", fontWeight: "bold" }}
                  />
                  <Bar dataKey="stockCount" fill="#2563EB" radius={[4, 4, 0, 0]} name="Stock Units" />
                  <Bar dataKey="sellThrough" fill="#22c55e" radius={[4, 4, 0, 0]} name="Sell-Through %" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Compliance Audit Logs */}
          <div className="bg-[#16213e] rounded-xl p-6 border border-[#2a3a5c]">
            <div className="flex justify-between items-center mb-4">
              <div className="flex items-center space-x-2">
                <span className="material-symbols-outlined text-rose-500">gavel</span>
                <h3 className="font-display font-semibold text-lg text-white">Rule 10 Audit Ledger</h3>
              </div>
              <span className="text-xs bg-emerald-500 bg-opacity-20 text-emerald-400 font-mono font-semibold px-2 py-0.5 rounded border border-emerald-500">ACTIVE</span>
            </div>
            
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm text-[#8892a4]">
                <thead className="text-xs uppercase text-white bg-[#1a2744] rounded border-b border-[#2a3a5c]">
                  <tr>
                    <th className="px-4 py-2">Timestamp</th>
                    <th className="px-4 py-2">Operator</th>
                    <th className="px-4 py-2">Action</th>
                    <th className="px-4 py-2">Before Value</th>
                    <th className="px-4 py-2">After Value</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#2a3a5c]">
                  {auditLogs.slice(0, 5).map((log) => (
                    <tr key={log.id} className="hover:bg-[#1a2744] hover:bg-opacity-50">
                      <td className="px-4 py-3 font-mono text-xs">{new Date(log.timestamp).toLocaleTimeString()}</td>
                      <td className="px-4 py-3 font-medium text-white">{log.user}</td>
                      <td className="px-4 py-3">
                        <div className="text-white text-xs font-semibold">{log.action}</div>
                        <div className="text-[11px] text-[#8892a4]">{log.details}</div>
                      </td>
                      <td className="px-4 py-3 font-mono text-xs text-rose-400">{log.before}</td>
                      <td className="px-4 py-3 font-mono text-xs text-emerald-400">{log.after}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

        </div>

        {/* Right column: Copilot AI Chat panel */}
        <div className="bg-[#16213e] rounded-xl border border-[#2a3a5c] flex flex-col h-[490px]">
          <div className="px-5 py-4 border-b border-[#2a3a5c] flex justify-between items-center bg-[#1a2744] rounded-t-xl">
            <div className="flex items-center space-x-2">
              <span className="material-symbols-outlined text-[#2563EB] animate-pulse">psychology</span>
              <h4 className="font-semibold text-white font-display">AI Retail Assistant</h4>
            </div>
            <span className="text-[10px] bg-blue-500 bg-opacity-20 text-blue-400 border border-blue-500 px-1.5 py-0.5 rounded font-mono font-bold uppercase">Gemini Inside</span>
          </div>

          {/* Chats view */}
          <div className="flex-1 overflow-y-auto custom-scrollbar p-4 space-y-3 font-sans text-xs">
            {chatReplies.map((reply, i) => (
              <div key={i} className={`flex ${reply.sender === "user" ? "justify-end" : "justify-start"}`}>
                <div className={`max-w-[85%] rounded-lg p-3 ${
                  reply.sender === "user" 
                    ? "bg-[#2563EB] text-white" 
                    : "bg-[#1a2744] text-[#e2e8f0] border border-[#2a3a5c] whitespace-pre-wrap leading-relaxed"
                }`}>
                  {reply.text}
                </div>
              </div>
            ))}
            {isSending && (
              <div className="flex justify-start">
                <div className="bg-[#1a2744] text-[#8892a4] border border-[#2a3a5c] rounded-lg p-3 flex items-center space-x-2">
                  <div className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-bounce"></div>
                  <div className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: "0.2s" }}></div>
                  <div className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: "0.4s" }}></div>
                </div>
              </div>
            )}
          </div>

          {/* Quick query buttons */}
          <div className="p-3 border-t border-[#2a3a5c] bg-[#1a2744] bg-opacity-40 flex gap-2 overflow-x-auto shrink-0">
            <button 
              onClick={() => handleSendMessage("How do I reduce Southern Logistics' capital exposure?")}
              className="shrink-0 text-[10px] bg-[#16213e] hover:bg-[#2563EB] text-[#e2e8f0] font-semibold px-2 py-1 rounded border border-[#2a3a5c] transition-colors"
            >
              Expose Southern Capital
            </button>
            <button 
              onClick={() => handleSendMessage("Explain the WOC formula and target levels.")}
              className="shrink-0 text-[10px] bg-[#16213e] hover:bg-[#2563EB] text-[#e2e8f0] font-semibold px-2 py-1 rounded border border-[#2a3a5c] transition-colors"
            >
              Analyze Weeks of Cover
            </button>
          </div>

          {/* Input field */}
          <div className="p-3 border-t border-[#2a3a5c] bg-[#1a2744] flex items-center space-x-2 rounded-b-xl shrink-0">
            <input
              type="text"
              placeholder="Ask SMRITI Intelligence..."
              value={chatMessage}
              onChange={(e) => setChatMessage(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSendMessage()}
              className="flex-1 bg-[#16213e] border border-[#2a3a5c] text-white text-xs px-3 py-2 rounded focus:outline-none focus:border-[#2563EB]"
              disabled={isSending}
            />
            <button
              onClick={() => handleSendMessage()}
              className="bg-[#2563EB] hover:bg-opacity-95 text-white p-2 rounded flex items-center justify-center transition-colors shrink-0"
              disabled={isSending}
            >
              <span className="material-symbols-outlined text-sm">send</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
