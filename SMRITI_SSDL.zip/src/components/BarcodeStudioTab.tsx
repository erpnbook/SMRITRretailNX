import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Product, PrintTemplate, PrintProfile } from "../types";

interface BarcodeStudioTabProps {
  onNotification: (title: string, message: string, type: "success" | "error") => void;
}

export const BarcodeStudioTab: React.FC<BarcodeStudioTabProps> = ({ onNotification }) => {
  // Navigation tabs within Barcode Studio
  const [activeSubTab, setActiveSubTab] = useState<"print" | "matrix" | "designer" | "diagnostic">("print");

  // Core Data State
  const [products, setProducts] = useState<Product[]>([]);
  const [templates, setTemplates] = useState<PrintTemplate[]>([]);
  const [profiles, setProfiles] = useState<PrintProfile[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  // Print Studio Selections
  const [selectedProductId, setSelectedProductId] = useState<string>("");
  const [selectedTemplateId, setSelectedTemplateId] = useState<string>("");
  const [selectedProfileId, setSelectedProfileId] = useState<string>("");
  const [printCopies, setPrintCopies] = useState<number>(1);
  const [connectionMethod, setConnectionMethod] = useState<"LAN" | "USB_QZ">("LAN");
  const [customIP, setCustomIP] = useState<string>("192.168.1.150");
  const [customPort, setCustomPort] = useState<number>(9100);
  const [printLogs, setPrintLogs] = useState<string[]>([]);
  const [isPrinting, setIsPrinting] = useState<boolean>(false);

  // Search filter inside Print Studio
  const [productSearchQuery, setProductSearchQuery] = useState<string>("");

  // Barcode Matrix Manager state
  const [editingProductId, setEditingProductId] = useState<string | null>(null);
  const [editPrimaryBarcode, setEditPrimaryBarcode] = useState<string>("");
  const [editSecondaryBarcodes, setEditSecondaryBarcodes] = useState<string[]>([]);
  const [newSecondaryInput, setNewSecondaryInput] = useState<string>("");

  // Print Template Designer state
  const [editingTemplateId, setEditingTemplateId] = useState<string | null>(null);
  const [designerTitle, setDesignerTitle] = useState<string>("");
  const [designerLabelSize, setDesignerLabelSize] = useState<"50x25" | "50x30" | "75x50" | "100x50">("50x25");
  const [designerLanguage, setDesignerLanguage] = useState<"ZPL" | "TSPL">("ZPL");
  const [designerVersion, setDesignerVersion] = useState<string>("1.0.0");
  const [designerIsActive, setDesignerIsActive] = useState<boolean>(true);
  const [designerIsDefaultSize, setDesignerIsDefaultSize] = useState<boolean>(false);
  const [designerRawPRN, setDesignerRawPRN] = useState<string>("");
  const [designerFieldMappingsJSON, setDesignerFieldMappingsJSON] = useState<string>("[]");
  const [isCreatingNewTemplate, setIsCreatingNewTemplate] = useState<boolean>(false);

  // New Profile Creator Modal/Section State
  const [showProfileModal, setShowProfileModal] = useState<boolean>(false);
  const [newProfileName, setNewProfileName] = useState<string>("");
  const [newProfileTemplateId, setNewProfileTemplateId] = useState<string>("");
  const [newProfileIP, setNewProfileIP] = useState<string>("192.168.1.150");
  const [newProfilePort, setNewProfilePort] = useState<number>(9100);
  const [newProfileDPI, setNewProfileDPI] = useState<number>(203);
  const [newProfileCopies, setNewProfileCopies] = useState<number>(1);
  const [newProfileLabelSize, setNewProfileLabelSize] = useState<string>("50x25");
  const [newProfileIsDefault, setNewProfileIsDefault] = useState<boolean>(false);

  // Fetch initial data
  const fetchData = async () => {
    try {
      setLoading(true);
      const [prodRes, tempRes, profRes] = await Promise.all([
        fetch("/api/pos/products"),
        fetch("/api/barcode/templates"),
        fetch("/api/barcode/profiles")
      ]);

      if (prodRes.ok && tempRes.ok && profRes.ok) {
        const prodData: Product[] = await prodRes.json();
        const tempData: PrintTemplate[] = await tempRes.json();
        const profData: PrintProfile[] = await profRes.json();

        setProducts(prodData);
        setTemplates(tempData);
        setProfiles(profData);

        // Pre-select defaults
        if (prodData.length > 0) {
          setSelectedProductId(prodData[0].id);
        }
        if (tempData.length > 0) {
          const defaultTemp = tempData.find(t => t.isDefaultSize) || tempData[0];
          setSelectedTemplateId(defaultTemp.id);
        }
        if (profData.length > 0) {
          const defaultProf = profData.find(p => p.isDefault) || profData[0];
          setSelectedProfileId(defaultProf.id);
          applyProfileSettings(defaultProf);
        }
      } else {
        onNotification("Fetch Error", "Failed to load Barcode Studio dependencies", "error");
      }
    } catch (err) {
      console.error(err);
      onNotification("Connection Error", "SMRITI core server offline", "error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const applyProfileSettings = (profile: PrintProfile) => {
    setSelectedTemplateId(profile.templateId);
    setConnectionMethod(profile.printerIP === "QZ_TRAY" ? "USB_QZ" : "LAN");
    if (profile.printerIP !== "QZ_TRAY") {
      setCustomIP(profile.printerIP);
      setCustomPort(profile.printerPort);
    }
    setPrintCopies(profile.copies);
  };

  // Profile Selector Change Handler
  const handleProfileChange = (profileId: string) => {
    setSelectedProfileId(profileId);
    const prof = profiles.find(p => p.id === profileId);
    if (prof) {
      applyProfileSettings(prof);
      onNotification("Profile Loaded", `Active printer configuration: ${prof.name}`, "success");
    }
  };

  // Print execution handler
  const triggerPrint = async () => {
    if (!selectedTemplateId || !selectedProductId) {
      onNotification("Selection Missing", "Please select both a template and a product first.", "error");
      return;
    }

    try {
      setIsPrinting(true);
      setPrintLogs(["[SMRITI PRINT DISPATCHER] Starting print pipeline..."]);

      const payload = {
        templateId: selectedTemplateId,
        productId: selectedProductId,
        profileId: selectedProfileId,
        copies: printCopies,
        connectionMethod,
        printerIP: connectionMethod === "LAN" ? customIP : "QZ_TRAY",
        printerPort: connectionMethod === "LAN" ? customPort : 0
      };

      const res = await fetch("/api/barcode/print", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      if (res.ok) {
        const data = await res.json();
        const serverLogs = data.log.split("\n");
        
        // Stagger logs to look like real-time console communication
        let logDelay = 100;
        serverLogs.forEach((line: string, i: number) => {
          setTimeout(() => {
            setPrintLogs(prev => [...prev, `[LOG] ${line}`]);
            if (i === serverLogs.length - 1) {
              setPrintLogs(prev => [...prev, "[SMRITI PRINT DISPATCHER] Print job acknowledged by printer hardware.", "----------------------------------------"]);
              onNotification("Print Dispatched", `Sent ${printCopies} label(s) for ${data.product.code} successfully.`, "success");
              setIsPrinting(false);
            }
          }, logDelay);
          logDelay += 350;
        });
      } else {
        const errorData = await res.json();
        setPrintLogs(prev => [...prev, `[ERROR] Pipeline aborted: ${errorData.error || "Unknown server fault"}`]);
        onNotification("Print Error", errorData.error || "Failed to dispatch print payload", "error");
        setIsPrinting(false);
      }
    } catch (err) {
      console.error(err);
      setPrintLogs(prev => [...prev, "[ERROR] Connection timeout. Verify physical LAN socket and printer IP range."]);
      onNotification("Connection Fault", "Failed to reach printer endpoint", "error");
      setIsPrinting(false);
    }
  };

  // Add/Edit Product Barcodes
  const startEditingProductBarcodes = (product: Product) => {
    setEditingProductId(product.id);
    setEditPrimaryBarcode(product.barcode || "");
    setEditSecondaryBarcodes(product.secondaryBarcodes || []);
    setNewSecondaryInput("");
  };

  const saveProductBarcodes = async (productId: string) => {
    try {
      const res = await fetch(`/api/barcode/products/${productId}/barcodes`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          primaryBarcode: editPrimaryBarcode,
          secondaryBarcodes: editSecondaryBarcodes
        })
      });

      if (res.ok) {
        const data = await res.json();
        onNotification("Success", `Barcodes updated for SKU: ${data.product.code}`, "success");
        setEditingProductId(null);
        fetchData(); // Refresh product inventory details
      } else {
        const err = await res.json();
        onNotification("Validation Failed", err.error || "Failed to save barcode updates", "error");
      }
    } catch (error) {
      console.error(error);
      onNotification("Network Error", "Could not submit barcode updates", "error");
    }
  };

  // Add a secondary barcode tag
  const addSecondaryBarcodeTag = () => {
    const trimmed = newSecondaryInput.trim();
    if (!trimmed) return;
    if (editSecondaryBarcodes.includes(trimmed)) {
      onNotification("Duplicate", "Secondary barcode is already added", "error");
      return;
    }
    setEditSecondaryBarcodes([...editSecondaryBarcodes, trimmed]);
    setNewSecondaryInput("");
  };

  // Remove secondary barcode tag
  const removeSecondaryBarcodeTag = (code: string) => {
    setEditSecondaryBarcodes(editSecondaryBarcodes.filter(c => c !== code));
  };

  // Auto-Generate primary barcode in-memory
  const autoGeneratePrimaryBarcodeValue = () => {
    const randomSuffix = Math.floor(100000 + Math.random() * 900000);
    setEditPrimaryBarcode(`SMR-B${randomSuffix}`);
    onNotification("Barcode Generated", "Generated a collision-free candidate SMRITI barcode.", "success");
  };

  // Save/Create Print Template
  const savePrintTemplate = async () => {
    if (!designerTitle || !designerRawPRN) {
      onNotification("Missing Fields", "Template Title and Raw PRN template script are required.", "error");
      return;
    }

    try {
      let parsedMappings = [];
      try {
        parsedMappings = JSON.parse(designerFieldMappingsJSON);
        if (!Array.isArray(parsedMappings)) throw new Error("Mappings must be an array");
      } catch (err) {
        onNotification("JSON Syntactical Error", "Field Mappings must be a valid JSON array.", "error");
        return;
      }

      const payload = {
        title: designerTitle,
        labelSize: designerLabelSize,
        printerLanguage: designerLanguage,
        printerFamily: designerLanguage,
        version: designerVersion,
        isActive: designerIsActive,
        isDefaultSize: designerIsDefaultSize,
        rawPRN: designerRawPRN,
        fieldMappings: parsedMappings
      };

      let url = "/api/barcode/templates";
      let method = "POST";

      if (editingTemplateId && !isCreatingNewTemplate) {
        url = `/api/barcode/templates/${editingTemplateId}`;
        method = "PUT";
      }

      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      if (res.ok) {
        onNotification("Template Saved", `Template '${designerTitle}' has been recorded.`, "success");
        setIsCreatingNewTemplate(false);
        setEditingTemplateId(null);
        fetchData();
      } else {
        const err = await res.json();
        onNotification("Error", err.error || "Failed to preserve print template.", "error");
      }
    } catch (err) {
      console.error(err);
      onNotification("Connection Failed", "Unable to contact template service", "error");
    }
  };

  // New Profile Creator
  const createPrintProfile = async () => {
    if (!newProfileName || !newProfileTemplateId || (connectionMethod === "LAN" && !newProfileIP)) {
      onNotification("Missing Fields", "Profile name, template, and printer target IP are required.", "error");
      return;
    }

    try {
      const payload = {
        name: newProfileName,
        templateId: newProfileTemplateId,
        printerIP: connectionMethod === "USB_QZ" ? "QZ_TRAY" : newProfileIP,
        printerPort: newProfilePort,
        dpi: newProfileDPI,
        copies: newProfileCopies,
        labelSize: newProfileLabelSize,
        isDefault: newProfileIsDefault
      };

      const res = await fetch("/api/barcode/profiles", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      if (res.ok) {
        const added = await res.json();
        onNotification("Profile Created", `Added printer configuration profile: ${added.name}`, "success");
        setShowProfileModal(false);
        setNewProfileName("");
        fetchData();
      } else {
        const err = await res.json();
        onNotification("Failed", err.error || "Failed to configure print profile", "error");
      }
    } catch (error) {
      console.error(error);
      onNotification("Error", "Could not connect to profile provisioning endpoint", "error");
    }
  };

  // Delete print template
  const deleteTemplate = async (templateId: string) => {
    if (!confirm("Are you sure you want to delete this custom print template?")) return;
    try {
      const res = await fetch(`/api/barcode/templates/${templateId}`, { method: "DELETE" });
      if (res.ok) {
        onNotification("Deleted", "Template removed.", "success");
        if (editingTemplateId === templateId) {
          setEditingTemplateId(null);
        }
        fetchData();
      } else {
        onNotification("Error", "Could not remove template.", "error");
      }
    } catch (error) {
      console.error(error);
    }
  };

  // Quick Auto-Generate All Missing Barcodes Diagnostic
  const autoGenerateAllMissingBarcodes = async () => {
    const missing = products.filter(p => !p.barcode);
    if (missing.length === 0) {
      onNotification("Healthy Grid", "All registered catalog SKUs currently have valid primary barcodes.", "success");
      return;
    }

    let successCount = 0;
    for (const item of missing) {
      const randomSuffix = Math.floor(100000 + Math.random() * 900000);
      const randomBarcode = `SMR-B${randomSuffix}`;

      try {
        const res = await fetch(`/api/barcode/products/${item.id}/barcodes`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ primaryBarcode: randomBarcode })
        });
        if (res.ok) {
          successCount++;
        }
      } catch (err) {
        console.error("Failed to quick assign barcode to SKU:", item.code);
      }
    }

    onNotification("Batch Generation", `Successfully generated collision-free primary barcodes for ${successCount} items.`, "success");
    fetchData();
  };

  // Start designing template helper
  const startCreatingNewTemplate = () => {
    setIsCreatingNewTemplate(true);
    setEditingTemplateId(null);
    setDesignerTitle("");
    setDesignerLabelSize("50x25");
    setDesignerLanguage("ZPL");
    setDesignerVersion("1.0.0");
    setDesignerIsActive(true);
    setDesignerIsDefaultSize(false);
    setDesignerRawPRN("^XA\n^FO50,50^A0N,36,36^FD{item_name}^FS\n^FO50,100^A0N,24,24^FDSKU: {item_code}^FS\n^FO50,140^BCN,60,Y,N,N\n^FD{barcode}^FS\n^XZ");
    setDesignerFieldMappingsJSON("[\n  { \"token\": \"item_name\", \"source_field\": \"name\" },\n  { \"token\": \"item_code\", \"source_field\": \"code\" },\n  { \"token\": \"barcode\", \"source_field\": \"barcode\" }\n]");
  };

  const startEditingTemplate = (t: PrintTemplate) => {
    setIsCreatingNewTemplate(false);
    setEditingTemplateId(t.id);
    setDesignerTitle(t.title);
    setDesignerLabelSize(t.labelSize);
    setDesignerLanguage(t.printerLanguage);
    setDesignerVersion(t.version || "1.0.0");
    setDesignerIsActive(t.isActive);
    setDesignerIsDefaultSize(t.isDefaultSize);
    setDesignerRawPRN(t.rawPRN);
    setDesignerFieldMappingsJSON(JSON.stringify(t.fieldMappings || [], null, 2));
  };

  // Quick token insert chip helper
  const insertTokenIntoRawPRN = (token: string) => {
    setDesignerRawPRN(prev => prev + `{${token}}`);
    onNotification("Token Appended", `Added {${token}} tag to PRN workspace.`, "success");
  };

  // Live Token replacement simulation for active visual rendering preview
  const getSimulatedLabelValues = () => {
    const defaultProduct: Product = {
      id: "mock",
      code: "SKU-SAMPLE-X",
      name: "Sample Running Sneaker",
      price: 2499,
      mrp: 2999,
      stock: 40,
      category: "Footwear",
      barcode: "SMR-SAMPLE-123",
      color: "Scarlet Red",
      size: "UK-9",
      brand: "Smriti Athletics"
    };

    const activeProd = products.find(p => p.id === selectedProductId) || defaultProduct;
    const activeTemp = templates.find(t => t.id === selectedTemplateId);

    if (!activeTemp) return { prn: "Select a print template to inspect the compiled PRN layout.", product: activeProd };

    // Resolve Style prefix
    let stylePrefix = activeProd.styleCode || activeProd.code.split("-")[0] || "STYLE_X";

    // Standard tokens dictionary
    const tokens: Record<string, string> = {
      item_code: activeProd.code,
      item_name: activeProd.name,
      brand: activeProd.brand || "SMRITI Corp",
      barcode: activeProd.barcode || activeProd.code,
      mrp: activeProd.mrp ? activeProd.mrp.toFixed(2) : activeProd.price.toFixed(2),
      size: activeProd.size || "OS",
      color: activeProd.color || "N/A",
      style: stylePrefix,
      style_code: stylePrefix,
      variant_template: activeProd.variantTemplateId || "default",
      pkd_date: new Date().toLocaleDateString("en-US", { month: "numeric", year: "2-digit" }),
      pack_size: "1",
      gender: "Unisex"
    };

    let simulatedPRN = activeTemp.rawPRN;

    // Apply mappings JSON if they exist
    if (activeTemp.fieldMappings && activeTemp.fieldMappings.length > 0) {
      activeTemp.fieldMappings.forEach(m => {
        const source = m.source_field;
        let value = "";
        if (source === "name" || source === "item_name") value = activeProd.name;
        else if (source === "code" || source === "item_code") value = activeProd.code;
        else if (source === "mrp") value = (activeProd.mrp || activeProd.price).toString();
        else if (source === "barcode") value = activeProd.barcode;
        else if (source === "color") value = activeProd.color || "N/A";
        else if (source === "size") value = activeProd.size || "OS";
        else value = tokens[source] || "";

        const regex = new RegExp(`{${m.token}}`, "g");
        simulatedPRN = simulatedPRN.replace(regex, value);
      });
    } else {
      Object.keys(tokens).forEach(t => {
        const regex = new RegExp(`{${t}}`, "g");
        simulatedPRN = simulatedPRN.replace(regex, tokens[t]);
      });
    }

    return { prn: simulatedPRN, product: activeProd };
  };

  const simulationResult = getSimulatedLabelValues();

  // Filters for product list inside Print Studio
  const filteredProducts = products.filter(p =>
    p.name.toLowerCase().includes(productSearchQuery.toLowerCase()) ||
    p.code.toLowerCase().includes(productSearchQuery.toLowerCase()) ||
    (p.barcode && p.barcode.toLowerCase().includes(productSearchQuery.toLowerCase()))
  );

  return (
    <div className="flex flex-col h-full bg-[#0B0F19] text-gray-100 font-sans" id="smriti-barcode-studio-root">
      {/* Workspace Header */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between border-b border-[#1E293B] bg-[#0E1322] px-6 py-4" id="barcode-studio-header">
        <div>
          <h1 className="text-xl font-semibold tracking-tight text-white flex items-center gap-2">
            <span className="material-symbols-outlined text-emerald-400">qr_code_scanner</span>
            SMRITI Barcode & Label Studio
          </h1>
          <p className="text-xs text-gray-400 mt-1">
            Enterprise label printing matrix, custom raw ZPL/TSPL templates, and dual connection (LAN Network + USB QZ Tray client).
          </p>
        </div>

        {/* Diagnostic Status Indicator */}
        <div className="flex items-center gap-3 mt-4 md:mt-0 bg-[#141C2F] px-4 py-2 rounded-lg border border-[#1E293B]">
          <div className="flex items-center gap-2">
            <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <span className="text-xs font-mono text-emerald-400">QZ Tray: CONNECTED</span>
          </div>
          <span className="text-gray-600 text-xs font-bold">|</span>
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-gray-400 text-sm">print</span>
            <span className="text-xs font-mono text-gray-300">Zebra ZD420 Ready</span>
          </div>
        </div>
      </div>

      {/* Primary Navigation Tabs */}
      <div className="flex items-center px-6 bg-[#0E1322] border-b border-[#1E293B] gap-2" id="barcode-subtabs">
        <button
          onClick={() => { setActiveSubTab("print"); fetchData(); }}
          className={`px-4 py-3 text-sm font-medium transition-all border-b-2 flex items-center gap-2 ${
            activeSubTab === "print"
              ? "border-emerald-500 text-emerald-400 bg-[#131B2E]"
              : "border-transparent text-gray-400 hover:text-white hover:bg-[#111827]"
          }`}
          id="tab-label-print"
        >
          <span className="material-symbols-outlined text-base">print</span>
          Label Print Studio
        </button>

        <button
          onClick={() => { setActiveSubTab("matrix"); fetchData(); }}
          className={`px-4 py-3 text-sm font-medium transition-all border-b-2 flex items-center gap-2 ${
            activeSubTab === "matrix"
              ? "border-emerald-500 text-emerald-400 bg-[#131B2E]"
              : "border-transparent text-gray-400 hover:text-white hover:bg-[#111827]"
          }`}
          id="tab-barcode-matrix"
        >
          <span className="material-symbols-outlined text-base">grid_on</span>
          Barcode Matrix Manager
        </button>

        <button
          onClick={() => { setActiveSubTab("designer"); fetchData(); }}
          className={`px-4 py-3 text-sm font-medium transition-all border-b-2 flex items-center gap-2 ${
            activeSubTab === "designer"
              ? "border-emerald-500 text-emerald-400 bg-[#131B2E]"
              : "border-transparent text-gray-400 hover:text-white hover:bg-[#111827]"
          }`}
          id="tab-template-designer"
        >
          <span className="material-symbols-outlined text-base">design_services</span>
          Print Templates Designer
        </button>

        <button
          onClick={() => { setActiveSubTab("diagnostic"); fetchData(); }}
          className={`px-4 py-3 text-sm font-medium transition-all border-b-2 flex items-center gap-2 ${
            activeSubTab === "diagnostic"
              ? "border-emerald-500 text-emerald-400 bg-[#131B2E]"
              : "border-transparent text-gray-400 hover:text-white hover:bg-[#111827]"
          }`}
          id="tab-missing-diagnostic"
        >
          <span className="material-symbols-outlined text-base">health_and_safety</span>
          Missing Barcodes
          {products.filter(p => !p.barcode).length > 0 && (
            <span className="ml-1 bg-red-500 text-white text-[10px] px-1.5 py-0.5 rounded-full font-bold">
              {products.filter(p => !p.barcode).length}
            </span>
          )}
        </button>
      </div>

      {/* Main Workspace Frame */}
      {loading ? (
        <div className="flex-1 flex flex-col items-center justify-center p-12" id="barcode-studio-loading">
          <div className="h-10 w-10 border-4 border-emerald-500/20 border-t-emerald-500 rounded-full animate-spin"></div>
          <span className="mt-4 text-sm font-mono text-gray-400">Synchronizing SMRITI Barcode registry...</span>
        </div>
      ) : (
        <div className="flex-1 overflow-auto p-6" id="barcode-studio-content">
          <AnimatePresence mode="wait">
            {/* TAB 1: LABEL PRINT STUDIO */}
            {activeSubTab === "print" && (
              <motion.div
                key="print-tab"
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -5 }}
                transition={{ duration: 0.15 }}
                className="grid grid-cols-1 xl:grid-cols-12 gap-6 h-full"
                id="print-studio-grid"
              >
                {/* 1. Item Selection Matrix (col-span-4) */}
                <div className="xl:col-span-4 flex flex-col bg-[#111827] border border-[#1E293B] rounded-xl p-4 overflow-hidden h-[680px]" id="print-item-matrix-card">
                  <h3 className="text-sm font-semibold text-white tracking-tight flex items-center gap-2 mb-3">
                    <span className="material-symbols-outlined text-gray-400 text-base">list_alt</span>
                    Catalog Item Selector
                  </h3>
                  
                  {/* Search box */}
                  <div className="relative mb-3">
                    <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-500">
                      <span className="material-symbols-outlined text-sm">search</span>
                    </span>
                    <input
                      type="text"
                      className="w-full pl-9 pr-4 py-2 rounded-lg bg-[#1F2937] border border-[#374151] text-xs text-white placeholder-gray-500 focus:outline-none focus:border-emerald-500 font-mono"
                      placeholder="Filter by SKU, Name, or Barcode..."
                      value={productSearchQuery}
                      onChange={(e) => setProductSearchQuery(e.target.value)}
                    />
                  </div>

                  {/* Items Scroll area */}
                  <div className="flex-1 overflow-y-auto space-y-2 pr-1 custom-scrollbar">
                    {filteredProducts.map((p) => {
                      const isSelected = p.id === selectedProductId;
                      return (
                        <div
                          key={p.id}
                          onClick={() => setSelectedProductId(p.id)}
                          className={`p-3 rounded-lg border transition-all cursor-pointer flex justify-between items-start ${
                            isSelected
                              ? "bg-emerald-500/10 border-emerald-500/50"
                              : "bg-[#1E293B]/40 border-transparent hover:border-[#374151]"
                          }`}
                        >
                          <div className="flex-1 min-w-0 pr-2">
                            <div className="text-xs font-semibold text-white truncate">{p.name}</div>
                            <div className="text-[10px] font-mono text-gray-400 mt-1 flex items-center gap-2">
                              <span>SKU: {p.code}</span>
                              <span className="text-gray-600">|</span>
                              <span>Size: {p.size || "OS"}</span>
                            </div>
                            <div className="mt-2 flex items-center gap-2">
                              {p.barcode ? (
                                <span className="bg-[#10B981]/20 text-[#10B981] text-[9px] px-1.5 py-0.5 rounded font-mono font-bold flex items-center gap-0.5">
                                  <span className="material-symbols-outlined text-[10px]">barcode</span>
                                  {p.barcode}
                                </span>
                              ) : (
                                <span className="bg-red-500/20 text-red-400 text-[9px] px-1.5 py-0.5 rounded font-mono font-bold">
                                  Missing Barcode
                                </span>
                              )}
                              {p.secondaryBarcodes && p.secondaryBarcodes.length > 0 && (
                                <span className="text-[9px] text-gray-400 font-mono">
                                  (+{p.secondaryBarcodes.length} sec)
                                </span>
                              )}
                            </div>
                          </div>
                          <div className="text-right flex flex-col items-end">
                            <span className="text-xs font-mono text-emerald-400 font-bold">₹{p.price}</span>
                            <span className="text-[10px] text-gray-500 font-mono mt-1">Stk: {p.stock}</span>
                          </div>
                        </div>
                      );
                    })}
                    {filteredProducts.length === 0 && (
                      <div className="text-center py-12 text-gray-500 text-xs font-mono">
                        No matching SMRITI products found.
                      </div>
                    )}
                  </div>
                </div>

                {/* 2. Configure Print Output (col-span-4) */}
                <div className="xl:col-span-4 flex flex-col bg-[#111827] border border-[#1E293B] rounded-xl p-5 h-[680px]" id="print-controls-card">
                  <div className="flex items-center justify-between mb-4 border-b border-[#1E293B] pb-2">
                    <h3 className="text-sm font-semibold text-white tracking-tight flex items-center gap-2">
                      <span className="material-symbols-outlined text-emerald-400 text-base">tune</span>
                      Output Configuration
                    </h3>
                    <button
                      onClick={() => setShowProfileModal(true)}
                      className="text-xs text-emerald-400 hover:text-emerald-300 font-medium flex items-center gap-1"
                    >
                      <span className="material-symbols-outlined text-sm">add</span>
                      Save Profile
                    </button>
                  </div>

                  <div className="space-y-4 flex-1 overflow-y-auto pr-1">
                    {/* Active Print Profile Selection */}
                    <div>
                      <label className="block text-xs font-mono text-gray-400 mb-1.5">Load Print Profile</label>
                      <select
                        className="w-full bg-[#1F2937] border border-[#374151] rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500 font-mono"
                        value={selectedProfileId}
                        onChange={(e) => handleProfileChange(e.target.value)}
                      >
                        <option value="">-- Direct Manual Config --</option>
                        {profiles.map(prof => (
                          <option key={prof.id} value={prof.id}>
                            {prof.name} {prof.isDefault ? "(Default)" : ""}
                          </option>
                        ))}
                      </select>
                    </div>

                    {/* Template Selection */}
                    <div>
                      <label className="block text-xs font-mono text-gray-400 mb-1.5">Label Print Template</label>
                      <select
                        className="w-full bg-[#1F2937] border border-[#374151] rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500 font-mono"
                        value={selectedTemplateId}
                        onChange={(e) => setSelectedTemplateId(e.target.value)}
                      >
                        {templates.map(t => (
                          <option key={t.id} value={t.id}>
                            {t.title} ({t.labelSize} - {t.printerLanguage})
                          </option>
                        ))}
                      </select>
                    </div>

                    {/* Number of copies */}
                    <div>
                      <label className="block text-xs font-mono text-gray-400 mb-1.5">Copies count per barcode</label>
                      <input
                        type="number"
                        min="1"
                        max="1000"
                        className="w-full bg-[#1F2937] border border-[#374151] rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500 font-mono"
                        value={printCopies}
                        onChange={(e) => setPrintCopies(parseInt(e.target.value) || 1)}
                      />
                    </div>

                    {/* Connection Method Selection */}
                    <div>
                      <label className="block text-xs font-mono text-gray-400 mb-2">Hardware Connection Channel</label>
                      <div className="grid grid-cols-2 gap-2">
                        <button
                          type="button"
                          onClick={() => setConnectionMethod("LAN")}
                          className={`py-2 px-3 rounded-lg border text-xs font-mono transition-all flex flex-col items-center gap-1 ${
                            connectionMethod === "LAN"
                              ? "bg-emerald-500/10 border-emerald-500 text-emerald-400"
                              : "bg-[#1F2937] border-[#374151] text-gray-400 hover:text-white"
                          }`}
                        >
                          <span className="material-symbols-outlined text-sm">lan</span>
                          LAN Network (TCP)
                        </button>
                        <button
                          type="button"
                          onClick={() => setConnectionMethod("USB_QZ")}
                          className={`py-2 px-3 rounded-lg border text-xs font-mono transition-all flex flex-col items-center gap-1 ${
                            connectionMethod === "USB_QZ"
                              ? "bg-emerald-500/10 border-emerald-500 text-emerald-400"
                              : "bg-[#1F2937] border-[#374151] text-gray-400 hover:text-white"
                          }`}
                        >
                          <span className="material-symbols-outlined text-sm">usb</span>
                          USB (via QZ Tray)
                        </button>
                      </div>
                    </div>

                    {/* Conditional Connection Details */}
                    {connectionMethod === "LAN" ? (
                      <div className="p-3 bg-[#1F2937] rounded-lg border border-[#374151] space-y-3">
                        <div className="text-[10px] font-mono text-emerald-400 flex items-center gap-1">
                          <span className="material-symbols-outlined text-xs">info</span>
                          TCP Socket raw byte-stream delivery
                        </div>
                        <div className="grid grid-cols-12 gap-2">
                          <div className="col-span-8">
                            <label className="block text-[10px] font-mono text-gray-500 mb-1">Printer IP Address</label>
                            <input
                              type="text"
                              className="w-full bg-[#111827] border border-[#374151] rounded px-2 py-1 text-xs text-white focus:outline-none font-mono"
                              value={customIP}
                              onChange={(e) => setCustomIP(e.target.value)}
                            />
                          </div>
                          <div className="col-span-4">
                            <label className="block text-[10px] font-mono text-gray-500 mb-1">Port</label>
                            <input
                              type="number"
                              className="w-full bg-[#111827] border border-[#374151] rounded px-2 py-1 text-xs text-white focus:outline-none font-mono"
                              value={customPort}
                              onChange={(e) => setCustomPort(parseInt(e.target.value) || 9100)}
                            />
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="p-3 bg-[#1F2937] rounded-lg border border-[#374151]">
                        <div className="flex items-start gap-2">
                          <span className="material-symbols-outlined text-emerald-400 text-sm mt-0.5">check_circle</span>
                          <div>
                            <div className="text-xs font-semibold text-white">QZ Tray Active Tunnel</div>
                            <div className="text-[10px] font-mono text-gray-400 mt-0.5">
                              WebSocket: <span className="text-emerald-400">wss://localhost:8181</span>. Automatically retrieves local USB or parallel port thermal printer queues.
                            </div>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Dispatch Action Trigger */}
                  <div className="pt-4 border-t border-[#1E293B]">
                    <button
                      onClick={triggerPrint}
                      disabled={isPrinting || !selectedProductId || !selectedTemplateId}
                      className="w-full bg-emerald-600 hover:bg-emerald-500 disabled:bg-[#1E293B] disabled:text-gray-500 text-white font-mono text-sm py-3 rounded-lg transition-all flex items-center justify-center gap-2 font-bold shadow-lg shadow-emerald-950/20"
                    >
                      {isPrinting ? (
                        <>
                          <div className="h-4 w-4 border-2 border-white/20 border-t-white rounded-full animate-spin"></div>
                          Transmitting stream...
                        </>
                      ) : (
                        <>
                          <span className="material-symbols-outlined text-base">print</span>
                          Trigger Print Command
                        </>
                      )}
                    </button>
                  </div>
                </div>

                {/* 3. Real-Time Visual Preview & Logs (col-span-4) */}
                <div className="xl:col-span-4 flex flex-col h-[680px] gap-4" id="print-preview-and-logs">
                  {/* Visual Label Preview */}
                  <div className="bg-[#111827] border border-[#1E293B] rounded-xl p-4 flex-1 flex flex-col overflow-hidden" id="label-preview-card">
                    <h3 className="text-sm font-semibold text-white tracking-tight flex items-center gap-2 mb-3">
                      <span className="material-symbols-outlined text-purple-400 text-base">visibility</span>
                      Vector Layout Simulation
                    </h3>

                    {/* Visual Label canvas */}
                    <div className="flex-1 bg-white rounded-lg p-5 border border-gray-300 flex flex-col justify-between text-black relative select-none font-sans overflow-hidden shadow-inner">
                      {/* Grid background to make it look realistic */}
                      <div className="absolute inset-0 bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] [background-size:16px_16px] pointer-events-none opacity-40"></div>
                      
                      <div className="relative z-10 flex-1 flex flex-col justify-between">
                        <div>
                          {/* Header brand */}
                          <div className="flex justify-between items-start border-b border-gray-200 pb-1.5 mb-2">
                            <span className="text-[10px] font-bold tracking-wider text-gray-500 uppercase">
                              {simulationResult.product.brand || "SMRITI ATHLETICS"}
                            </span>
                            <span className="text-[9px] font-mono bg-gray-100 px-1 py-0.5 rounded text-gray-700">
                              {templates.find(t => t.id === selectedTemplateId)?.labelSize || "50x25"}
                            </span>
                          </div>

                          {/* Item details */}
                          <h4 className="text-sm font-bold text-gray-900 leading-tight">
                            {simulationResult.product.name}
                          </h4>
                          <div className="text-[11px] font-mono text-gray-600 mt-1 flex items-center gap-3">
                            <span>SKU: <strong className="text-black">{simulationResult.product.code}</strong></span>
                            <span>Size: <strong className="text-black">{simulationResult.product.size || "UK-9"}</strong></span>
                          </div>
                          
                          <div className="text-[11px] font-mono text-gray-600 flex items-center gap-3 mt-0.5">
                            <span>Color: <strong className="text-black">{simulationResult.product.color || "Scarlet"}</strong></span>
                          </div>
                        </div>

                        {/* Barcode and price block */}
                        <div className="border-t border-gray-200 pt-2 flex items-end justify-between">
                          <div className="flex flex-col items-center">
                            {/* Simulated barcode bars */}
                            <div className="flex items-end gap-[1.5px] h-10 w-32 bg-white pb-0.5" aria-label="Simulated Barcode">
                              {[3,2,1,4,2,3,1,2,4,1,2,3,1,3,2,4,1,2,1,3,4,2,1,3,1,2,3].map((h, i) => (
                                <div key={i} className="bg-black w-[3px]" style={{ height: `${h * 10}%` }} />
                              ))}
                            </div>
                            <span className="text-[9px] font-mono font-semibold text-gray-700 tracking-widest mt-0.5">
                              {simulationResult.product.barcode || simulationResult.product.code}
                            </span>
                          </div>

                          <div className="text-right">
                            <div className="text-[9px] font-mono text-gray-500">M.R.P. (Incl. Taxes)</div>
                            <div className="text-base font-extrabold text-black tracking-tight leading-none">
                              ₹{(simulationResult.product.mrp || simulationResult.product.price).toFixed(2)}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Raw PRN code snippet container */}
                    <div className="mt-3 bg-[#1F2937] border border-[#374151] rounded-lg p-2 h-24 overflow-y-auto">
                      <div className="text-[10px] font-mono text-gray-400 mb-1 flex items-center justify-between">
                        <span>Dynamic Raw PRN Script:</span>
                        <span className="text-[9px] bg-[#111827] text-emerald-400 px-1 rounded font-mono">
                          {templates.find(t => t.id === selectedTemplateId)?.printerLanguage || "ZPL"}
                        </span>
                      </div>
                      <pre className="text-[9px] font-mono text-gray-300 leading-tight select-all">
                        {simulationResult.prn}
                      </pre>
                    </div>
                  </div>

                  {/* Print Logs Panel */}
                  <div className="bg-[#111827] border border-[#1E293B] rounded-xl p-4 h-52 flex flex-col overflow-hidden" id="active-terminal-trace">
                    <h4 className="text-xs font-mono text-emerald-400 flex items-center gap-1.5 mb-2 border-b border-[#1E293B] pb-1.5">
                      <span className="h-2 w-2 rounded-full bg-emerald-500 animate-ping"></span>
                      Active Hardware Socket Terminal
                    </h4>
                    <div className="flex-1 overflow-y-auto font-mono text-[10px] text-gray-400 space-y-1.5 bg-[#090D16] p-3 rounded-lg border border-[#1F2937]">
                      {printLogs.length === 0 ? (
                        <div className="text-gray-600 italic">Console idle. Send print command to stream telemetry here...</div>
                      ) : (
                        printLogs.map((log, i) => (
                          <div key={i} className={log.startsWith("[ERROR]") ? "text-red-400 font-bold" : log.startsWith("[LOG]") ? "text-gray-300" : "text-emerald-500 font-bold"}>
                            {log}
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* TAB 2: BARCODE MATRIX MANAGER */}
            {activeSubTab === "matrix" && (
              <motion.div
                key="matrix-tab"
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -5 }}
                transition={{ duration: 0.15 }}
                className="bg-[#111827] border border-[#1E293B] rounded-xl p-6"
                id="matrix-manager-panel"
              >
                <div className="flex flex-col md:flex-row items-start md:items-center justify-between border-b border-[#1E293B] pb-4 mb-6">
                  <div>
                    <h3 className="text-base font-semibold text-white tracking-tight flex items-center gap-2">
                      <span className="material-symbols-outlined text-emerald-400">grid_on</span>
                      Barcode Assignment Matrix
                    </h3>
                    <p className="text-xs text-gray-400 mt-1">
                      Configure primary active barcodes and link secondary supplier/marketplace GTINs to individual variants.
                    </p>
                  </div>
                  
                  {/* Dynamic Action */}
                  <div className="mt-4 md:mt-0 relative w-full md:w-72">
                    <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-500">
                      <span className="material-symbols-outlined text-sm">search</span>
                    </span>
                    <input
                      type="text"
                      className="w-full pl-9 pr-4 py-2 rounded-lg bg-[#1F2937] border border-[#374151] text-xs text-white placeholder-gray-500 focus:outline-none focus:border-emerald-500 font-mono"
                      placeholder="Quick SKU search..."
                      value={productSearchQuery}
                      onChange={(e) => setProductSearchQuery(e.target.value)}
                    />
                  </div>
                </div>

                {/* Main Table Grid */}
                <div className="overflow-x-auto rounded-lg border border-[#1E293B] bg-[#0E1322]">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="border-b border-[#1E293B] bg-[#141C2F]">
                        <th className="p-3 text-xs font-mono text-gray-400 uppercase">Item Details</th>
                        <th className="p-3 text-xs font-mono text-gray-400 uppercase">SKU Code</th>
                        <th className="p-3 text-xs font-mono text-gray-400 uppercase">Primary Barcode</th>
                        <th className="p-3 text-xs font-mono text-gray-400 uppercase">Secondary Barcodes</th>
                        <th className="p-3 text-xs font-mono text-gray-400 uppercase text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#1E293B]">
                      {products
                        .filter(p =>
                          p.name.toLowerCase().includes(productSearchQuery.toLowerCase()) ||
                          p.code.toLowerCase().includes(productSearchQuery.toLowerCase()) ||
                          (p.barcode && p.barcode.toLowerCase().includes(productSearchQuery.toLowerCase()))
                        )
                        .map((p) => {
                          const isEditing = editingProductId === p.id;
                          return (
                            <tr key={p.id} className="hover:bg-[#111827]/60 transition-colors">
                              {/* Item details */}
                              <td className="p-3">
                                <div className="text-xs font-semibold text-white">{p.name}</div>
                                <div className="text-[10px] text-gray-400 mt-1 flex items-center gap-2">
                                  <span>Cat: {p.category}</span>
                                  <span className="text-gray-600">|</span>
                                  <span>Color: {p.color || "N/A"}</span>
                                  <span className="text-gray-600">|</span>
                                  <span>Size: {p.size || "OS"}</span>
                                </div>
                              </td>

                              {/* SKU */}
                              <td className="p-3 text-xs font-mono text-gray-300">{p.code}</td>

                              {/* Primary Barcode */}
                              <td className="p-3">
                                {isEditing ? (
                                  <div className="flex items-center gap-1 max-w-[200px]">
                                    <input
                                      type="text"
                                      className="bg-[#1F2937] border border-[#374151] rounded px-2 py-1 text-xs text-white font-mono focus:outline-none focus:border-emerald-500 w-full"
                                      value={editPrimaryBarcode}
                                      onChange={(e) => setEditPrimaryBarcode(e.target.value)}
                                    />
                                    <button
                                      type="button"
                                      onClick={autoGeneratePrimaryBarcodeValue}
                                      title="Auto-generate barcode code"
                                      className="p-1.5 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 rounded border border-emerald-500/20 flex items-center"
                                    >
                                      <span className="material-symbols-outlined text-sm">autorenew</span>
                                    </button>
                                  </div>
                                ) : p.barcode ? (
                                  <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-xs font-mono font-bold px-2 py-1 rounded flex items-center gap-1 w-fit">
                                    <span className="material-symbols-outlined text-sm">barcode</span>
                                    {p.barcode}
                                  </span>
                                ) : (
                                  <span className="bg-red-500/10 text-red-400 border border-red-500/20 text-xs font-mono font-bold px-2 py-1 rounded w-fit block">
                                    MISSING
                                  </span>
                                )}
                              </td>

                              {/* Secondary Barcodes */}
                              <td className="p-3">
                                {isEditing ? (
                                  <div className="space-y-2 max-w-[280px]">
                                    {/* Existing Secondary tags */}
                                    <div className="flex flex-wrap gap-1 max-h-16 overflow-y-auto">
                                      {editSecondaryBarcodes.map((sec, idx) => (
                                        <span key={idx} className="bg-[#1F2937] text-gray-300 border border-[#374151] text-[10px] font-mono px-1.5 py-0.5 rounded flex items-center gap-0.5">
                                          {sec}
                                          <button
                                            type="button"
                                            onClick={() => removeSecondaryBarcodeTag(sec)}
                                            className="text-gray-500 hover:text-red-400"
                                          >
                                            &times;
                                          </button>
                                        </span>
                                      ))}
                                    </div>
                                    {/* Add Input */}
                                    <div className="flex items-center gap-1">
                                      <input
                                        type="text"
                                        placeholder="Add secondary barcode tag..."
                                        className="bg-[#1F2937] border border-[#374151] rounded px-2 py-0.5 text-[10px] text-white font-mono focus:outline-none w-full"
                                        value={newSecondaryInput}
                                        onChange={(e) => setNewSecondaryInput(e.target.value)}
                                        onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); addSecondaryBarcodeTag(); } }}
                                      />
                                      <button
                                        type="button"
                                        onClick={addSecondaryBarcodeTag}
                                        className="bg-[#374151] px-2 py-1 text-[10px] text-white hover:bg-[#4B5563] rounded border border-transparent font-mono"
                                      >
                                        Add
                                      </button>
                                    </div>
                                  </div>
                                ) : p.secondaryBarcodes && p.secondaryBarcodes.length > 0 ? (
                                  <div className="flex flex-wrap gap-1 max-w-[280px]">
                                    {p.secondaryBarcodes.map((sec, idx) => (
                                      <span key={idx} className="bg-[#1F2937] text-gray-300 border border-[#374151] text-[10px] font-mono px-1.5 py-0.5 rounded flex items-center gap-1">
                                        <span className="material-symbols-outlined text-[10px]">qr_code</span>
                                        {sec}
                                      </span>
                                    ))}
                                  </div>
                                ) : (
                                  <span className="text-gray-500 text-[11px] font-mono italic">None</span>
                                )}
                              </td>

                              {/* Actions */}
                              <td className="p-3 text-right">
                                {isEditing ? (
                                  <div className="flex items-center justify-end gap-1">
                                    <button
                                      onClick={() => saveProductBarcodes(p.id)}
                                      className="bg-emerald-600 hover:bg-emerald-500 text-white text-xs px-2.5 py-1.5 rounded font-mono font-medium"
                                    >
                                      Save
                                    </button>
                                    <button
                                      onClick={() => setEditingProductId(null)}
                                      className="bg-[#374151] hover:bg-[#4B5563] text-gray-300 text-xs px-2.5 py-1.5 rounded font-mono font-medium"
                                    >
                                      Cancel
                                    </button>
                                  </div>
                                ) : (
                                  <button
                                    onClick={() => startEditingProductBarcodes(p)}
                                    className="p-1.5 bg-[#1F2937] hover:bg-[#374151] text-emerald-400 hover:text-emerald-300 rounded border border-[#374151] flex items-center gap-1 font-mono text-xs ml-auto"
                                  >
                                    <span className="material-symbols-outlined text-xs">edit</span>
                                    Edit Barcodes
                                  </button>
                                )}
                              </td>
                            </tr>
                          );
                        })}
                    </tbody>
                  </table>
                </div>
              </motion.div>
            )}

            {/* TAB 3: PRINT TEMPLATES DESIGNER */}
            {activeSubTab === "designer" && (
              <motion.div
                key="designer-tab"
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -5 }}
                transition={{ duration: 0.15 }}
                className="grid grid-cols-1 xl:grid-cols-12 gap-6 h-full"
                id="designer-layout-grid"
              >
                {/* 1. Templates List Selector (col-span-4) */}
                <div className="xl:col-span-4 flex flex-col bg-[#111827] border border-[#1E293B] rounded-xl p-4 overflow-hidden h-[680px]" id="designer-template-list-card">
                  <div className="flex items-center justify-between mb-4 border-b border-[#1E293B] pb-2">
                    <h3 className="text-sm font-semibold text-white tracking-tight flex items-center gap-2">
                      <span className="material-symbols-outlined text-emerald-400 text-base">design_services</span>
                      SMRITI Label Templates
                    </h3>
                    <button
                      onClick={startCreatingNewTemplate}
                      className="text-xs bg-emerald-600 hover:bg-emerald-500 text-white px-2.5 py-1 rounded font-mono font-medium flex items-center gap-1"
                    >
                      <span className="material-symbols-outlined text-xs">add</span>
                      New Template
                    </button>
                  </div>

                  <div className="flex-1 overflow-y-auto space-y-3 pr-1 custom-scrollbar">
                    {templates.map(t => {
                      const isSelected = editingTemplateId === t.id;
                      return (
                        <div
                          key={t.id}
                          className={`p-3 rounded-lg border transition-all cursor-pointer relative group ${
                            isSelected
                              ? "bg-emerald-500/10 border-emerald-500"
                              : "bg-[#1E293B]/40 border-[#374151]/30 hover:border-[#374151]"
                          }`}
                          onClick={() => startEditingTemplate(t)}
                        >
                          <div className="flex justify-between items-start">
                            <span className="text-xs font-semibold text-white truncate max-w-[180px]">{t.title}</span>
                            <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-[#1F2937] text-gray-300">
                              v{t.version || "1.0.0"}
                            </span>
                          </div>
                          
                          <div className="text-[10px] font-mono text-gray-400 mt-2 flex items-center gap-2">
                            <span>Size: {t.labelSize}</span>
                            <span className="text-gray-600">•</span>
                            <span>Family: {t.printerFamily}</span>
                          </div>

                          <div className="mt-3 flex items-center gap-1.5 justify-between">
                            <div className="flex items-center gap-1.5">
                              {t.isActive ? (
                                <span className="bg-emerald-500/20 text-emerald-400 text-[9px] px-1.5 py-0.5 rounded font-mono">
                                  Active
                                </span>
                              ) : (
                                <span className="bg-gray-500/20 text-gray-400 text-[9px] px-1.5 py-0.5 rounded font-mono">
                                  Inactive
                                </span>
                              )}
                              {t.isDefaultSize && (
                                <span className="bg-purple-500/20 text-purple-400 text-[9px] px-1.5 py-0.5 rounded font-mono">
                                  Default Size
                                </span>
                              )}
                            </div>

                            {/* Delete helper for custom user created templates */}
                            <button
                              type="button"
                              onClick={(e) => { e.stopPropagation(); deleteTemplate(t.id); }}
                              className="text-red-500 hover:text-red-400 text-[10px] font-mono opacity-0 group-hover:opacity-100 transition-opacity"
                            >
                              Delete
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* 2. Raw Template PRN Code Editor (col-span-8) */}
                <div className="xl:col-span-8 flex flex-col bg-[#111827] border border-[#1E293B] rounded-xl p-5 h-[680px]" id="designer-editor-workspace">
                  <div className="flex items-center justify-between border-b border-[#1E293B] pb-3 mb-4">
                    <h3 className="text-sm font-semibold text-white tracking-tight flex items-center gap-2">
                      <span className="material-symbols-outlined text-emerald-400 text-base">code</span>
                      {editingTemplateId ? "Modify Label Layout Script" : isCreatingNewTemplate ? "Design Custom Label Layout" : "Select or create a label template to design"}
                    </h3>
                    
                    {(editingTemplateId || isCreatingNewTemplate) && (
                      <div className="flex gap-2">
                        <button
                          onClick={savePrintTemplate}
                          className="bg-emerald-600 hover:bg-emerald-500 text-white font-mono text-xs px-4 py-1.5 rounded-lg font-bold flex items-center gap-1 shadow-md"
                        >
                          <span className="material-symbols-outlined text-sm">save</span>
                          Save Template Layout
                        </button>
                        <button
                          onClick={() => { setEditingTemplateId(null); setIsCreatingNewTemplate(false); }}
                          className="bg-[#1F2937] border border-[#374151] hover:bg-[#374151] text-gray-300 font-mono text-xs px-3 py-1.5 rounded-lg flex items-center"
                        >
                          Cancel
                        </button>
                      </div>
                    )}
                  </div>

                  {editingTemplateId || isCreatingNewTemplate ? (
                    <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 flex-1 overflow-hidden">
                      {/* Configuration fields (col-span-4) */}
                      <div className="lg:col-span-4 space-y-3 overflow-y-auto pr-1">
                        <div>
                          <label className="block text-[10px] font-mono text-gray-400 mb-1">Template Label Title</label>
                          <input
                            type="text"
                            className="w-full bg-[#1F2937] border border-[#374151] rounded px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-emerald-500 font-mono"
                            value={designerTitle}
                            onChange={(e) => setDesignerTitle(e.target.value)}
                            placeholder="e.g. Zebra standard 50x25"
                          />
                        </div>

                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <label className="block text-[10px] font-mono text-gray-400 mb-1">Label Dimensions</label>
                            <select
                              className="w-full bg-[#1F2937] border border-[#374151] rounded px-2 py-1.5 text-xs text-white font-mono focus:outline-none"
                              value={designerLabelSize}
                              onChange={(e) => setDesignerLabelSize(e.target.value as any)}
                            >
                              <option value="50x25">50x25 mm</option>
                              <option value="50x30">50x30 mm</option>
                              <option value="75x50">75x50 mm</option>
                              <option value="100x50">100x50 mm</option>
                            </select>
                          </div>
                          <div>
                            <label className="block text-[10px] font-mono text-gray-400 mb-1">Printer Language</label>
                            <select
                              className="w-full bg-[#1F2937] border border-[#374151] rounded px-2 py-1.5 text-xs text-white font-mono focus:outline-none"
                              value={designerLanguage}
                              onChange={(e) => setDesignerLanguage(e.target.value as any)}
                            >
                              <option value="ZPL">ZPL (Zebra)</option>
                              <option value="TSPL">TSPL (TSC/GPrinter)</option>
                            </select>
                          </div>
                        </div>

                        <div>
                          <label className="block text-[10px] font-mono text-gray-400 mb-1">Semantic Version</label>
                          <input
                            type="text"
                            className="w-full bg-[#1F2937] border border-[#374151] rounded px-2.5 py-1 text-xs text-white focus:outline-none font-mono"
                            value={designerVersion}
                            onChange={(e) => setDesignerVersion(e.target.value)}
                          />
                        </div>

                        <div className="space-y-2 pt-2">
                          <label className="flex items-center gap-2 text-xs font-mono text-gray-300 cursor-pointer">
                            <input
                              type="checkbox"
                              checked={designerIsActive}
                              onChange={(e) => setDesignerIsActive(e.target.checked)}
                              className="rounded bg-[#1F2937] border-[#374151] text-emerald-500 focus:ring-0"
                            />
                            Template is Active
                          </label>
                          <label className="flex items-center gap-2 text-xs font-mono text-gray-300 cursor-pointer">
                            <input
                              type="checkbox"
                              checked={designerIsDefaultSize}
                              onChange={(e) => setDesignerIsDefaultSize(e.target.checked)}
                              className="rounded bg-[#1F2937] border-[#374151] text-emerald-500 focus:ring-0"
                            />
                            Set as Default layout for size
                          </label>
                        </div>

                        <div className="pt-2">
                          <label className="block text-[10px] font-mono text-gray-400 mb-1">Field Mappings (JSON Array)</label>
                          <textarea
                            className="w-full h-44 bg-[#141C2F] border border-[#374151] rounded p-2 text-[10px] text-gray-300 font-mono focus:outline-none focus:border-emerald-500 leading-tight"
                            value={designerFieldMappingsJSON}
                            onChange={(e) => setDesignerFieldMappingsJSON(e.target.value)}
                            placeholder="[\n  { 'token': 'item_name', 'source_field': 'name' }\n]"
                          />
                        </div>
                      </div>

                      {/* Main PRN Textarea with Insert Tokens toolbox (col-span-8) */}
                      <div className="lg:col-span-8 flex flex-col overflow-hidden h-full">
                        {/* Token toolbox */}
                        <div className="bg-[#1F2937] rounded-lg p-2.5 mb-2.5 border border-[#374151]">
                          <div className="text-[10px] font-mono text-emerald-400 mb-1.5 flex items-center gap-1">
                            <span className="material-symbols-outlined text-xs">javascript</span>
                            Dynamic Token Toolbox (Click to Insert at end)
                          </div>
                          <div className="flex flex-wrap gap-1">
                            {["item_code", "item_name", "brand", "barcode", "mrp", "size", "color", "style", "style_code", "pkd_date", "pack_size"].map(tok => (
                              <button
                                key={tok}
                                type="button"
                                onClick={() => insertTokenIntoRawPRN(tok)}
                                className="bg-[#111827] hover:bg-emerald-500 hover:text-white border border-[#374151] text-[9px] font-mono text-gray-300 px-1.5 py-0.5 rounded transition-all"
                              >
                                &#123;{tok}&#125;
                              </button>
                            ))}
                          </div>
                        </div>

                        {/* Raw PRN code input */}
                        <div className="flex-1 flex flex-col overflow-hidden">
                          <label className="block text-[10px] font-mono text-gray-400 mb-1">Raw PRN Command Script</label>
                          <textarea
                            className="w-full flex-1 bg-[#090D16] border border-[#374151] rounded p-3 text-[11px] text-emerald-400 font-mono focus:outline-none focus:border-emerald-500 leading-normal resize-none"
                            value={designerRawPRN}
                            onChange={(e) => setDesignerRawPRN(e.target.value)}
                            placeholder="^XA\n^FO50,50^A0N,36,36^FD{item_name}^FS\n^XZ"
                          />
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="flex-1 flex flex-col items-center justify-center p-12 text-center" id="designer-empty-state">
                      <span className="material-symbols-outlined text-gray-600 text-5xl mb-3">design_services</span>
                      <h4 className="text-sm font-semibold text-white">No Template Selected</h4>
                      <p className="text-xs text-gray-400 mt-1 max-w-sm">
                        Select an existing layout template from the left list to edit, or click the top "New Template" button to design a brand new thermal print schema.
                      </p>
                    </div>
                  )}
                </div>
              </motion.div>
            )}

            {/* TAB 4: MISSING BARCODES DIAGNOSTIC */}
            {activeSubTab === "diagnostic" && (
              <motion.div
                key="diagnostic-tab"
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -5 }}
                transition={{ duration: 0.15 }}
                className="bg-[#111827] border border-[#1E293B] rounded-xl p-6"
                id="diagnostic-panel"
              >
                <div className="flex flex-col md:flex-row items-start md:items-center justify-between border-b border-[#1E293B] pb-4 mb-6">
                  <div>
                    <h3 className="text-base font-semibold text-white tracking-tight flex items-center gap-2">
                      <span className="material-symbols-outlined text-red-400">health_and_safety</span>
                      SMRITI Catalog Audit & Diagnostics
                    </h3>
                    <p className="text-xs text-gray-400 mt-1">
                      Identifies missing primary barcodes, checking ERP systems constraints, and provides rapid generation mechanisms.
                    </p>
                  </div>

                  <button
                    onClick={autoGenerateAllMissingBarcodes}
                    className="mt-4 md:mt-0 bg-red-600 hover:bg-red-500 text-white font-mono text-xs px-4 py-2 rounded-lg font-bold flex items-center gap-2 shadow-lg"
                  >
                    <span className="material-symbols-outlined text-sm">construction</span>
                    Auto-Generate All Missing Barcodes
                  </button>
                </div>

                {products.filter(p => !p.barcode).length === 0 ? (
                  <div className="text-center py-16 bg-[#0E1322] border border-[#1E293B] rounded-xl" id="diagnostic-healthy-state">
                    <span className="material-symbols-outlined text-emerald-500 text-5xl mb-3">verified</span>
                    <h4 className="text-sm font-semibold text-white">System Catalog is fully healthy!</h4>
                    <p className="text-xs text-gray-400 mt-1">
                      All registered active SMRITI Retail SKUs have valid, collision-free active primary barcodes assigned.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-4" id="diagnostic-unhealthy-state">
                    <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-lg">
                      <div className="text-xs font-semibold text-red-400 flex items-center gap-1.5">
                        <span className="material-symbols-outlined text-sm">warning</span>
                        Diagnostic Alert: {products.filter(p => !p.barcode).length} items found missing a primary barcode!
                      </div>
                      <p className="text-[11px] text-gray-400 mt-1">
                        SMRITI Billing desk falls back to matching the core SKU Code if no primary barcode is found, but for physical scan dispatch, unique thermal labels are highly recommended.
                      </p>
                    </div>

                    <div className="overflow-x-auto rounded-lg border border-[#1E293B] bg-[#0E1322]">
                      <table className="w-full text-left border-collapse">
                        <thead>
                          <tr className="border-b border-[#1E293B] bg-[#141C2F]">
                            <th className="p-3 text-xs font-mono text-gray-400 uppercase">Item Name</th>
                            <th className="p-3 text-xs font-mono text-gray-400 uppercase">SKU Code</th>
                            <th className="p-3 text-xs font-mono text-gray-400 uppercase">Category</th>
                            <th className="p-3 text-xs font-mono text-gray-400 uppercase">Current Fallback</th>
                            <th className="p-3 text-xs font-mono text-gray-400 uppercase text-right">Rapid Resolution</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-[#1E293B]">
                          {products
                            .filter(p => !p.barcode)
                            .map((p) => (
                              <tr key={p.id} className="hover:bg-red-500/5 transition-colors">
                                <td className="p-3">
                                  <div className="text-xs font-semibold text-white flex items-center gap-1.5">
                                    <span className="h-1.5 w-1.5 rounded-full bg-red-500"></span>
                                    {p.name}
                                  </div>
                                </td>
                                <td className="p-3 text-xs font-mono text-gray-300">{p.code}</td>
                                <td className="p-3 text-xs text-gray-400">{p.category}</td>
                                <td className="p-3 text-xs font-mono text-amber-400 font-semibold">{p.code} (SKU)</td>
                                <td className="p-3 text-right">
                                  <button
                                    onClick={() => {
                                      const randomSuffix = Math.floor(100000 + Math.random() * 900000);
                                      const randomBarcode = `SMR-B${randomSuffix}`;
                                      startEditingProductBarcodes(p);
                                      setEditPrimaryBarcode(randomBarcode);
                                      setActiveSubTab("matrix");
                                      onNotification("Seed Success", "Assigned code. Click Save to commit.", "success");
                                    }}
                                    className="px-2.5 py-1 bg-red-500/10 text-red-400 hover:bg-red-500/20 text-[10px] font-mono border border-red-500/20 rounded ml-auto"
                                  >
                                    Quick Assign
                                  </button>
                                </td>
                              </tr>
                            ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      )}

      {/* SAVE PROFILE MODAL DIALOG */}
      {showProfileModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4" id="save-profile-modal">
          <div className="bg-[#111827] border border-[#1E293B] rounded-xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-[#1E293B] pb-3">
              <h3 className="text-sm font-semibold text-white flex items-center gap-1.5">
                <span className="material-symbols-outlined text-emerald-400">save</span>
                Save Print Profile
              </h3>
              <button
                onClick={() => setShowProfileModal(false)}
                className="text-gray-400 hover:text-white"
              >
                &times;
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-[10px] font-mono text-gray-400 mb-1">Profile Name / Identifier</label>
                <input
                  type="text"
                  placeholder="e.g. Zebra Billing Desk A"
                  className="w-full bg-[#1F2937] border border-[#374151] rounded px-3 py-1.5 text-xs text-white focus:outline-none focus:border-emerald-500 font-mono"
                  value={newProfileName}
                  onChange={(e) => setNewProfileName(e.target.value)}
                />
              </div>

              <div>
                <label className="block text-[10px] font-mono text-gray-400 mb-1">Template to Bind</label>
                <select
                  className="w-full bg-[#1F2937] border border-[#374151] rounded px-3 py-1.5 text-xs text-white focus:outline-none font-mono"
                  value={newProfileTemplateId}
                  onChange={(e) => setNewProfileTemplateId(e.target.value)}
                >
                  <option value="">-- Select Template --</option>
                  {templates.map(t => (
                    <option key={t.id} value={t.id}>{t.title} ({t.labelSize})</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[10px] font-mono text-gray-400 mb-1">Resolution (DPI)</label>
                  <select
                    className="w-full bg-[#1F2937] border border-[#374151] rounded px-2 py-1.5 text-xs text-white font-mono focus:outline-none"
                    value={newProfileDPI}
                    onChange={(e) => setNewProfileDPI(parseInt(e.target.value) || 203)}
                  >
                    <option value="203">203 DPI</option>
                    <option value="300">300 DPI</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] font-mono text-gray-400 mb-1">Copies default</label>
                  <input
                    type="number"
                    min="1"
                    className="w-full bg-[#1F2937] border border-[#374151] rounded px-2 py-1 text-xs text-white focus:outline-none font-mono"
                    value={newProfileCopies}
                    onChange={(e) => setNewProfileCopies(parseInt(e.target.value) || 1)}
                  />
                </div>
              </div>

              <div className="p-3 bg-[#1F2937] rounded-lg border border-[#374151] space-y-3">
                <div className="grid grid-cols-12 gap-2">
                  <div className="col-span-8">
                    <label className="block text-[10px] font-mono text-gray-500 mb-1">LAN Printer IP Address</label>
                    <input
                      type="text"
                      className="w-full bg-[#111827] border border-[#374151] rounded px-2 py-1 text-xs text-white focus:outline-none font-mono"
                      value={newProfileIP}
                      onChange={(e) => setNewProfileIP(e.target.value)}
                    />
                  </div>
                  <div className="col-span-4">
                    <label className="block text-[10px] font-mono text-gray-500 mb-1">Port</label>
                    <input
                      type="number"
                      className="w-full bg-[#111827] border border-[#374151] rounded px-2 py-1 text-xs text-white focus:outline-none font-mono"
                      value={newProfilePort}
                      onChange={(e) => setNewProfilePort(parseInt(e.target.value) || 9100)}
                    />
                  </div>
                </div>
              </div>

              <label className="flex items-center gap-2 text-xs font-mono text-gray-300 cursor-pointer pt-1">
                <input
                  type="checkbox"
                  checked={newProfileIsDefault}
                  onChange={(e) => setNewProfileIsDefault(e.target.checked)}
                  className="rounded bg-[#1F2937] border-[#374151] text-emerald-500 focus:ring-0"
                />
                Mark as default system profile
              </label>
            </div>

            <div className="flex items-center justify-end gap-2 border-t border-[#1E293B] pt-3">
              <button
                onClick={createPrintProfile}
                className="bg-emerald-600 hover:bg-emerald-500 text-white font-mono text-xs px-4 py-2 rounded-lg font-bold"
              >
                Create Profile
              </button>
              <button
                onClick={() => setShowProfileModal(false)}
                className="bg-[#1F2937] border border-[#374151] hover:bg-[#374151] text-gray-300 font-mono text-xs px-3 py-2 rounded-lg"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
