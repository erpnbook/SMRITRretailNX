import React, { useState, useEffect } from "react";
import { 
  Plus, Search, Grid, Trash2, Edit3, RefreshCw, Tag, 
  Package, DollarSign, Percent, AlertCircle, X, Eye, 
  Layers, Barcode, CheckCircle2, ListFilter, Sliders,
  Settings, FolderKanban, FileSpreadsheet, BarChart3, Info
} from "lucide-react";
import { Product, AttributeDefinition, AttributeGroup } from "../types.js";
import { AttributeManagerSection } from "./AttributeManagerSection.js";
import { VariantTemplateSection } from "./VariantTemplateSection.js";
import { BulkImportSection } from "./BulkImportSection.js";
import { AttributeAnalyticsSection } from "./AttributeAnalyticsSection.js";

interface ItemMasterTabProps {
  products: Product[];
  onRefreshProducts: () => Promise<void>;
  onNotification: (title: string, message: string, type?: "success" | "error") => void;
}

type TabType = "registry" | "attributes" | "templates" | "bulk" | "analytics";

export const ItemMasterTab: React.FC<ItemMasterTabProps> = ({ 
  products, 
  onRefreshProducts, 
  onNotification 
}) => {
  const [activeTab, setActiveTab] = useState<TabType>("registry");
  const [loading, setLoading] = useState<boolean>(false);
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [selectedCategory, setSelectedCategory] = useState<string>("All");
  
  // Dynamic attribute architecture states
  const [definitions, setDefinitions] = useState<AttributeDefinition[]>([]);
  const [groups, setGroups] = useState<AttributeGroup[]>([]);
  const [categoryMappings, setCategoryMappings] = useState<any[]>([]);

  // Detail & Editing States
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [isCreating, setIsCreating] = useState<boolean>(false);

  // Form States
  const [formName, setFormName] = useState<string>("");
  const [formCode, setFormCode] = useState<string>("");
  const [formBarcode, setFormBarcode] = useState<string>("");
  const [formPrice, setFormPrice] = useState<number>(0);
  const [formMrp, setFormMrp] = useState<number>(0);
  const [formStock, setFormStock] = useState<number>(0);
  const [formCategory, setFormCategory] = useState<string>("Apparel");
  const [formGst, setFormGst] = useState<number>(18);
  const [formStyleCode, setFormStyleCode] = useState<string>("");
  
  // State for manual product custom attribute answers
  const [dynamicAttributes, setDynamicAttributes] = useState<Record<string, string>>({});

  useEffect(() => {
    // Load metadata configs
    const loadMetadata = async () => {
      try {
        const [res1, res2, res3] = await Promise.all([
          fetch("/api/attributes/definitions"),
          fetch("/api/attributes/groups"),
          fetch("/api/attributes/category-mappings")
        ]);
        if (res1.ok) setDefinitions(await res1.json());
        if (res2.ok) setGroups(await res2.json());
        if (res3.ok) setCategoryMappings(await res3.json());
      } catch (err) {
        console.error("Error loading attribute metadata in master:", err);
      }
    };
    loadMetadata();
  }, [products]);

  // Find active attribute group definitions for selected form category
  const getActiveGroup = () => {
    const mapping = categoryMappings.find(m => m.category.toLowerCase() === formCategory.toLowerCase());
    if (!mapping) return null;
    return groups.find(g => g.id === mapping.attributeGroupId) || null;
  };

  const activeGroup = getActiveGroup();
  const activeGroupAttrs = activeGroup 
    ? activeGroup.attributeIds.map(aid => definitions.find(d => d.id === aid)).filter((d): d is AttributeDefinition => !!d)
    : [];

  const categories = ["All", ...Array.from(new Set(products.map(p => p.category)))];

  const handleNameChange = (nameVal: string) => {
    setFormName(nameVal);
    const sanitized = nameVal.trim().toUpperCase().replace(/[^A-Z0-9]/g, "-").slice(0, 8);
    if (sanitized && !formStyleCode) {
      setFormStyleCode(sanitized);
    }
  };

  const handleOpenCreate = () => {
    setFormName("");
    setFormCode("");
    setFormBarcode("");
    setFormPrice(0);
    setFormMrp(0);
    setFormStock(0);
    setFormCategory("Apparel");
    setFormGst(18);
    setFormStyleCode("");
    setDynamicAttributes({});
    setIsCreating(true);
    setIsEditing(false);
  };

  const handleOpenEdit = (prod: Product) => {
    setSelectedProduct(prod);
    setFormName(prod.name);
    setFormCode(prod.code);
    setFormBarcode(prod.barcode);
    setFormPrice(prod.price);
    setFormMrp(prod.mrp || prod.price);
    setFormStock(prod.stock);
    setFormCategory(prod.category);
    setFormGst(prod.gstPercentage || 18);
    setFormStyleCode(prod.styleCode || "");
    setDynamicAttributes(prod.attributes || {});
    setIsEditing(true);
    setIsCreating(false);
  };

  const handleSaveItem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim() || !formCode.trim() || !formBarcode.trim()) {
      onNotification("Missing Fields", "Name, SKU Code, and Barcode are required parameters.", "error");
      return;
    }

    setLoading(true);
    try {
      // Validate mandatory attributes
      for (const attr of activeGroupAttrs) {
        if (attr.isMandatory && !dynamicAttributes[attr.name]) {
          onNotification("Mandatory Attribute", `Please specify a value for "${attr.label}".`, "error");
          setLoading(false);
          return;
        }
      }

      const payload = {
        name: formName,
        code: formCode,
        price: formPrice,
        stock: formStock,
        category: formCategory,
        barcode: formBarcode,
        mrp: formMrp || formPrice,
        gstPercentage: formGst,
        styleCode: formStyleCode || formCode,
        attributes: dynamicAttributes
      };

      const url = isEditing && selectedProduct 
        ? `/api/pos/products/${selectedProduct.id}` 
        : "/api/pos/products";
      const method = isEditing ? "PUT" : "POST";

      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      if (res.ok) {
        onNotification(
          "Success", 
          `SKU ${formCode} committed successfully to SMRITI Master Ledger.`, 
          "success"
        );
        setIsCreating(false);
        setIsEditing(false);
        setSelectedProduct(null);
        setDynamicAttributes({});
        await onRefreshProducts();
      } else {
        const err = await res.json();
        onNotification("Database Error", err.error || "Failed to commit record.", "error");
      }
    } catch (err) {
      onNotification("Connection Error", "Failed to connect with Master DB API.", "error");
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteItem = async (id: string, code: string) => {
    if (!confirm(`Are you sure you want to permanently delete SKU: ${code} from master registry?`)) return;
    
    setLoading(true);
    try {
      const res = await fetch(`/api/pos/products/${id}`, { method: "DELETE" });
      if (res.ok) {
        onNotification("Deleted", `SKU ${code} has been purged from system.`, "success");
        setSelectedProduct(null);
        setIsEditing(false);
        await onRefreshProducts();
      } else {
        const err = await res.json();
        onNotification("Purge Error", err.error, "error");
      }
    } catch (e) {
      onNotification("Connection Error", "Failed to reach Master DB.", "error");
    } finally {
      setLoading(false);
    }
  };

  const handleSuggestCodes = () => {
    if (!formName) {
      onNotification("No Name", "Please specify an item name first.", "error");
      return;
    }
    
    // Ordered segments based on Variant Dimension attributes of active group
    const style = formStyleCode || formName.trim().toUpperCase().slice(0, 3).replace(/[^A-Z]/g, "ITM");
    const parts = [style];

    activeGroupAttrs.forEach(attr => {
      if (attr.isVariantDimension && dynamicAttributes[attr.name]) {
        parts.push(dynamicAttributes[attr.name].toUpperCase().replace(/[^A-Z0-9]/g, ""));
      }
    });

    if (parts.length === 1) {
      parts.push(Math.floor(100 + Math.random() * 900).toString());
    }

    const suggestedSku = parts.join("-");
    const suggestedBarcode = `SMR-B${Math.floor(100000 + Math.random() * 900000)}`;

    setFormCode(suggestedSku);
    setFormBarcode(suggestedBarcode);
    if (!formMrp) setFormMrp(Math.round(formPrice * 1.25));

    onNotification("Automation Active", "Suggested compliance codes injected.", "success");
  };

  const filteredProducts = products.filter(p => {
    const matchesSearch = 
      p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.barcode.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (p.styleCode || "").toLowerCase().includes(searchTerm.toLowerCase()) ||
      Object.values(p.attributes || {}).some(v => v.toLowerCase().includes(searchTerm.toLowerCase()));
    
    const matchesCategory = selectedCategory === "All" || p.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  // KPI Calculations
  const totalSkus = products.length;
  const onHandStock = products.reduce((sum, p) => sum + p.stock, 0);
  const totalAssetValuation = products.reduce((sum, p) => sum + (p.stock * p.price), 0);
  const distinctCategories = Array.from(new Set(products.map(p => p.category))).length;

  return (
    <div className="space-y-6">
      
      {/* SMRITI Module Tab Bar Switcher */}
      <div className="flex border-b border-[#2a3a5c] overflow-x-auto select-none no-scrollbar">
        <button
          onClick={() => setActiveTab("registry")}
          className={`px-5 py-3 text-xs font-bold font-display uppercase tracking-wider flex items-center space-x-2 border-b-2 cursor-pointer transition-all ${
            activeTab === "registry" 
              ? "border-blue-500 text-blue-400 bg-[#16213e]/40" 
              : "border-transparent text-[#8892a4] hover:text-white hover:bg-[#16213e]/10"
          }`}
        >
          <Grid size={14} />
          <span>Catalog Registry</span>
        </button>
        <button
          onClick={() => setActiveTab("attributes")}
          className={`px-5 py-3 text-xs font-bold font-display uppercase tracking-wider flex items-center space-x-2 border-b-2 cursor-pointer transition-all ${
            activeTab === "attributes" 
              ? "border-blue-500 text-blue-400 bg-[#16213e]/40" 
              : "border-transparent text-[#8892a4] hover:text-white hover:bg-[#16213e]/10"
          }`}
        >
          <Settings size={14} />
          <span>Attribute Manager</span>
        </button>
        <button
          onClick={() => setActiveTab("templates")}
          className={`px-5 py-3 text-xs font-bold font-display uppercase tracking-wider flex items-center space-x-2 border-b-2 cursor-pointer transition-all ${
            activeTab === "templates" 
              ? "border-blue-500 text-blue-400 bg-[#16213e]/40" 
              : "border-transparent text-[#8892a4] hover:text-white hover:bg-[#16213e]/10"
          }`}
        >
          <FolderKanban size={14} />
          <span>Variant Templates</span>
        </button>
        <button
          onClick={() => setActiveTab("bulk")}
          className={`px-5 py-3 text-xs font-bold font-display uppercase tracking-wider flex items-center space-x-2 border-b-2 cursor-pointer transition-all ${
            activeTab === "bulk" 
              ? "border-blue-500 text-blue-400 bg-[#16213e]/40" 
              : "border-transparent text-[#8892a4] hover:text-white hover:bg-[#16213e]/10"
          }`}
        >
          <FileSpreadsheet size={14} />
          <span>Bulk Spreadsheet Importer</span>
        </button>
        <button
          onClick={() => setActiveTab("analytics")}
          className={`px-5 py-3 text-xs font-bold font-display uppercase tracking-wider flex items-center space-x-2 border-b-2 cursor-pointer transition-all ${
            activeTab === "analytics" 
              ? "border-blue-500 text-blue-400 bg-[#16213e]/40" 
              : "border-transparent text-[#8892a4] hover:text-white hover:bg-[#16213e]/10"
          }`}
        >
          <BarChart3 size={14} />
          <span>Attribute Intelligence</span>
        </button>
      </div>

      {/* RENDER ACTIVE MODULAR VIEW */}
      {activeTab === "attributes" && (
        <AttributeManagerSection onNotification={onNotification} />
      )}

      {activeTab === "templates" && (
        <VariantTemplateSection 
          products={products}
          onRefreshProducts={onRefreshProducts}
          onNotification={onNotification}
        />
      )}

      {activeTab === "bulk" && (
        <BulkImportSection 
          onRefreshProducts={onRefreshProducts}
          onNotification={onNotification}
        />
      )}

      {activeTab === "analytics" && (
        <AttributeAnalyticsSection onNotification={onNotification} />
      )}

      {activeTab === "registry" && (
        <div className="space-y-6">
          {/* Top Asset & Catalog Analytics */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-[#16213e] p-5 rounded-2xl border border-[#2a3a5c] shadow-lg flex items-center justify-between">
              <div>
                <span className="text-[10px] text-[#8892a4] block font-mono font-bold tracking-wider uppercase">ACTIVE SKU CATALOG</span>
                <span className="text-2xl font-bold font-display text-white mt-1 block">
                  {totalSkus} <span className="text-xs font-normal text-[#8892a4]">SKUs</span>
                </span>
                <span className="text-[11px] text-[#8892a4] mt-1 block">
                  Spread over <span className="text-white font-medium">{distinctCategories} categories</span>
                </span>
              </div>
              <div className="w-12 h-12 rounded-xl bg-indigo-950 flex items-center justify-center text-indigo-400 border border-indigo-900">
                <Layers size={22} />
              </div>
            </div>

            <div className="bg-[#16213e] p-5 rounded-2xl border border-[#2a3a5c] shadow-lg flex items-center justify-between">
              <div>
                <span className="text-[10px] text-[#8892a4] block font-mono font-bold tracking-wider uppercase">TOTAL STOCK UNITS</span>
                <span className="text-2xl font-bold font-display text-emerald-400 mt-1 block">
                  {onHandStock.toLocaleString("en-IN")} <span className="text-xs font-normal text-[#8892a4]">Units</span>
                </span>
                <span className="text-[11px] text-[#8892a4] mt-1 block">
                  Average stock per SKU: <span className="text-white font-medium">{totalSkus > 0 ? Math.round(onHandStock / totalSkus) : 0} pcs</span>
                </span>
              </div>
              <div className="w-12 h-12 rounded-xl bg-emerald-950 flex items-center justify-center text-emerald-400 border border-emerald-900">
                <Package size={22} />
              </div>
            </div>

            <div className="bg-[#16213e] p-5 rounded-2xl border border-[#2a3a5c] shadow-lg flex items-center justify-between">
              <div>
                <span className="text-[10px] text-[#8892a4] block font-mono font-bold tracking-wider uppercase">NET ASSET VALUATION</span>
                <span className="text-2xl font-bold font-display text-white mt-1 block">
                  ₹{totalAssetValuation.toLocaleString("en-IN")}
                </span>
                <span className="text-[11px] text-[#8892a4] mt-1 block">
                  Calculated at selling rate
                </span>
              </div>
              <div className="w-12 h-12 rounded-xl bg-sky-950 flex items-center justify-center text-sky-400 border border-sky-900">
                <DollarSign size={22} />
              </div>
            </div>

            <div className="bg-[#16213e] p-5 rounded-2xl border border-[#2a3a5c] shadow-lg flex items-center justify-between">
              <div>
                <span className="text-[10px] text-[#8892a4] block font-mono font-bold tracking-wider uppercase">EXTENSIBILITY METRIC</span>
                <span className="text-2xl font-bold font-display text-violet-400 mt-1 block">
                  {definitions.length} <span className="text-xs font-normal text-[#8892a4]">Attrs</span>
                </span>
                <span className="text-[11px] text-[#8892a4] mt-1 block">
                  Data-driven product schema
                </span>
              </div>
              <div className="w-12 h-12 rounded-xl bg-violet-950 flex items-center justify-center text-violet-400 border border-violet-900">
                <CheckCircle2 size={22} />
              </div>
            </div>
          </div>

          {/* Primary Toolbar Controls */}
          <div className="bg-[#16213e] border border-[#2a3a5c] rounded-2xl p-4 flex flex-col md:flex-row items-center justify-between gap-4">
            
            {/* Search & Category Filter */}
            <div className="flex flex-col sm:flex-row gap-3 w-full md:w-auto flex-1">
              <div className="relative flex-1 max-w-md">
                <span className="absolute left-3 top-2.5 text-[#8892a4]"><Search size={14} /></span>
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Search by SKU, Name, Barcode, Attributes..."
                  className="w-full bg-[#121c35] border border-[#2a3a5c] rounded-lg pl-9 pr-4 py-2 text-xs text-white placeholder-[#8892a4] focus:outline-none focus:border-blue-500"
                />
              </div>

              <div className="flex items-center space-x-2">
                <span className="text-xs text-[#8892a4] font-mono whitespace-nowrap"><ListFilter size={13} className="inline mr-1" /> Category:</span>
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="bg-[#121c35] border border-[#2a3a5c] rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500 font-bold"
                >
                  {categories.map(cat => (
                    <option key={cat} value={cat}>{cat}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Action Controls */}
            <div className="flex items-center space-x-3 w-full md:w-auto justify-end">
              <button
                onClick={onRefreshProducts}
                className="p-2.5 rounded-lg bg-[#1a2744] hover:bg-[#20315a] border border-[#2a3a5c] text-[#8892a4] hover:text-white transition-colors cursor-pointer"
                title="Refresh Ledger"
              >
                <RefreshCw size={14} className={loading ? "animate-spin" : ""} />
              </button>
              <button
                onClick={handleOpenCreate}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-500 active:bg-blue-700 text-white rounded-lg text-xs font-bold flex items-center space-x-2 shadow-lg hover:shadow-blue-950/30 transition-all cursor-pointer"
              >
                <Plus size={14} />
                <span>Add SMRITI SKU</span>
              </button>
            </div>
          </div>

          {/* Main Grid View Panel */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Left 2/3: Catalog list */}
            <div className="lg:col-span-2 space-y-6">
              
              {/* Create or Edit Form Panel */}
              {(isCreating || isEditing) && (
                <div className="bg-[#16213e] border border-[#2a3a5c] rounded-2xl overflow-hidden shadow-xl animate-in fade-in duration-200">
                  <div className="bg-[#1c2a4f] border-b border-[#2a3a5c] px-6 py-4 flex items-center justify-between">
                    <div>
                      <h3 className="font-display font-bold text-sm text-white">
                        {isEditing ? `Edit Master Record: ${formCode}` : "Quick Create SMRITI Item SKU"}
                      </h3>
                      <p className="text-[11px] text-[#8892a4]">Treats dynamic attributes as data, satisfying multiple retail categories perfectly</p>
                    </div>
                    <button 
                      onClick={() => {
                        setIsCreating(false);
                        setIsEditing(false);
                        setSelectedProduct(null);
                        setDynamicAttributes({});
                      }}
                      className="p-1 rounded bg-[#20315a] text-[#8892a4] hover:text-white transition-colors cursor-pointer"
                    >
                      <X size={16} />
                    </button>
                  </div>

                  <form onSubmit={handleSaveItem} className="p-6 space-y-5">
                    {/* 1. Item Name and Group */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="text-[10px] font-mono uppercase tracking-wider text-[#8892a4] block mb-1">Item Display Name *</label>
                        <input
                          type="text"
                          required
                          value={formName}
                          onChange={(e) => handleNameChange(e.target.value)}
                          placeholder="e.g. Vintage Leather Sneakers"
                          className="w-full bg-[#121c35] border border-[#2a3a5c] rounded-lg px-3 py-2 text-xs text-white placeholder-[#8892a4] focus:outline-none focus:border-blue-500"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] font-mono uppercase tracking-wider text-[#8892a4] block mb-1">Category / Group</label>
                        <select
                          value={formCategory}
                          onChange={(e) => setFormCategory(e.target.value)}
                          className="w-full bg-[#121c35] border border-[#2a3a5c] rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
                        >
                          <option value="Apparel">Apparel</option>
                          <option value="Footwear">Footwear</option>
                          <option value="Pharmacy">Pharmacy</option>
                          <option value="Jewellery">Jewellery</option>
                          <option value="Accessories">Accessories</option>
                          <option value="General">General</option>
                        </select>
                      </div>
                    </div>

                    {/* SMRITI Dynamic Attributes Mapping Form */}
                    <div className="bg-[#121c35] p-4 rounded-xl border border-[#2a3a5c]/50 space-y-4">
                      <div className="flex justify-between items-center">
                        <span className="text-[10px] font-mono uppercase tracking-wider text-indigo-400">
                          {activeGroup ? `Dynamic schema: ${activeGroup.name}` : "General Core Specifications"}
                        </span>
                        <button
                          type="button"
                          onClick={handleSuggestCodes}
                          className="text-[10px] font-bold text-blue-400 hover:text-blue-300 flex items-center space-x-1 cursor-pointer"
                        >
                          <Sliders size={11} />
                          <span>Code Construction Autopilot</span>
                        </button>
                      </div>

                      {/* Render dynamic attributes inputs from group */}
                      {activeGroupAttrs.length > 0 ? (
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                          {activeGroupAttrs.map(attr => (
                            <div key={attr.id}>
                              <label className="text-[9px] font-mono text-[#8892a4] block mb-1 uppercase">
                                {attr.label} {attr.isMandatory && <span className="text-rose-400 font-bold">*</span>}
                              </label>
                              {attr.dataType === "select" ? (
                                <select
                                  value={dynamicAttributes[attr.name] || ""}
                                  onChange={(e) => setDynamicAttributes(prev => ({ ...prev, [attr.name]: e.target.value }))}
                                  className="w-full bg-[#16213e] border border-[#2a3a5c] rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-blue-500"
                                >
                                  <option value="">-- Pick option --</option>
                                  {attr.validValues.map(v => (
                                    <option key={v} value={v}>{v}</option>
                                  ))}
                                </select>
                              ) : (
                                <input
                                  type={attr.dataType === "number" ? "number" : "text"}
                                  value={dynamicAttributes[attr.name] || ""}
                                  onChange={(e) => setDynamicAttributes(prev => ({ ...prev, [attr.name]: e.target.value }))}
                                  placeholder={`Enter ${attr.label}`}
                                  className="w-full bg-[#16213e] border border-[#2a3a5c] rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-blue-500 font-mono"
                                />
                              )}
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="text-[11px] text-[#8892a4] py-1 border-b border-[#2a3a5c]/20">
                          No category-specific attributes found. Create attribute groups to map Apparel, Footwear, Saree, Sourcing, or Pharmacy attributes automatically.
                        </div>
                      )}

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                        <div>
                          <label className="text-[9px] font-mono text-[#8892a4] block mb-1">Style Reference Code</label>
                          <input
                            type="text"
                            value={formStyleCode}
                            onChange={(e) => setFormStyleCode(e.target.value)}
                            placeholder="Style Code"
                            className="w-full bg-[#16213e] border border-[#2a3a5c] rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-blue-500 font-mono uppercase"
                          />
                        </div>
                        <div>
                          <label className="text-[9px] font-mono text-[#8892a4] block mb-1">SKU Unique Code *</label>
                          <input
                            type="text"
                            required
                            disabled={isEditing}
                            value={formCode}
                            onChange={(e) => setFormCode(e.target.value)}
                            placeholder="SKU Code (e.g. TSH-COT-L)"
                            className="w-full bg-[#16213e] border border-[#2a3a5c] rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-blue-500 font-mono disabled:opacity-50"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="text-[9px] font-mono text-[#8892a4] block mb-1">Barcode / POS Identifier *</label>
                        <div className="relative">
                          <span className="absolute left-3 top-2.5 text-[#8892a4]"><Barcode size={12} /></span>
                          <input
                            type="text"
                            required
                            value={formBarcode}
                            onChange={(e) => setFormBarcode(e.target.value)}
                            placeholder="e.g. SMR-B301"
                            className="w-full bg-[#16213e] border border-[#2a3a5c] rounded-lg pl-8 pr-3 py-1.5 text-xs text-white focus:outline-none focus:border-blue-500 font-mono"
                          />
                        </div>
                      </div>
                    </div>

                    {/* SMRITI Financials / Taxation / Multi-price Engine */}
                    <div className="bg-[#121c35] p-4 rounded-xl border border-[#2a3a5c]/50 space-y-4">
                      <span className="text-[10px] font-mono uppercase tracking-wider text-indigo-400 block">Financial & Cost Configuration</span>
                      
                      <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                        <div>
                          <label className="text-[9px] font-mono text-[#8892a4] block mb-1">Standard Price (₹) *</label>
                          <input
                            type="number"
                            min="0"
                            required
                            value={formPrice || ""}
                            onChange={(e) => {
                              const val = parseFloat(e.target.value) || 0;
                              setFormPrice(val);
                              if (!formMrp || formMrp < val) setFormMrp(Math.round(val * 1.25));
                            }}
                            placeholder="Selling Price"
                            className="w-full bg-[#16213e] border border-[#2a3a5c] rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-blue-500 font-mono"
                          />
                        </div>
                        <div>
                          <label className="text-[9px] font-mono text-[#8892a4] block mb-1">Maximum Retail Price (MRP)</label>
                          <input
                            type="number"
                            min="0"
                            value={formMrp || ""}
                            onChange={(e) => setFormMrp(parseFloat(e.target.value) || 0)}
                            placeholder="MRP (₹)"
                            className="w-full bg-[#16213e] border border-[#2a3a5c] rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-blue-500 font-mono"
                          />
                        </div>
                        <div>
                          <label className="text-[9px] font-mono text-[#8892a4] block mb-1">GST Tax Category %</label>
                          <select
                            value={formGst}
                            onChange={(e) => setFormGst(parseInt(e.target.value) || 18)}
                            className="w-full bg-[#16213e] border border-[#2a3a5c] rounded-lg px-2 py-1.5 text-xs text-white focus:outline-none focus:border-blue-500 font-mono"
                          >
                            <option value="5">5% GST (Standard Fabrics)</option>
                            <option value="12">12% GST (Semi-premium)</option>
                            <option value="18">18% GST (Standard Retail)</option>
                            <option value="28">28% GST (Luxury Items)</option>
                          </select>
                        </div>
                        <div>
                          <label className="text-[9px] font-mono text-[#8892a4] block mb-1">Initial Stock On Hand</label>
                          <input
                            type="number"
                            min="0"
                            value={formStock}
                            onChange={(e) => setFormStock(Math.max(0, parseInt(e.target.value) || 0))}
                            placeholder="Opening Stock"
                            className="w-full bg-[#16213e] border border-[#2a3a5c] rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-blue-500 font-mono"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Form Buttons */}
                    <div className="flex justify-end space-x-3 pt-3 border-t border-[#2a3a5c]/50">
                      <button
                        type="button"
                        onClick={() => {
                          setIsCreating(false);
                          setIsEditing(false);
                          setSelectedProduct(null);
                        }}
                        className="px-4 py-2 rounded-lg bg-[#1a2744] hover:bg-[#20315a] border border-[#2a3a5c] text-[#8892a4] hover:text-white text-xs font-semibold transition-colors cursor-pointer"
                      >
                        Cancel Draft
                      </button>
                      <button
                        type="submit"
                        disabled={loading}
                        className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-bold rounded-lg text-xs shadow-lg transition-colors cursor-pointer"
                      >
                        {loading ? "Writing SKU..." : isEditing ? "Save Adjustments" : "Commit to SMRITI Database"}
                      </button>
                    </div>
                  </form>
                </div>
              )}

              {/* SMRITI Catalog Database Grid */}
              <div className="bg-[#16213e] border border-[#2a3a5c] rounded-2xl overflow-hidden shadow-lg">
                <div className="p-4 bg-[#1c2a4f] border-b border-[#2a3a5c] flex items-center justify-between">
                  <span className="text-xs font-bold font-display uppercase tracking-wider text-white">
                    Core Catalog Master Registry
                  </span>
                  <span className="text-[10px] font-mono text-[#8892a4]">
                    Showing {filteredProducts.length} of {products.length} registered SKUs
                  </span>
                </div>

                {filteredProducts.length === 0 ? (
                  <div className="p-16 text-center text-[#8892a4] text-xs">
                    No matched SMRITI inventory items found. Adjust filter criteria or add a new catalog item.
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs border-collapse">
                      <thead>
                        <tr className="bg-[#121c35] text-[#8892a4] uppercase font-mono text-[9px] tracking-wider border-b border-[#2a3a5c]">
                          <th className="px-5 py-3">SKU Code</th>
                          <th className="px-5 py-3">Item Details</th>
                          <th className="px-5 py-3 text-right">Selling Rate</th>
                          <th className="px-5 py-3 text-right">MRP (₹)</th>
                          <th className="px-5 py-3 text-right">Tax (GST)</th>
                          <th className="px-5 py-3 text-right">On Hand</th>
                          <th className="px-5 py-3 text-center">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {filteredProducts.map(p => (
                          <tr 
                            key={p.id} 
                            onClick={() => setSelectedProduct(p)}
                            className={`border-b border-[#2a3a5c]/40 hover:bg-[#1c2a4f]/50 cursor-pointer transition-colors ${
                              selectedProduct?.id === p.id ? "bg-[#1c2a4f]" : ""
                            }`}
                          >
                            <td className="px-5 py-3 font-mono font-bold text-white">
                              <div className="flex items-center space-x-1.5">
                                <Tag size={12} className="text-[#8892a4]" />
                                <span>{p.code}</span>
                              </div>
                            </td>
                            <td className="px-5 py-3">
                              <div className="text-white font-medium">{p.name}</div>
                              <div className="text-[10px] text-[#8892a4] mt-0.5 font-mono max-w-sm truncate">
                                Category: <span className="text-indigo-300 font-semibold">{p.category}</span>
                                {p.attributes && Object.entries(p.attributes).map(([k, v]) => (
                                  <span key={k}> • {k}: <span className="text-white">{v}</span></span>
                                ))}
                              </div>
                            </td>
                            <td className="px-5 py-3 text-right font-mono font-semibold text-emerald-400">
                              ₹{p.price.toLocaleString("en-IN")}
                            </td>
                            <td className="px-5 py-3 text-right font-mono text-[#8892a4]">
                              ₹{(p.mrp || p.price).toLocaleString("en-IN")}
                            </td>
                            <td className="px-5 py-3 text-right font-mono text-amber-400 font-bold">
                              {p.gstPercentage || 18}%
                            </td>
                            <td className="px-5 py-3 text-right font-mono">
                              <span className={`font-semibold ${p.stock < 10 ? "text-rose-400" : "text-[#e2e8f0]"}`}>
                                {p.stock} pcs
                              </span>
                            </td>
                            <td className="px-5 py-3 text-center" onClick={(e) => e.stopPropagation()}>
                              <div className="flex items-center justify-center space-x-2">
                                <button
                                  onClick={() => handleOpenEdit(p)}
                                  className="p-1 rounded hover:bg-[#1a2744] text-sky-400"
                                  title="Edit SKU details"
                                >
                                  <Edit3 size={14} />
                                </button>
                                <button
                                  onClick={() => handleDeleteItem(p.id, p.code)}
                                  className="p-1 rounded hover:bg-rose-950 text-rose-400"
                                  title="Purge Master SKU"
                                >
                                  <Trash2 size={14} />
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </div>

            {/* Right 1/3: Inspector Panel Drawer */}
            <div className="lg:col-span-1">
              {selectedProduct ? (
                <div className="bg-[#16213e] border border-[#2a3a5c] rounded-2xl p-5 space-y-6 shadow-xl sticky top-24">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="text-[10px] bg-emerald-950 text-emerald-400 border border-emerald-900 rounded px-1.5 py-0.2 font-mono font-bold uppercase">SMRITI SKU MASTER</span>
                      </div>
                      <h4 className="font-display font-bold text-base text-white mt-1.5">{selectedProduct.name}</h4>
                      <p className="text-[11px] text-[#8892a4] mt-0.5">Barcode ID: <span className="text-white font-mono font-medium">{selectedProduct.barcode}</span></p>
                    </div>
                    <button
                      onClick={() => setSelectedProduct(null)}
                      className="p-1 rounded bg-[#1a2744] text-[#8892a4] hover:text-white transition-colors cursor-pointer"
                    >
                      <X size={14} />
                    </button>
                  </div>

                  {/* Specifications checklist */}
                  <div className="space-y-4 border-t border-b border-[#2a3a5c] py-4">
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-[#8892a4] font-medium">SKU Unique Code</span>
                      <span className="text-white font-mono">{selectedProduct.code}</span>
                    </div>
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-[#8892a4] font-medium">Style Reference</span>
                      <span className="text-white font-mono">{selectedProduct.styleCode || selectedProduct.code}</span>
                    </div>
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-[#8892a4] font-medium">Segment Category</span>
                      <span className="text-indigo-300 font-semibold">{selectedProduct.category}</span>
                    </div>
                    {selectedProduct.attributes && Object.entries(selectedProduct.attributes).map(([k, v]) => (
                      <div key={k} className="flex justify-between items-center text-xs">
                        <span className="text-[#8892a4] font-medium">{k}</span>
                        <span className="text-white font-bold">{v}</span>
                      </div>
                    ))}
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-[#8892a4] font-medium">GST Percentage</span>
                      <span className="text-amber-400 font-mono font-bold">{selectedProduct.gstPercentage || 18}%</span>
                    </div>
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-[#8892a4] font-medium">Consolidated Asset Value</span>
                      <span className="text-emerald-400 font-mono font-semibold">₹{(selectedProduct.stock * selectedProduct.price).toLocaleString("en-IN")}</span>
                    </div>
                  </div>

                  {/* Price Metrics Breakdown */}
                  <div className="space-y-3">
                    <span className="text-[10px] font-mono uppercase tracking-wider text-[#8892a4] block">COMPLIANCE PRICING PROFILE</span>
                    <div className="bg-[#121c35] p-3.5 rounded-xl border border-[#2a3a5c]/60 space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-xs text-[#8892a4]">Retail Selling Price</span>
                        <span className="text-sm font-semibold text-white font-mono">₹{selectedProduct.price.toLocaleString("en-IN")}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-xs text-[#8892a4]">Maximum Retail Price</span>
                        <span className="text-sm font-semibold text-[#8892a4] font-mono">₹{(selectedProduct.mrp || selectedProduct.price).toLocaleString("en-IN")}</span>
                      </div>
                      <div className="pt-2 border-t border-[#2a3a5c]/40 flex justify-between items-center">
                        <span className="text-xs text-[#8892a4]">Active Margin Cap</span>
                        <span className="text-xs font-bold text-indigo-400">
                          {selectedProduct.mrp ? Math.round(((selectedProduct.mrp - selectedProduct.price) / selectedProduct.mrp) * 100) : 0}% potential
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Active stock replenishment advice */}
                  <div className="bg-[#1a2744] p-4 rounded-xl border border-dashed border-[#2a3a5c] space-y-2">
                    <div className="flex items-center space-x-2 text-indigo-400">
                      <AlertCircle size={15} />
                      <span className="text-xs font-bold font-display">SMRITI Warehouse Advice</span>
                    </div>
                    <p className="text-[11px] text-[#8892a4] leading-relaxed">
                      {selectedProduct.stock < 10 
                        ? "Critical levels detected. Expedite replenishment with Distributor / Kora Apparels."
                        : "Stock level is stable. Average Weeks of Cover is healthy. No action required."}
                    </p>
                  </div>

                  <div className="flex gap-2.5 pt-2">
                    <button
                      onClick={() => handleOpenEdit(selectedProduct)}
                      className="flex-1 py-2.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center justify-center space-x-2 transition-colors cursor-pointer"
                    >
                      <Edit3 size={13} />
                      <span>Update Details</span>
                    </button>
                    <button
                      onClick={() => handleDeleteItem(selectedProduct.id, selectedProduct.code)}
                      className="px-3.5 rounded-lg bg-rose-950/40 hover:bg-rose-950/80 text-rose-400 border border-rose-900 flex items-center justify-center transition-colors cursor-pointer"
                      title="Purge SKU"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>
              ) : (
                <div className="bg-[#16213e] border border-[#2a3a5c] rounded-2xl p-6 text-center space-y-4 shadow-lg sticky top-24">
                  <div className="w-12 h-12 rounded-full bg-[#121c35] flex items-center justify-center text-[#8892a4] mx-auto border border-[#2a3a5c]">
                    <Sliders size={20} />
                  </div>
                  <div>
                    <h4 className="font-display font-bold text-sm text-white">Variant Inspector active</h4>
                    <p className="text-xs text-[#8892a4] max-w-xs mx-auto mt-1 leading-relaxed">
                      Select any product row from the registry grid to inspect its variant structure, inventory health indexes, and pricing profile.
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
