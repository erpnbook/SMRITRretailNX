import React, { useState } from "react";
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, Legend } from "recharts";
import { PSVParty } from "../types";

interface PsvTabProps {
  psvParties: PSVParty[];
}

export const PsvTab: React.FC<PsvTabProps> = ({ psvParties }) => {
  const [selectedPartyId, setSelectedPartyId] = useState<string>(psvParties[0]?.id || "");

  const activeParty = psvParties.find(p => p.id === selectedPartyId);

  // Formatting INR Currencies
  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
      maximumFractionDigits: 0
    }).format(val);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      
      {/* Left Column: Distributor List (Col span 5) */}
      <div className="lg:col-span-5 bg-[#16213e] p-5 rounded-xl border border-[#2a3a5c] space-y-4">
        <div>
          <h3 className="font-display font-semibold text-lg text-white">Party Stock Visibility (PSV)</h3>
          <p className="text-xs text-[#8892a4]">Downstream Channel Distribution Ledger</p>
        </div>

        <div className="space-y-3 max-h-[440px] overflow-y-auto custom-scrollbar pr-1">
          {psvParties.map(p => (
            <div
              key={p.id}
              onClick={() => setSelectedPartyId(p.id)}
              className={`p-4 rounded-xl border cursor-pointer transition-all space-y-2.5 ${
                selectedPartyId === p.id 
                  ? "bg-[#1a2744] border-[#2563EB]" 
                  : "bg-[#16213e] border-[#2a3a5c] hover:border-[#2563EB]"
              }`}
            >
              <div className="flex justify-between items-start">
                <div>
                  <h4 className="font-semibold text-white text-sm font-display">{p.name}</h4>
                  <p className="text-[11px] text-[#8892a4] flex items-center">
                    <span className="material-symbols-outlined text-xs mr-1 text-gray-500">location_on</span>
                    {p.location}
                  </p>
                </div>
                <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded border ${
                  p.status === "Healthy" 
                    ? "bg-emerald-500 bg-opacity-20 text-emerald-400 border-emerald-500" 
                    : p.status === "Monitor"
                    ? "bg-amber-500 bg-opacity-20 text-amber-400 border-amber-500"
                    : "bg-rose-500 bg-opacity-20 text-rose-400 border-rose-500"
                }`}>
                  {p.status}
                </span>
              </div>

              <div className="grid grid-cols-3 gap-2 text-center border-t border-[#2a3a5c] pt-2.5 mt-1">
                <div>
                  <span className="block text-[9px] uppercase text-[#8892a4]">Stock Balance</span>
                  <span className="text-xs font-bold text-white font-mono">{p.stockCount} u</span>
                </div>
                <div>
                  <span className="block text-[9px] uppercase text-[#8892a4]">Sell-Through</span>
                  <span className="text-xs font-bold text-emerald-400 font-mono">{p.sellThrough}%</span>
                </div>
                <div>
                  <span className="block text-[9px] uppercase text-[#8892a4]">Runway Cover</span>
                  <span className="text-xs font-bold text-amber-400 font-mono">{p.weeksOfCover} W</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Right Column: Detailed analysis with charts (Col span 7) */}
      <div className="lg:col-span-7 bg-[#16213e] p-6 rounded-xl border border-[#2a3a5c] flex flex-col justify-between">
        {activeParty ? (
          <div className="space-y-6">
            <div className="flex justify-between items-center pb-3 border-b border-[#2a3a5c]">
              <div>
                <span className="text-xs text-[#8892a4] font-mono">Node ID: {activeParty.id}</span>
                <h3 className="font-display font-semibold text-lg text-white mt-0.5">{activeParty.name}</h3>
              </div>
              <div className="text-right">
                <span className="text-[10px] text-[#8892a4] block uppercase">Locked Capital</span>
                <span className="text-rose-400 font-bold font-mono text-sm">{formatCurrency(activeParty.capitalLocked)}</span>
              </div>
            </div>

            {/* Recharts daily velocity ledger */}
            <div>
              <h4 className="text-xs font-semibold text-[#8892a4] uppercase font-display mb-4">4-Day Stock vs Sales Velocity Trends</h4>
              <div className="h-60 bg-[#1a2744] bg-opacity-40 p-4 rounded-lg border border-[#2a3a5c]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={activeParty.history} margin={{ top: 5, right: 5, left: -20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#2a3a5c" />
                    <XAxis dataKey="date" stroke="#8892a4" fontSize={11} />
                    <YAxis stroke="#8892a4" fontSize={11} />
                    <Tooltip 
                      contentStyle={{ backgroundColor: "#16213e", borderColor: "#2a3a5c", borderRadius: 8 }}
                      labelStyle={{ color: "white" }}
                    />
                    <Legend wrapperStyle={{ fontSize: 11 }} />
                    <Line type="monotone" dataKey="stock" stroke="#2563EB" activeDot={{ r: 6 }} name="On-Hand Inventory" strokeWidth={2} />
                    <Line type="monotone" dataKey="sales" stroke="#22c55e" name="Daily Sales Velocity" strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Suggestions card */}
            <div className="bg-[#1a2744] rounded-lg p-4 border border-[#2a3a5c] flex items-start space-x-3">
              <span className="material-symbols-outlined text-amber-400 mt-0.5">lightbulb</span>
              <div>
                <h5 className="text-xs font-bold text-white uppercase tracking-wider font-display">Operational Recommendation</h5>
                <p className="mt-1 text-xs text-[#e2e8f0] leading-relaxed">
                  {activeParty.status === "Critical" 
                    ? "Capital is severely stagnating. Immediately deploy pricing markdown schemes, bundle promotions, or generate an internal stock transfer request to move high-demand categories to active retail zones."
                    : activeParty.status === "Monitor"
                    ? "Stock runways are slightly below safety parameters. Monitor sales velocity indices and configure alert flags before generating standard replenishments."
                    : "No action required. Node continues to maintain high efficiency and steady stock turns. Proceed with standard operational cycles."}
                </p>
              </div>
            </div>

          </div>
        ) : (
          <div className="h-full flex items-center justify-center text-center text-[#8892a4]">
            Select a distributor to view downstream inventory analysis.
          </div>
        )}
      </div>

    </div>
  );
};
