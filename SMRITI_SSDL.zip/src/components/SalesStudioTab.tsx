import React, { useState, useEffect } from "react";
import { 
  FileText, Plus, Search, Grid, Trash2, Edit3, 
  RefreshCw, User, Calendar, DollarSign, Percent, 
  ArrowRight, FileCheck, AlertCircle, ShoppingCart, 
  CheckCircle2, X, Eye, Layers
} from "lucide-react";
import { Product, Quotation, SalesOrder, SalesItemLine } from "../types.js";

interface SalesStudioTabProps {
  products: Product[];
  onNotification: (title: string, message: string, type?: "success" | "error") => void;
}

export const SalesStudioTab: React.FC<SalesStudioTabProps> = ({ products, onNotification }) => {
  const [quotations, setQuotations] = useState<Quotation[]>([]);
  const [salesOrders, setSalesOrders] = useState<SalesOrder[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [subView, setSubView] = useState<"quotations" | "orders">("quotations");

  // Selection states for detail view
  const [selectedQuotation, setSelectedQuotation] = useState<Quotation | null>(null);
  const [selectedOrder, setSelectedOrder] = useState<SalesOrder | null>(null);

  // Editor states (for creating/editing Quotations)
  const [isCreatingQuotation, setIsCreatingQuotation] = useState<boolean>(false);
  const [editorCustomerName, setEditorCustomerName] = useState<string>("");
  const [editorItems, setEditorItems] = useState<any[]>([]); // items in current draft
  const [editorStatus, setEditorStatus] = useState<"Draft" | "Submitted">("Draft");

  // Dual entry mode state
  const [entryMode, setEntryMode] = useState<"manual" | "matrix">("manual");
  
  // Manual entry fields
  const [selectedProduct, setSelectedProduct] = useState<string>("");
  const [manualQty, setManualQty] = useState<number>(1);
  const [manualTax, setManualTax] = useState<number>(18);

  // Matrix entry fields
  const [selectedBaseArticle, setSelectedBaseArticle] = useState<string>("");
  const [selectedBaseColor, setSelectedBaseColor] = useState<string>("");
  const [matrixQuantities, setMatrixQuantities] = useState<Record<string, number>>({}); // productId -> qty

  useEffect(() => {
    fetchQuotations();
    fetchSalesOrders();
  }, []);

  const fetchQuotations = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/sales/quotations");
      if (res.ok) {
        const data = await res.json();
        setQuotations(data);
      }
    } catch (e) {
      onNotification("Sync Error", "Failed to load quotations ledger.", "error");
    } finally {
      setLoading(false);
    }
  };

  const fetchSalesOrders = async () => {
    try {
      const res = await fetch("/api/sales/orders");
      if (res.ok) {
        const data = await res.json();
        setSalesOrders(data);
      }
    } catch (e) {
      onNotification("Sync Error", "Failed to load sales orders ledger.", "error");
    }
  };

  // Group products for Matrix Mode
  // articleNames are distinct names (e.g. Classic Cotton T-Shirt, Retro Leather Sneakers)
  const baseArticles = Array.from(new Set(products.map(p => p.name)));

  // Get colors available for the selected base article
  const availableColors = Array.from(
    new Set(
      products
        .filter(p => p.name === selectedBaseArticle)
        .map(p => p.color || "N/A")
    )
  );

  // Get variants (sizes) for selected base article & color
  const matrixVariants = products.filter(
    p => p.name === selectedBaseArticle && (p.color || "N/A") === selectedBaseColor
  );

  const handleAddManualItem = () => {
    const prod = products.find(p => p.id === selectedProduct);
    if (!prod) {
      onNotification("Invalid Product", "Please select a product variant.", "error");
      return;
    }
    if (manualQty <= 0) {
      onNotification("Invalid Quantity", "Quantity must be greater than zero.", "error");
      return;
    }

    // Check if variant already exists in current draft items list
    const existingIndex = editorItems.findIndex(item => item.productId === prod.id);
    if (existingIndex > -1) {
      const updated = [...editorItems];
      updated[existingIndex].quantity += manualQty;
      updated[existingIndex].totalAmount = updated[existingIndex].quantity * updated[existingIndex].price * (1 + updated[existingIndex].taxRate/100);
      setEditorItems(updated);
    } else {
      setEditorItems([
        ...editorItems,
        {
          productId: prod.id,
          code: prod.code,
          name: prod.name,
          color: prod.color,
          size: prod.size,
          quantity: manualQty,
          price: prod.price,
          taxRate: manualTax
        }
      ]);
    }

    // Reset inputs
    setSelectedProduct("");
    setManualQty(1);
    onNotification("Item Added", `${prod.name} (${prod.size}) added to draft items list.`, "success");
  };

  const handleAddMatrixItems = () => {
    const itemsToAdd: any[] = [];
    let addedCount = 0;

    matrixVariants.forEach(variant => {
      const qty = matrixQuantities[variant.id] || 0;
      if (qty > 0) {
        itemsToAdd.push({
          productId: variant.id,
          code: variant.code,
          name: variant.name,
          color: variant.color,
          size: variant.size,
          quantity: qty,
          price: variant.price,
          taxRate: 18 // standard retail tax
        });
        addedCount += qty;
      }
    });

    if (itemsToAdd.length === 0) {
      onNotification("No Quantities Entered", "Please enter quantities for at least one size variant.", "error");
      return;
    }

    // Merge into editorItems
    const updated = [...editorItems];
    itemsToAdd.forEach(newItem => {
      const existingIdx = updated.findIndex(item => item.productId === newItem.productId);
      if (existingIdx > -1) {
        updated[existingIdx].quantity += newItem.quantity;
      } else {
        updated.push(newItem);
      }
    });

    setEditorItems(updated);
    // Reset matrix inputs
    setMatrixQuantities({});
    onNotification("Matrix Items Added", `Successfully loaded ${addedCount} units from matrix grid to draft.`, "success");
  };

  const handleRemoveDraftItem = (index: number) => {
    const updated = editorItems.filter((_, i) => i !== index);
    setEditorItems(updated);
  };

  const handleSaveQuotation = async () => {
    if (!editorCustomerName.trim()) {
      onNotification("Validation Error", "Please specify Customer Name.", "error");
      return;
    }
    if (editorItems.length === 0) {
      onNotification("Validation Error", "Please add at least one item line.", "error");
      return;
    }

    try {
      const response = await fetch("/api/sales/quotations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          customerName: editorCustomerName,
          items: editorItems,
          status: editorStatus
        })
      });

      if (response.ok) {
        onNotification("Success", "Quotation generated successfully and written to ledger.", "success");
        setIsCreatingQuotation(false);
        setEditorCustomerName("");
        setEditorItems([]);
        fetchQuotations();
      } else {
        const err = await response.json();
        onNotification("Error", err.error || "Failed to generate quotation.", "error");
      }
    } catch (e) {
      onNotification("Network Error", "Connection failed while writing quotation.", "error");
    }
  };

  const handleConvertQuotation = async (qId: string) => {
    try {
      const res = await fetch(`/api/sales/quotations/convert/${qId}`, { method: "POST" });
      if (res.ok) {
        const data = await res.json();
        onNotification("Order Confirmed", `Quotation converted successfully to ${data.salesOrder.orderNo}!`, "success");
        fetchQuotations();
        fetchSalesOrders();
        // Clear selected view or update it
        setSelectedQuotation(null);
      } else {
        const err = await res.json();
        onNotification("Conversion Failed", err.error || "Failed to convert.", "error");
      }
    } catch (e) {
      onNotification("Network Error", "Connection failed during conversion.", "error");
    }
  };

  const handleDeleteQuotation = async (qId: string) => {
    if (!confirm("Are you sure you want to permanently delete this quotation draft?")) return;
    try {
      const res = await fetch(`/api/sales/quotations/${qId}`, { method: "DELETE" });
      if (res.ok) {
        onNotification("Success", "Quotation draft deleted.", "success");
        setSelectedQuotation(null);
        fetchQuotations();
      } else {
        const err = await res.json();
        onNotification("Error", err.error, "error");
      }
    } catch (e) {
      onNotification("Network Error", "Failed to connect to backend.", "error");
    }
  };

  // Quick Stats
  const activeDrafts = quotations.filter(q => q.status === "Draft").length;
  const submittedQuotations = quotations.filter(q => q.status === "Submitted").length;
  const convertedQuotations = quotations.filter(q => q.status === "Converted").length;

  const totalSalesOrdered = salesOrders.reduce((sum, so) => sum + so.grandTotal, 0);

  return (
    <div className="space-y-6">
      
      {/* Overview Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#16213e] p-5 rounded-2xl border border-[#2a3a5c] shadow-lg flex items-center justify-between">
          <div>
            <span className="text-[10px] text-[#8892a4] block font-mono font-bold tracking-wider uppercase">ACTIVE QUOTATIONS</span>
            <span className="text-2xl font-bold font-display text-white mt-1 block">
              {quotations.length} <span className="text-xs font-normal text-[#8892a4]">Docs</span>
            </span>
            <span className="text-[11px] text-indigo-400 mt-1 block font-medium">
              {activeDrafts} Drafts • {submittedQuotations} Submitted
            </span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-indigo-950 flex items-center justify-center text-indigo-400 border border-indigo-900">
            <FileText size={22} />
          </div>
        </div>

        <div className="bg-[#16213e] p-5 rounded-2xl border border-[#2a3a5c] shadow-lg flex items-center justify-between">
          <div>
            <span className="text-[10px] text-[#8892a4] block font-mono font-bold tracking-wider uppercase">SALES ORDERS GENERATED</span>
            <span className="text-2xl font-bold font-display text-emerald-400 mt-1 block">
              {salesOrders.length} <span className="text-xs font-normal text-[#8892a4]">Orders</span>
            </span>
            <span className="text-[11px] text-[#8892a4] mt-1 block">
              {convertedQuotations} converted from Quotations
            </span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-emerald-950 flex items-center justify-center text-emerald-400 border border-emerald-900">
            <ShoppingCart size={22} />
          </div>
        </div>

        <div className="bg-[#16213e] p-5 rounded-2xl border border-[#2a3a5c] shadow-lg flex items-center justify-between">
          <div>
            <span className="text-[10px] text-[#8892a4] block font-mono font-bold tracking-wider uppercase">TOTAL BOOKED REVENUE</span>
            <span className="text-2xl font-bold font-display text-white mt-1 block">
              ₹{(totalSalesOrdered).toLocaleString("en-IN")}
            </span>
            <span className="text-[11px] text-[#8892a4] mt-1 block">
              Total sales booking in ledger
            </span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-sky-950 flex items-center justify-center text-sky-400 border border-sky-900">
            <DollarSign size={22} />
          </div>
        </div>

        <div className="bg-[#16213e] p-5 rounded-2xl border border-[#2a3a5c] shadow-lg flex items-center justify-between">
          <div>
            <span className="text-[10px] text-[#8892a4] block font-mono font-bold tracking-wider uppercase">CONVERSION EFFICIENCY</span>
            <span className="text-2xl font-bold font-display text-violet-400 mt-1 block">
              {quotations.length > 0 ? Math.round((convertedQuotations / quotations.length) * 100) : 0}%
            </span>
            <span className="text-[11px] text-[#8892a4] mt-1 block">
              Quotations converted to SO
            </span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-violet-950 flex items-center justify-center text-violet-400 border border-violet-900">
            <CheckCircle2 size={22} />
          </div>
        </div>
      </div>

      {/* Sub-navigation & Header Controls */}
      <div className="bg-[#16213e] border border-[#2a3a5c] rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex space-x-1.5 bg-[#121c35] p-1 rounded-xl border border-[#2a3a5c]/80 w-full sm:w-auto">
          <button
            onClick={() => { setSubView("quotations"); setSelectedOrder(null); }}
            className={`flex-1 sm:flex-none px-4 py-2 rounded-lg text-xs font-semibold font-display flex items-center justify-center space-x-2 transition-all ${
              subView === "quotations" ? "bg-[#2563EB] text-white" : "text-[#8892a4] hover:text-[#e2e8f0]"
            }`}
          >
            <FileText size={14} />
            <span>Quotations Desk</span>
          </button>
          <button
            onClick={() => { setSubView("orders"); setSelectedQuotation(null); }}
            className={`flex-1 sm:flex-none px-4 py-2 rounded-lg text-xs font-semibold font-display flex items-center justify-center space-x-2 transition-all ${
              subView === "orders" ? "bg-[#2563EB] text-white" : "text-[#8892a4] hover:text-[#e2e8f0]"
            }`}
          >
            <ShoppingCart size={14} />
            <span>Sales Orders Book</span>
          </button>
        </div>

        <div className="flex items-center space-x-3 w-full sm:w-auto justify-end">
          <button
            onClick={() => {
              if (subView === "quotations") fetchQuotations();
              else fetchSalesOrders();
            }}
            className="p-2.5 rounded-lg bg-[#1a2744] hover:bg-[#20315a] border border-[#2a3a5c] text-[#8892a4] hover:text-white transition-colors"
            title="Refresh Ledger"
          >
            <RefreshCw size={14} className={loading ? "animate-spin" : ""} />
          </button>
          {subView === "quotations" && (
            <button
              onClick={() => setIsCreatingQuotation(true)}
              className="px-4 py-2 bg-[#2563EB] hover:bg-blue-600 active:bg-blue-700 text-white rounded-lg text-xs font-bold flex items-center space-x-2 shadow-lg hover:shadow-blue-900/30 transition-all cursor-pointer"
            >
              <Plus size={14} />
              <span>Generate Quotation</span>
            </button>
          )}
        </div>
      </div>

      {/* Main Studio View Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 2/3: Lists & Forms */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Create New Quotation Panel */}
          {isCreatingQuotation ? (
            <div className="bg-[#16213e] border border-[#2a3a5c] rounded-2xl overflow-hidden shadow-xl animate-in fade-in duration-200">
              <div className="bg-[#1c2a4f] border-b border-[#2a3a5c] px-6 py-4 flex items-center justify-between">
                <div>
                  <h3 className="font-display font-bold text-sm text-white">Generate Quotation Draft</h3>
                  <p className="text-[11px] text-[#8892a4]">Draft quotation with dual-mode item entry</p>
                </div>
                <button 
                  onClick={() => setIsCreatingQuotation(false)}
                  className="p-1 rounded bg-[#20315a] text-[#8892a4] hover:text-white transition-colors cursor-pointer"
                >
                  <X size={16} />
                </button>
              </div>

              <div className="p-6 space-y-6">
                {/* Header Fields */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-[#121c35] p-4 rounded-xl border border-[#2a3a5c]/50">
                  <div>
                    <label className="text-[10px] font-mono uppercase tracking-wider text-[#8892a4] block mb-1">Customer / Party Name *</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2.5 text-[#8892a4]"><User size={14} /></span>
                      <input
                        type="text"
                        value={editorCustomerName}
                        onChange={(e) => setEditorCustomerName(e.target.value)}
                        placeholder="Enter Client or Company Name"
                        className="w-full bg-[#16213e] border border-[#2a3a5c] rounded-lg pl-9 pr-4 py-2 text-xs text-white placeholder-[#8892a4] focus:outline-none focus:border-blue-500"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="text-[10px] font-mono uppercase tracking-wider text-[#8892a4] block mb-1">Workflow Status</label>
                    <div className="flex space-x-2">
                      <button
                        type="button"
                        onClick={() => setEditorStatus("Draft")}
                        className={`flex-1 py-2 rounded-lg text-xs font-semibold border transition-all ${
                          editorStatus === "Draft" 
                            ? "bg-[#2563EB] border-blue-500 text-white" 
                            : "bg-[#16213e] border-[#2a3a5c] text-[#8892a4] hover:text-white"
                        }`}
                      >
                        Keep Draft
                      </button>
                      <button
                        type="button"
                        onClick={() => setEditorStatus("Submitted")}
                        className={`flex-1 py-2 rounded-lg text-xs font-semibold border transition-all ${
                          editorStatus === "Submitted" 
                            ? "bg-amber-600 border-amber-500 text-white" 
                            : "bg-[#16213e] border-[#2a3a5c] text-[#8892a4] hover:text-white"
                        }`}
                      >
                        Submit Direct
                      </button>
                    </div>
                  </div>
                </div>

                {/* Entry Modes Tabs */}
                <div>
                  <div className="flex border-b border-[#2a3a5c] mb-4">
                    <button
                      type="button"
                      onClick={() => setEntryMode("manual")}
                      className={`px-4 py-2 text-xs font-bold font-display flex items-center space-x-2 border-b-2 transition-all cursor-pointer ${
                        entryMode === "manual" ? "border-blue-500 text-white" : "border-transparent text-[#8892a4] hover:text-white"
                      }`}
                    >
                      <Layers size={14} />
                      <span>Manual Scan / Resolve</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setEntryMode("matrix")}
                      className={`px-4 py-2 text-xs font-bold font-display flex items-center space-x-2 border-b-2 transition-all cursor-pointer ${
                        entryMode === "matrix" ? "border-blue-500 text-white" : "border-transparent text-[#8892a4] hover:text-white"
                      }`}
                    >
                      <Grid size={14} />
                      <span>Matrix Grid Entry (SMRITI Footwear/Apparel)</span>
                    </button>
                  </div>

                  {/* Manual Entry Form */}
                  {entryMode === "manual" && (
                    <div className="bg-[#121c35] p-4 rounded-xl border border-[#2a3a5c]/50 space-y-4">
                      <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
                        <div className="sm:col-span-6">
                          <label className="text-[9px] font-mono text-[#8892a4] block mb-1">SELECT VARIANT</label>
                          <select
                            value={selectedProduct}
                            onChange={(e) => setSelectedProduct(e.target.value)}
                            className="w-full bg-[#16213e] border border-[#2a3a5c] rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
                          >
                            <option value="">-- Choose Article Variant --</option>
                            {products.map(p => (
                              <option key={p.id} value={p.id}>
                                {p.name} ({p.color || "N/A"} - Size {p.size || "N/A"}) - ₹{p.price} [SMR-Barcode: {p.barcode}]
                              </option>
                            ))}
                          </select>
                        </div>
                        <div className="sm:col-span-3">
                          <label className="text-[9px] font-mono text-[#8892a4] block mb-1">QTY</label>
                          <input
                            type="number"
                            min="1"
                            value={manualQty}
                            onChange={(e) => setManualQty(Math.max(1, parseInt(e.target.value) || 1))}
                            className="w-full bg-[#16213e] border border-[#2a3a5c] rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-blue-500"
                          />
                        </div>
                        <div className="sm:col-span-3">
                          <label className="text-[9px] font-mono text-[#8892a4] block mb-1">GST TAX %</label>
                          <select
                            value={manualTax}
                            onChange={(e) => setManualTax(parseInt(e.target.value) || 18)}
                            className="w-full bg-[#16213e] border border-[#2a3a5c] rounded-lg px-2 py-1.5 text-xs text-white focus:outline-none focus:border-blue-500"
                          >
                            <option value="5">5% GST</option>
                            <option value="12">12% GST</option>
                            <option value="18">18% GST</option>
                            <option value="28">28% GST</option>
                          </select>
                        </div>
                      </div>
                      <div className="flex justify-end">
                        <button
                          type="button"
                          onClick={handleAddManualItem}
                          className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-bold transition-colors cursor-pointer"
                        >
                          Add Item Line
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Matrix Entry Grid Form */}
                  {entryMode === "matrix" && (
                    <div className="bg-[#121c35] p-4 rounded-xl border border-[#2a3a5c]/50 space-y-4">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                          <label className="text-[9px] font-mono text-[#8892a4] block mb-1">SELECT BASE ARTICLE</label>
                          <select
                            value={selectedBaseArticle}
                            onChange={(e) => {
                              setSelectedBaseArticle(e.target.value);
                              setSelectedBaseColor("");
                              setMatrixQuantities({});
                            }}
                            className="w-full bg-[#16213e] border border-[#2a3a5c] rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
                          >
                            <option value="">-- Choose Base Article --</option>
                            {baseArticles.map(art => (
                              <option key={art} value={art}>{art}</option>
                            ))}
                          </select>
                        </div>
                        <div>
                          <label className="text-[9px] font-mono text-[#8892a4] block mb-1">SELECT COLOR</label>
                          <select
                            value={selectedBaseColor}
                            onChange={(e) => {
                              setSelectedBaseColor(e.target.value);
                              setMatrixQuantities({});
                            }}
                            disabled={!selectedBaseArticle}
                            className="w-full bg-[#16213e] border border-[#2a3a5c] rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500 disabled:opacity-50"
                          >
                            <option value="">-- Choose Color --</option>
                            {availableColors.map(col => (
                              <option key={col} value={col}>{col}</option>
                            ))}
                          </select>
                        </div>
                      </div>

                      {selectedBaseArticle && selectedBaseColor && (
                        <div className="space-y-4 pt-2 border-t border-[#2a3a5c]/50">
                          <div className="bg-[#16213e] p-3.5 rounded-lg border border-[#2a3a5c]">
                            <h4 className="text-[10px] font-mono text-indigo-300 uppercase tracking-wider mb-3">VARIANT SIZE ALLOCATIONS MATRIX</h4>
                            
                            <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-5 gap-3">
                              {matrixVariants.map(variant => (
                                <div key={variant.id} className="bg-[#121c35] p-2 rounded border border-[#2a3a5c]/60 flex flex-col items-center">
                                  <span className="text-[10px] font-mono text-[#8892a4]">Size {variant.size || "OS"}</span>
                                  <span className="text-xs font-semibold text-white mt-0.5">₹{variant.price}</span>
                                  <span className="text-[9px] text-emerald-400 mt-0.5">Stock: {variant.stock}</span>
                                  <input
                                    type="number"
                                    min="0"
                                    value={matrixQuantities[variant.id] || ""}
                                    placeholder="0"
                                    onChange={(e) => {
                                      const val = Math.max(0, parseInt(e.target.value) || 0);
                                      setMatrixQuantities({
                                        ...matrixQuantities,
                                        [variant.id]: val
                                      });
                                    }}
                                    className="w-full text-center bg-[#16213e] border border-[#2a3a5c] rounded mt-2 py-1 text-xs text-white focus:outline-none focus:border-blue-500"
                                  />
                                </div>
                              ))}
                            </div>
                          </div>

                          <div className="flex justify-end">
                            <button
                              type="button"
                              onClick={handleAddMatrixItems}
                              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-bold transition-colors cursor-pointer"
                            >
                              Add Matrix Items to Draft
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* Current Draft Items Table */}
                <div className="space-y-2">
                  <h4 className="text-[10px] font-mono uppercase tracking-wider text-[#8892a4]">Draft Item Lines List</h4>
                  
                  {editorItems.length === 0 ? (
                    <div className="p-8 text-center bg-[#121c35] border border-dashed border-[#2a3a5c] rounded-xl text-[#8892a4] text-xs">
                      No items added yet. Choose manual or matrix entry above to build the quotation document lines.
                    </div>
                  ) : (
                    <div className="bg-[#121c35] border border-[#2a3a5c] rounded-xl overflow-hidden">
                      <table className="w-full text-left text-xs border-collapse">
                        <thead>
                          <tr className="bg-[#1c2a4f] text-[#8892a4] uppercase font-mono text-[9px] tracking-wider border-b border-[#2a3a5c]">
                            <th className="px-4 py-2.5">Article / Variant</th>
                            <th className="px-4 py-2.5">Color/Size</th>
                            <th className="px-4 py-2.5 text-right">Qty</th>
                            <th className="px-4 py-2.5 text-right">Price</th>
                            <th className="px-4 py-2.5 text-right">GST %</th>
                            <th className="px-4 py-2.5 text-right">Tax (₹)</th>
                            <th className="px-4 py-2.5 text-right">Total (₹)</th>
                            <th className="px-4 py-2.5 text-center">Action</th>
                          </tr>
                        </thead>
                        <tbody>
                          {editorItems.map((item, index) => {
                            const taxRate = item.taxRate || 18;
                            const baseTotal = item.quantity * item.price;
                            const taxAmount = (baseTotal * taxRate) / 100;
                            const lineTotal = baseTotal + taxAmount;

                            return (
                              <tr key={index} className="border-b border-[#2a3a5c]/40 hover:bg-[#16213e] text-white">
                                <td className="px-4 py-2">
                                  <div className="font-semibold">{item.name}</div>
                                  <div className="text-[10px] text-[#8892a4] font-mono">{item.code}</div>
                                </td>
                                <td className="px-4 py-2 font-mono">
                                  {item.color || "N/A"} / {item.size || "N/A"}
                                </td>
                                <td className="px-4 py-2 text-right font-mono font-semibold">
                                  {item.quantity}
                                </td>
                                <td className="px-4 py-2 text-right font-mono">
                                  ₹{item.price.toLocaleString("en-IN")}
                                </td>
                                <td className="px-4 py-2 text-right font-mono text-amber-400">
                                  {taxRate}%
                                </td>
                                <td className="px-4 py-2 text-right font-mono text-[#8892a4]">
                                  ₹{Math.round(taxAmount).toLocaleString("en-IN")}
                                </td>
                                <td className="px-4 py-2 text-right font-mono text-emerald-400 font-semibold">
                                  ₹{Math.round(lineTotal).toLocaleString("en-IN")}
                                </td>
                                <td className="px-4 py-2 text-center">
                                  <button
                                    type="button"
                                    onClick={() => handleRemoveDraftItem(index)}
                                    className="p-1 rounded text-rose-500 hover:bg-rose-950/50 transition-colors"
                                  >
                                    <Trash2 size={14} />
                                  </button>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>

                      {/* Summary Section */}
                      <div className="p-4 bg-[#1a2744] border-t border-[#2a3a5c] text-xs text-[#8892a4] flex flex-col sm:flex-row justify-between items-center gap-4">
                        <div className="text-[11px] leading-relaxed">
                          SMRITI tax engine automatically back-calculates and segregates SGST/CGST breakdown lines.
                        </div>
                        <div className="space-y-1 text-right w-full sm:w-auto">
                          <div>
                            Base Net Total: <span className="font-mono text-white">₹{editorItems.reduce((acc, item) => acc + (item.quantity * item.price), 0).toLocaleString("en-IN")}</span>
                          </div>
                          <div>
                            Taxes Consolidated: <span className="font-mono text-white">₹{editorItems.reduce((acc, item) => acc + ((item.quantity * item.price * (item.taxRate || 18)) / 100), 0).toFixed(1)}</span>
                          </div>
                          <div className="text-sm font-bold text-emerald-400">
                            Grand Quotation Total: ₹{editorItems.reduce((acc, item) => acc + (item.quantity * item.price * (1 + (item.taxRate || 18) / 100)), 0).toLocaleString("en-IN")}
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* Form Actions */}
                <div className="flex justify-end space-x-3 pt-4 border-t border-[#2a3a5c]/50">
                  <button
                    type="button"
                    onClick={() => {
                      setIsCreatingQuotation(false);
                      setEditorItems([]);
                    }}
                    className="px-4 py-2 rounded-lg bg-[#1a2744] hover:bg-[#20315a] border border-[#2a3a5c] text-[#8892a4] hover:text-white text-xs font-semibold transition-colors cursor-pointer"
                  >
                    Cancel Draft
                  </button>
                  <button
                    type="button"
                    onClick={handleSaveQuotation}
                    className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg text-xs shadow-lg transition-colors cursor-pointer"
                  >
                    Commit & Write Ledger
                  </button>
                </div>
              </div>
            </div>
          ) : (
            /* Standard Ledger Lists View */
            <div className="bg-[#16213e] border border-[#2a3a5c] rounded-2xl overflow-hidden shadow-lg">
              <div className="p-4 bg-[#1c2a4f] border-b border-[#2a3a5c] flex items-center justify-between">
                <span className="text-xs font-bold font-display uppercase tracking-wider text-white">
                  {subView === "quotations" ? "Quotations Registry" : "Sales Orders Registry"}
                </span>
                <span className="text-[10px] font-mono text-[#8892a4]">
                  {subView === "quotations" ? `${quotations.length} Active Records` : `${salesOrders.length} Confirmed Bookings`}
                </span>
              </div>

              {loading ? (
                <div className="p-16 flex flex-col items-center justify-center space-y-3">
                  <RefreshCw className="animate-spin text-blue-500" size={24} />
                  <span className="text-xs text-[#8892a4]">Syncing real-time ledger data...</span>
                </div>
              ) : subView === "quotations" ? (
                /* Quotations Registry Table */
                quotations.length === 0 ? (
                  <div className="p-16 text-center text-[#8892a4] text-xs">
                    No quotations found in SMRITI. Click "Generate Quotation" to create your first record.
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs border-collapse">
                      <thead>
                        <tr className="bg-[#121c35] text-[#8892a4] uppercase font-mono text-[9px] tracking-wider border-b border-[#2a3a5c]">
                          <th className="px-5 py-3">Quotation No</th>
                          <th className="px-5 py-3">Client Name</th>
                          <th className="px-5 py-3">Document Date</th>
                          <th className="px-5 py-3 text-right">Items Count</th>
                          <th className="px-5 py-3 text-right">Grand Total</th>
                          <th className="px-5 py-3 text-center">Status</th>
                          <th className="px-5 py-3 text-center">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {quotations.map(q => (
                          <tr 
                            key={q.id} 
                            onClick={() => setSelectedQuotation(q)}
                            className={`border-b border-[#2a3a5c]/40 hover:bg-[#1c2a4f]/50 cursor-pointer transition-colors ${
                              selectedQuotation?.id === q.id ? "bg-[#1c2a4f]" : ""
                            }`}
                          >
                            <td className="px-5 py-3 font-mono font-bold text-white flex items-center space-x-2">
                              <FileText size={13} className="text-[#8892a4]" />
                              <span>{q.quotationNo}</span>
                            </td>
                            <td className="px-5 py-3 text-white font-medium">{q.customerName}</td>
                            <td className="px-5 py-3 text-[#8892a4] font-mono">
                              {new Date(q.date).toLocaleDateString("en-IN", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })}
                            </td>
                            <td className="px-5 py-3 text-right font-mono text-[#8892a4]">
                              {q.items.reduce((acc, i) => acc + i.quantity, 0)} units
                            </td>
                            <td className="px-5 py-3 text-right font-mono font-semibold text-emerald-400">
                              ₹{q.grandTotal.toLocaleString("en-IN")}
                            </td>
                            <td className="px-5 py-3 text-center">
                              <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                                q.status === "Draft" ? "bg-[#1a2744] text-[#8892a4] border border-[#2a3a5c]" :
                                q.status === "Submitted" ? "bg-amber-950/80 text-amber-400 border border-amber-800" :
                                "bg-emerald-950/80 text-emerald-400 border border-emerald-800"
                              }`}>
                                {q.status}
                              </span>
                            </td>
                            <td className="px-5 py-3 text-center" onClick={(e) => e.stopPropagation()}>
                              <div className="flex items-center justify-center space-x-2">
                                <button
                                  onClick={() => setSelectedQuotation(q)}
                                  className="p-1 rounded hover:bg-[#1a2744] text-sky-400"
                                  title="View Quotation"
                                >
                                  <Eye size={14} />
                                </button>
                                {q.status === "Submitted" && (
                                  <button
                                    onClick={() => handleConvertQuotation(q.id)}
                                    className="p-1 rounded hover:bg-emerald-950 text-emerald-400"
                                    title="Convert to Sales Order"
                                  >
                                    <FileCheck size={14} />
                                  </button>
                                )}
                                {q.status === "Draft" && (
                                  <button
                                    onClick={() => handleDeleteQuotation(q.id)}
                                    className="p-1 rounded hover:bg-rose-950 text-rose-400"
                                    title="Delete Draft"
                                  >
                                    <Trash2 size={14} />
                                  </button>
                                )}
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )
              ) : (
                /* Sales Orders Book Registry */
                salesOrders.length === 0 ? (
                  <div className="p-16 text-center text-[#8892a4] text-xs">
                    No confirmed sales bookings found in SMRITI. Convert a submitted quotation or create an order.
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs border-collapse">
                      <thead>
                        <tr className="bg-[#121c35] text-[#8892a4] uppercase font-mono text-[9px] tracking-wider border-b border-[#2a3a5c]">
                          <th className="px-5 py-3">Order No</th>
                          <th className="px-5 py-3">Client Name</th>
                          <th className="px-5 py-3">Order Date</th>
                          <th className="px-5 py-3 text-right">Items Booking</th>
                          <th className="px-5 py-3 text-right">Booked Value</th>
                          <th className="px-5 py-3 text-center">Status</th>
                          <th className="px-5 py-3 text-center">Source QTN</th>
                        </tr>
                      </thead>
                      <tbody>
                        {salesOrders.map(so => (
                          <tr 
                            key={so.id} 
                            onClick={() => setSelectedOrder(so)}
                            className={`border-b border-[#2a3a5c]/40 hover:bg-[#1c2a4f]/50 cursor-pointer transition-colors ${
                              selectedOrder?.id === so.id ? "bg-[#1c2a4f]" : ""
                            }`}
                          >
                            <td className="px-5 py-3 font-mono font-bold text-white flex items-center space-x-2">
                              <ShoppingCart size={13} className="text-[#8892a4]" />
                              <span>{so.orderNo}</span>
                            </td>
                            <td className="px-5 py-3 text-white font-medium">{so.customerName}</td>
                            <td className="px-5 py-3 text-[#8892a4] font-mono">
                              {new Date(so.date).toLocaleDateString("en-IN", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })}
                            </td>
                            <td className="px-5 py-3 text-right font-mono text-[#8892a4]">
                              {so.items.reduce((acc, i) => acc + i.quantity, 0)} units
                            </td>
                            <td className="px-5 py-3 text-right font-mono font-semibold text-emerald-400">
                              ₹{so.grandTotal.toLocaleString("en-IN")}
                            </td>
                            <td className="px-5 py-3 text-center">
                              <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-emerald-950 text-emerald-400 border border-emerald-800">
                                {so.status}
                              </span>
                            </td>
                            <td className="px-5 py-3 text-center font-mono text-[#8892a4]">
                              {so.sourceQuotationId ? (
                                <span className="bg-indigo-950 text-indigo-300 border border-indigo-900 px-1.5 py-0.2 rounded text-[10px]">
                                  LINKED
                                </span>
                              ) : (
                                "DIRECT"
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )
              )}
            </div>
          )}
        </div>

        {/* Right 1/3: Context Details Drawer */}
        <div className="lg:col-span-1">
          
          {selectedQuotation ? (
            /* Selected Quotation Side Pane */
            <div className="bg-[#16213e] border border-[#2a3a5c] rounded-2xl p-5 space-y-6 shadow-xl sticky top-24">
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="text-[10px] bg-indigo-950 text-indigo-400 border border-indigo-900 rounded px-1.5 py-0.2 font-mono font-bold uppercase">QUOTATION</span>
                    <span className="text-xs text-[#8892a4] font-mono font-medium">#{selectedQuotation.id.slice(-5)}</span>
                  </div>
                  <h4 className="font-display font-bold text-base text-white mt-1.5">{selectedQuotation.quotationNo}</h4>
                  <p className="text-[11px] text-[#8892a4] mt-0.5">Assigned to: <span className="text-white font-medium">{selectedQuotation.customerName}</span></p>
                </div>
                <button
                  onClick={() => setSelectedQuotation(null)}
                  className="p-1 rounded bg-[#1a2744] text-[#8892a4] hover:text-white transition-colors cursor-pointer"
                >
                  <X size={14} />
                </button>
              </div>

              <div className="space-y-4 border-t border-b border-[#2a3a5c] py-4">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-[#8892a4] font-medium">Document Date</span>
                  <span className="text-white font-mono">{new Date(selectedQuotation.date).toLocaleDateString("en-IN")}</span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-[#8892a4] font-medium">Workflow Status</span>
                  <span className={`px-2 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider ${
                    selectedQuotation.status === "Draft" ? "bg-[#1a2744] text-[#8892a4] border border-[#2a3a5c]" :
                    selectedQuotation.status === "Submitted" ? "bg-amber-950/80 text-amber-400 border border-amber-800" :
                    "bg-emerald-950/80 text-emerald-400 border border-emerald-800"
                  }`}>
                    {selectedQuotation.status}
                  </span>
                </div>
                {selectedQuotation.salesOrderId && (
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-[#8892a4] font-medium">Sales Order Linked</span>
                    <span className="text-emerald-400 font-mono font-semibold">LINKED</span>
                  </div>
                )}
              </div>

              {/* Items Breakdown lines list inside side pane */}
              <div className="space-y-3">
                <span className="text-[10px] font-mono uppercase tracking-wider text-[#8892a4] block">DOCUMENT LINE ITEMS</span>
                <div className="max-h-[220px] overflow-y-auto space-y-2 pr-1.5">
                  {selectedQuotation.items.map((line, idx) => (
                    <div key={idx} className="bg-[#121c35] p-3 rounded-lg border border-[#2a3a5c]/60 flex justify-between items-start text-xs">
                      <div>
                        <div className="font-semibold text-white">{line.name}</div>
                        <div className="text-[10px] text-[#8892a4] font-mono mt-0.5">
                          {line.color || "N/A"} / {line.size || "N/A"} • Qty {line.quantity}
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-semibold text-white">₹{Math.round(line.totalAmount).toLocaleString("en-IN")}</div>
                        <div className="text-[9px] text-[#8892a4] mt-0.5 font-mono">₹{line.price} + {line.taxRate}% GST</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Totals Box */}
              <div className="bg-[#121c35] p-4 rounded-xl border border-[#2a3a5c] space-y-2">
                <div className="flex justify-between items-center text-xs text-[#8892a4]">
                  <span>Consolidated Taxes (GST)</span>
                  <span className="font-mono text-white">₹{selectedQuotation.taxTotal.toLocaleString("en-IN")}</span>
                </div>
                <div className="flex justify-between items-center text-xs font-bold text-white pt-2 border-t border-[#2a3a5c]/60">
                  <span>Grand Ledger Total</span>
                  <span className="text-emerald-400 font-mono text-sm">₹{selectedQuotation.grandTotal.toLocaleString("en-IN")}</span>
                </div>
              </div>

              {/* Conversion Controls */}
              {selectedQuotation.status === "Submitted" && (
                <button
                  onClick={() => handleConvertQuotation(selectedQuotation.id)}
                  className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-lg hover:shadow-emerald-900/30 flex items-center justify-center space-x-2.5 transition-all cursor-pointer"
                >
                  <FileCheck size={16} />
                  <span>Convert to Sales Order</span>
                </button>
              )}

              {selectedQuotation.status === "Draft" && (
                <div className="space-y-2">
                  <button
                    onClick={async () => {
                      try {
                        const res = await fetch(`/api/sales/quotations/${selectedQuotation.id}`, {
                          method: "PUT",
                          headers: { "Content-Type": "application/json" },
                          body: JSON.stringify({ status: "Submitted" })
                        });
                        if (res.ok) {
                          onNotification("Success", "Quotation submitted and locked.", "success");
                          fetchQuotations();
                          setSelectedQuotation(null);
                        }
                      } catch (e) {
                        onNotification("Error", "Failed to submit.", "error");
                      }
                    }}
                    className="w-full py-2.5 bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs rounded-xl transition-all cursor-pointer"
                  >
                    Lock & Submit Quotation
                  </button>
                  <button
                    onClick={() => handleDeleteQuotation(selectedQuotation.id)}
                    className="w-full py-2.5 bg-rose-950/40 hover:bg-rose-900 text-rose-200 border border-rose-900/80 font-semibold text-xs rounded-xl transition-all cursor-pointer"
                  >
                    Delete Draft
                  </button>
                </div>
              )}
            </div>
          ) : selectedOrder ? (
            /* Selected Sales Order Side Pane */
            <div className="bg-[#16213e] border border-[#2a3a5c] rounded-2xl p-5 space-y-6 shadow-xl sticky top-24">
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="text-[10px] bg-emerald-950 text-emerald-400 border border-emerald-900 rounded px-1.5 py-0.2 font-mono font-bold uppercase">SALES ORDER</span>
                    <span className="text-xs text-[#8892a4] font-mono font-medium">#{selectedOrder.id.slice(-5)}</span>
                  </div>
                  <h4 className="font-display font-bold text-base text-white mt-1.5">{selectedOrder.orderNo}</h4>
                  <p className="text-[11px] text-[#8892a4] mt-0.5">Customer Name: <span className="text-white font-medium">{selectedOrder.customerName}</span></p>
                </div>
                <button
                  onClick={() => setSelectedOrder(null)}
                  className="p-1 rounded bg-[#1a2744] text-[#8892a4] hover:text-white transition-colors cursor-pointer"
                >
                  <X size={14} />
                </button>
              </div>

              <div className="space-y-4 border-t border-b border-[#2a3a5c] py-4">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-[#8892a4] font-medium">Booking Date</span>
                  <span className="text-white font-mono">{new Date(selectedOrder.date).toLocaleDateString("en-IN")}</span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-[#8892a4] font-medium">Workflow Status</span>
                  <span className="px-2.5 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider bg-emerald-950 text-emerald-400 border border-emerald-800">
                    {selectedOrder.status}
                  </span>
                </div>
                {selectedOrder.sourceQuotationId && (
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-[#8892a4] font-medium">Source Document</span>
                    <span className="text-sky-400 font-mono font-semibold">CONVERTED QTN</span>
                  </div>
                )}
              </div>

              {/* Items Breakdown list */}
              <div className="space-y-3">
                <span className="text-[10px] font-mono uppercase tracking-wider text-[#8892a4] block">COMMITTED BOOKINGS</span>
                <div className="max-h-[220px] overflow-y-auto space-y-2 pr-1.5">
                  {selectedOrder.items.map((line, idx) => (
                    <div key={idx} className="bg-[#121c35] p-3 rounded-lg border border-[#2a3a5c]/60 flex justify-between items-start text-xs">
                      <div>
                        <div className="font-semibold text-white">{line.name}</div>
                        <div className="text-[10px] text-[#8892a4] font-mono mt-0.5">
                          {line.color || "N/A"} / {line.size || "N/A"} • Qty {line.quantity}
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-semibold text-white">₹{Math.round(line.totalAmount).toLocaleString("en-IN")}</div>
                        <div className="text-[9px] text-[#8892a4] mt-0.5 font-mono">₹{line.price} + {line.taxRate}% GST</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Totals Box */}
              <div className="bg-[#121c35] p-4 rounded-xl border border-[#2a3a5c] space-y-2">
                <div className="flex justify-between items-center text-xs text-[#8892a4]">
                  <span>Consolidated Taxes (GST)</span>
                  <span className="font-mono text-white">₹{selectedOrder.taxTotal.toLocaleString("en-IN")}</span>
                </div>
                <div className="flex justify-between items-center text-xs font-bold text-white pt-2 border-t border-[#2a3a5c]/60">
                  <span>Grand Booking Value</span>
                  <span className="text-emerald-400 font-mono text-sm">₹{selectedOrder.grandTotal.toLocaleString("en-IN")}</span>
                </div>
              </div>

              <div className="bg-indigo-950/40 p-3 rounded-xl border border-indigo-900/60 text-[10px] text-indigo-200 leading-relaxed flex items-start space-x-2">
                <AlertCircle size={14} className="mt-0.5 text-indigo-400 shrink-0" />
                <p>This sales order is committed to inventory logic. Quantities are reserved and waiting for shipment dispatch protocols (Phase 2).</p>
              </div>
            </div>
          ) : (
            /* Empty Right Pane State */
            <div className="bg-[#16213e] border border-[#2a3a5c] rounded-2xl p-8 text-center space-y-3 text-[#8892a4] sticky top-24">
              <div className="w-12 h-12 rounded-full bg-[#121c35] flex items-center justify-center text-[#8892a4] mx-auto">
                <FileText size={20} />
              </div>
              <h4 className="font-display font-bold text-xs text-white uppercase tracking-wider">Detail Inspection Desk</h4>
              <p className="text-[11px] leading-relaxed">Select any quotation or sales order from the registry list to load its real-time tax breakdown, workflow status transitions, and committed items.</p>
            </div>
          )}

        </div>

      </div>

    </div>
  );
};
