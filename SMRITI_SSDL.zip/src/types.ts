export interface ProductBatch {
  batchNo: string;
  mfgDate: string;
  expiryDate: string;
  stock: number;
}

export interface Product {
  id: string;
  code: string;
  name: string;
  price: number;
  stock: number;
  category: string;
  barcode: string;
  secondaryBarcodes?: string[]; // Added for secondary barcodes support
  brand?: string; // Added for brand support in template tokens
  color?: string;
  size?: string;
  mrp?: number;
  gstPercentage?: number;
  styleCode?: string;
  // Extensible Attribute fields
  attributes?: Record<string, string>; // e.g. { "Sole Type": "Rubber", "Color": "Navy", "Size": "M" }
  pricingMode?: "Fixed" | "Weight-based" | "Negotiated" | "Service";
  trackingMode?: "Standard" | "Batch" | "Serial" | "No-stock";
  variantTemplateId?: string; // Reference to VariantTemplate
  weightGrams?: number; // Used for Weight-based pricing
  batches?: ProductBatch[]; // Used for Batch tracking
  serialNumbers?: string[]; // Used for Serial tracking
}

export interface AttributeDefinition {
  id: string;
  name: string; // Name (e.g., Sole Type, Material, Screen Size, Molecule, Pack Size)
  label: string; // Human-friendly label (e.g., Sole Type, Material)
  dataType: "text" | "number" | "date" | "select";
  isVariantDimension: boolean; // If true, contributes to variant SKU and grid structure
  isMandatory: boolean;
  validValues: string[]; // Set of allowed values, e.g., ["Rubber", "PU", "PVC"]
}

export interface AttributeGroup {
  id: string;
  name: string; // Name (e.g., "Footwear Standard", "Apparel Basic", "Hardware Fasteners")
  attributeIds: string[]; // Ordered attribute IDs
  gridColumnAttributeId?: string; // E.g. "Size"
  gridRowAttributeId?: string; // E.g. "Color"
}

export interface VariantTemplate {
  id: string;
  styleCode: string; // Parent template style code prefix
  name: string; // Base name of the product line
  brand: string;
  category: string;
  hsnCode: string;
  basePrice: number;
  baseMrp: number;
  gstPercentage: number;
  attributeGroupId: string;
  pricingMode: "Fixed" | "Weight-based" | "Negotiated" | "Service";
  trackingMode: "Standard" | "Batch" | "Serial" | "No-stock";
}

export interface CategoryAttributeGroupMapping {
  category: string;
  attributeGroupId: string;
}

export interface POSProfile {
  id: string;
  name: string;
  cashier: string;
  warehouse: string;
  isLocked: boolean;
  isArchived: boolean;
}

export interface Shift {
  id: string;
  profileId: string;
  openedAt: string;
  closedAt: string | null;
  openingBalance: number;
  closingBalance: number | null;
  salesCount: number;
  salesValue: number;
  status: "Open" | "Closed" | "Locked";
}

export interface FieldInfo {
  id: string;
  fieldName: string;
  label: string;
  fieldType: string;
  docType: string;
  isStable: boolean;
  description: string;
  sampleValue: string;
}

export interface Formula {
  id: string;
  name: string;
  category: string;
  expression: string;
  meaning: string;
  workedExample: string;
  dataSources: string[];
  interpretation: {
    critical: string;
    monitor: string;
    healthy: string;
  };
  recommendedAction: string;
  value: string;
}

export interface PSVParty {
  id: string;
  name: string;
  location: string;
  stockCount: number;
  sellThrough: number; // percentage
  weeksOfCover: number;
  capitalLocked: number; // in INR
  status: "Healthy" | "Monitor" | "Critical";
  history: { date: string; sales: number; stock: number }[];
}

export interface Bill {
  id: string;
  timestamp: string;
  items: { product: Product; quantity: number }[];
  total: number;
  customerName?: string;
}

export interface SalesItemLine {
  productId: string;
  code: string;
  name: string;
  color?: string;
  size?: string;
  quantity: number;
  price: number;
  taxRate: number; // e.g. 18 for 18% GST
  taxAmount: number;
  totalAmount: number;
}

export interface Quotation {
  id: string;
  quotationNo: string;
  date: string;
  customerName: string;
  items: SalesItemLine[];
  taxTotal: number;
  grandTotal: number;
  status: "Draft" | "Submitted" | "Converted";
  salesOrderId?: string;
}

export interface SalesOrder {
  id: string;
  orderNo: string;
  date: string;
  customerName: string;
  items: SalesItemLine[];
  taxTotal: number;
  grandTotal: number;
  status: "Draft" | "Confirmed" | "Shipped" | "Cancelled";
  sourceQuotationId?: string;
}

export interface PrintTemplate {
  id: string;
  title: string;
  labelSize: "50x25" | "50x30" | "75x50" | "100x50";
  printerLanguage: "ZPL" | "TSPL";
  printerFamily: "ZPL" | "TSPL";
  version?: string;
  isActive: boolean;
  isDefaultSize: boolean;
  rawPRN: string;
  fieldMappings?: { token: string; source_field: string }[];
}

export interface PrintProfile {
  id: string;
  name: string;
  templateId: string;
  printerIP: string;
  printerPort: number;
  dpi: number;
  copies: number;
  labelSize: string;
  isDefault: boolean;
}


