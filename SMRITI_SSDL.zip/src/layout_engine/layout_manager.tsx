import React, { useState, useEffect } from "react";
import { 
  Sliders, Search, Layout, Cpu, Sun, Moon, Info, CheckCircle, 
  Settings, HelpCircle, Monitor, ShieldCheck, HelpCircle as HelpIcon, ArrowLeftRight
} from "lucide-react";
import { useLayoutEngine, DockPosition } from "./layout_store.js";
import { DockManager } from "./dock_manager.js";

interface LayoutManagerProps {
  activeTab: string;
  onTabSelect: (id: string) => void;
  children: React.ReactNode;
}

export const LayoutManager: React.FC<LayoutManagerProps> = ({
  activeTab,
  onTabSelect,
  children
}) => {
  const { preferences, setLayout, toggleSidebar } = useLayoutEngine();
  const [searchTerm, setSearchTerm] = useState("");
  const [systemClock, setSystemClock] = useState(new Date());
  const [showLayoutConfig, setShowLayoutConfig] = useState(false);

  // Sync Clock
  useEffect(() => {
    const interval = setInterval(() => setSystemClock(new Date()), 1000);
    return () => clearInterval(interval);
  }, []);

  const handlePositionChange = (pos: DockPosition) => {
    setLayout(pos);
    setShowLayoutConfig(false);
  };

  return (
    <div className="h-screen w-screen flex flex-col overflow-hidden bg-[#1A2B5C] text-[#e2e8f0] font-sans antialiased select-none">
      
      {/* 1. FIXED APPLICATION HEADER (Satisfies Application Header requirement) */}
      <header className="bg-[#16213e] border-b border-[#2a3a5c] px-6 h-[72px] flex-shrink-0 flex items-center justify-between z-30 shadow-md">
        
        {/* Brand Logo & Info */}
        <div className="flex items-center space-x-3.5">
          <div className="w-10 h-10 rounded-xl bg-[#2563EB] flex items-center justify-center font-bold text-lg font-display text-white border border-[#2a3a5c] shadow-lg animate-pulse">
            S
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h1 className="font-display font-bold text-base tracking-wide text-white">SMRITI Retail OS</h1>
              <span className="text-[9px] bg-[#1a2744] text-[#8892a4] border border-[#2a3a5c] rounded px-1.5 py-0.2 font-mono font-bold">LANE 01</span>
              <span className="text-[9px] bg-indigo-950 text-indigo-400 border border-indigo-900 rounded px-1.5 py-0.2 font-mono font-bold">SRLE v1.0</span>
            </div>
            <p className="text-[10px] text-[#8892a4]">Enterprise Experience & Operational Intelligence Desk</p>
          </div>
        </div>

        {/* Global Control Center & Settings */}
        <div className="flex items-center space-x-6">
          
          {/* Layout Quick Configuration Toggler */}
          <div className="relative">
            <button
              onClick={() => setShowLayoutConfig(!showLayoutConfig)}
              className="px-3 py-1.5 rounded-lg bg-[#1a2744] hover:bg-[#20315a] border border-[#2a3a5c] text-xs font-bold font-display text-blue-400 flex items-center space-x-2 cursor-pointer transition-colors"
            >
              <Layout size={13} />
              <span>Dock Position ({preferences.position})</span>
            </button>

            {showLayoutConfig && (
              <>
                <div 
                  className="fixed inset-0 z-30" 
                  onClick={() => setShowLayoutConfig(false)} 
                />
                <div className="absolute right-0 mt-2 w-56 rounded-xl bg-[#121c35] border border-[#2a3a5c] shadow-2xl p-4 space-y-3 z-40 animate-in fade-in slide-in-from-top-2 duration-150 text-left">
                  <span className="text-[10px] font-mono text-[#8892a4] font-bold uppercase tracking-wider block">Dock Layout Options</span>
                  <div className="grid grid-cols-2 gap-2">
                    {(["left", "right", "top", "bottom"] as DockPosition[]).map(pos => (
                      <button
                        key={`dropdown-pos-${pos}`}
                        onClick={() => handlePositionChange(pos)}
                        className={`py-2 text-[10px] font-mono font-bold uppercase rounded-lg border transition-colors ${
                          preferences.position === pos 
                            ? "bg-blue-600 border-blue-500 text-white" 
                            : "bg-[#16213e] border-[#2a3a5c] text-[#8892a4] hover:text-white"
                        }`}
                      >
                        {pos} Dock
                      </button>
                    ))}
                  </div>
                  <div className="h-px bg-[#2a3a5c]/50 my-1" />
                  <button
                    onClick={() => { toggleSidebar(); setShowLayoutConfig(false); }}
                    className="w-full text-left py-1 text-xs font-medium text-[#8892a4] hover:text-white flex items-center space-x-1.5"
                  >
                    <ArrowLeftRight size={12} />
                    <span>Expand/Collapse Sidebar</span>
                  </button>
                </div>
              </>
            )}
          </div>

          {/* System Clock */}
          <div className="text-right hidden md:block border-l border-[#2a3a5c] pl-4">
            <span className="text-[9px] text-[#8892a4] block font-mono">SYSTEM SYNCHRONIZED</span>
            <span className="font-mono text-xs text-white font-medium">
              {systemClock.toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })} • {systemClock.toLocaleTimeString()}
            </span>
          </div>

        </div>
      </header>

      {/* 2. DOCK MANAGER & VIEWPORT SHELL (Only the workspace inside the DockManager scrolls) */}
      <DockManager 
        activeTab={activeTab}
        onTabSelect={onTabSelect}
        searchTerm={searchTerm}
        onSearchChange={setSearchTerm}
      >
        {children}
      </DockManager>

    </div>
  );
};
