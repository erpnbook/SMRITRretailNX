import React, { useRef, useState, useEffect } from "react";
import { useLayoutEngine } from "./layout_store.js";
import { useResponsiveLayout } from "./responsive_manager.js";
import { NavigationRenderer } from "./navigation_renderer.js";
import { SmritiScrollArea } from "../components/SmritiScrollArea.tsx";

interface DockManagerProps {
  activeTab: string;
  onTabSelect: (id: string) => void;
  children: React.ReactNode;
  searchTerm: string;
  onSearchChange: (val: string) => void;
}

export const DockManager: React.FC<DockManagerProps> = ({
  activeTab,
  onTabSelect,
  children,
  searchTerm,
  onSearchChange
}) => {
  const { preferences, setSidebarWidth } = useLayoutEngine();
  const { effectivePosition } = useResponsiveLayout(preferences.position);
  
  const containerRef = useRef<HTMLDivElement>(null);
  const [isResizing, setIsResizing] = useState(false);
  const [localWidth, setLocalWidth] = useState(preferences.sidebarWidth);

  // Synchronize local state with store preferences
  useEffect(() => {
    setLocalWidth(preferences.sidebarWidth);
  }, [preferences.sidebarWidth]);

  // Drag-to-resize handlers
  const startResize = (e: React.MouseEvent) => {
    e.preventDefault();
    setIsResizing(true);
  };

  useEffect(() => {
    if (!isResizing) return;

    const handleMouseMove = (e: MouseEvent) => {
      if (!containerRef.current) return;
      const rect = containerRef.current.getBoundingClientRect();
      
      let newWidth = preferences.sidebarWidth;
      if (effectivePosition === "left") {
        newWidth = e.clientX - rect.left;
      } else if (effectivePosition === "right") {
        newWidth = rect.right - e.clientX;
      }

      // Constrain sidebar width between 180px and 480px
      const clamped = Math.max(180, Math.min(480, newWidth));
      setLocalWidth(clamped);
    };

    const handleMouseUp = () => {
      setIsResizing(false);
      setSidebarWidth(localWidth);
      // Dispatch resize event to force canvas / chart components redraw
      window.dispatchEvent(new Event("resize"));
    };

    window.addEventListener("mousemove", handleMouseMove);
    window.addEventListener("mouseup", handleMouseUp);

    return () => {
      window.removeEventListener("mousemove", handleMouseMove);
      window.removeEventListener("mouseup", handleMouseUp);
    };
  }, [isResizing, effectivePosition, localWidth, preferences.sidebarWidth, setSidebarWidth]);

  // Determine current width styled
  const isCollapsed = preferences.collapsed || preferences.iconOnly;
  const currentWidth = isCollapsed ? 72 : localWidth;

  // Render Left Dock Layout
  const renderLeftDockLayout = () => {
    return (
      <div ref={containerRef} className="flex-1 flex overflow-hidden relative">
        {/* Navigation Panel */}
        <div 
          style={{ width: `${currentWidth}px` }} 
          className="h-full flex-shrink-0 transition-all duration-200 ease-in-out select-none relative z-10"
        >
          <NavigationRenderer 
            activeTab={activeTab} 
            onTabSelect={onTabSelect} 
            searchTerm={searchTerm}
            onSearchChange={onSearchChange}
          />
          
          {/* Resize handle (only if not collapsed) */}
          {!isCollapsed && (
            <div 
              onMouseDown={startResize}
              className="absolute top-0 right-0 w-1.5 h-full cursor-col-resize hover:bg-blue-600/50 hover:w-2 active:bg-blue-500 transition-colors z-20"
            />
          )}
        </div>

        {/* Workspace content */}
        <SmritiScrollArea className="flex-1 bg-[#1A2B5C] select-text h-full relative" fadeColorClass="from-[#1A2B5C]">
          <div className="p-6">
            {children}
          </div>
        </SmritiScrollArea>
      </div>
    );
  };

  // Render Right Dock Layout
  const renderRightDockLayout = () => {
    return (
      <div ref={containerRef} className="flex-1 flex overflow-hidden relative">
        {/* Workspace content (first) */}
        <SmritiScrollArea className="flex-1 bg-[#1A2B5C] select-text h-full relative" fadeColorClass="from-[#1A2B5C]">
          <div className="p-6">
            {children}
          </div>
        </SmritiScrollArea>

        {/* Navigation Panel (second) */}
        <div 
          style={{ width: `${currentWidth}px` }} 
          className="h-full flex-shrink-0 transition-all duration-200 ease-in-out select-none relative z-10"
        >
          {/* Resize handle (only if not collapsed) */}
          {!isCollapsed && (
            <div 
              onMouseDown={startResize}
              className="absolute top-0 left-0 w-1.5 h-full cursor-col-resize hover:bg-blue-600/50 hover:w-2 active:bg-blue-500 transition-colors z-20"
            />
          )}

          <NavigationRenderer 
            activeTab={activeTab} 
            onTabSelect={onTabSelect} 
            searchTerm={searchTerm}
            onSearchChange={onSearchChange}
          />
        </div>
      </div>
    );
  };

  // Render Top Dock Layout
  const renderTopDockLayout = () => {
    return (
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Navigation Panel */}
        <NavigationRenderer 
          activeTab={activeTab} 
          onTabSelect={onTabSelect} 
          searchTerm={searchTerm}
          onSearchChange={onSearchChange}
        />
        
        {/* Workspace Content */}
        <SmritiScrollArea className="flex-1 bg-[#1A2B5C] select-text h-full relative" fadeColorClass="from-[#1A2B5C]">
          <div className="p-6">
            {children}
          </div>
        </SmritiScrollArea>
      </div>
    );
  };

  // Render Bottom Dock Layout
  const renderBottomDockLayout = () => {
    return (
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Workspace Content */}
        <SmritiScrollArea className="flex-1 bg-[#1A2B5C] select-text h-full relative" fadeColorClass="from-[#1A2B5C]">
          <div className="p-6">
            {children}
          </div>
        </SmritiScrollArea>

        {/* Navigation Panel */}
        <NavigationRenderer 
          activeTab={activeTab} 
          onTabSelect={onTabSelect} 
          searchTerm={searchTerm}
          onSearchChange={onSearchChange}
        />
      </div>
    );
  };

  // Return specific position renderers
  switch (effectivePosition) {
    case "right":
      return renderRightDockLayout();
    case "top":
      return renderTopDockLayout();
    case "bottom":
      return renderBottomDockLayout();
    default:
      return renderLeftDockLayout();
  }
};
