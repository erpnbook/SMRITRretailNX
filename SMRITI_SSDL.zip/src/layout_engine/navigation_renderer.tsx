import React, { useState } from "react";
import { 
  Star, Clock, ChevronDown, ChevronRight, MoreHorizontal, 
  Settings, Layers, SlidersHorizontal, Search, Sparkles, Check, 
  HelpCircle, ShieldCheck, Heart, Grid, Menu, X, ArrowLeftRight
} from "lucide-react";
import { useLayoutEngine, WorkspaceConfig, DockPosition } from "./layout_store.js";
import { SmritiScrollArea } from "../components/SmritiScrollArea.tsx";

interface NavigationRendererProps {
  activeTab: string;
  onTabSelect: (id: string) => void;
  searchTerm: string;
  onSearchChange: (val: string) => void;
}

export const NavigationRenderer: React.FC<NavigationRendererProps> = ({
  activeTab,
  onTabSelect,
  searchTerm,
  onSearchChange
}) => {
  const {
    preferences,
    recentlyUsed,
    registeredWorkspaces,
    toggleFavorite,
    toggleGroupCollapse,
    setLayout,
    toggleSidebar,
    addToRecentlyUsed
  } = useLayoutEngine();

  const [showMoreBottomMenu, setShowMoreBottomMenu] = useState(false);
  const [activeDropdownGroup, setActiveDropdownGroup] = useState<string | null>(null);

  const handleItemClick = (id: string) => {
    onTabSelect(id);
    addToRecentlyUsed(id);
    setShowMoreBottomMenu(false);
    setActiveDropdownGroup(null);
  };

  // Group workspaces by category
  const categories = Array.from(new Set(registeredWorkspaces.map(w => w.category)));

  // Filter workspaces by search term
  const filteredWorkspaces = registeredWorkspaces.filter(w => 
    w.label.toLowerCase().includes(searchTerm.toLowerCase()) || 
    w.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const isFavorited = (id: string) => preferences.favorites.includes(id);

  // Render Material Symbols Or fall back safely
  const renderIcon = (iconName: string, className = "text-xl") => {
    return <span className={`material-symbols-outlined ${className}`}>{iconName}</span>;
  };

  // 1. RENDER LEFT/RIGHT DOCK SIDEBAR NAVIGATION
  const renderSidebarNav = () => {
    const isCollapsed = preferences.collapsed || preferences.iconOnly;

    return (
      <div className="flex flex-col h-full bg-[#16213e] select-none text-sm border-r border-[#2a3a5c]">
        {/* Workspace Quick Search (Satisfies Global Search & Workspace Toolbar requirements) */}
        {!isCollapsed && (
          <div className="p-3 border-b border-[#2a3a5c]/60">
            <div className="relative">
              <span className="absolute left-2.5 top-2.5 text-[#8892a4]">
                <Search size={14} />
              </span>
              <input
                type="text"
                placeholder="Quick Workspace Search..."
                value={searchTerm}
                onChange={(e) => onSearchChange(e.target.value)}
                className="w-full bg-[#121c35] text-white border border-[#2a3a5c] rounded-lg pl-8 pr-3 py-1.5 text-xs focus:outline-none focus:border-blue-500 placeholder-[#8892a4]"
              />
              {searchTerm && (
                <button 
                  onClick={() => onSearchChange("")} 
                  className="absolute right-2.5 top-2.5 text-[#8892a4] hover:text-white"
                >
                  <X size={12} />
                </button>
              )}
            </div>
          </div>
        )}

        {/* Navigation Content Area */}
        <SmritiScrollArea className="flex-1" fadeColorClass="from-[#16213e]">
          <div className="p-3 space-y-4">
          
          {/* Favorites Section (if not collapsed and favorites exist) */}
          {!isCollapsed && preferences.favorites.length > 0 && (
            <div className="space-y-1 animate-in fade-in duration-300">
              <span className="text-[10px] font-mono text-amber-400 font-bold tracking-wider uppercase px-2 flex items-center space-x-1">
                <Star size={10} className="fill-amber-400 text-amber-400" />
                <span>Pinned Favorites</span>
              </span>
              <div className="space-y-0.5">
                {registeredWorkspaces
                  .filter(w => isFavorited(w.id))
                  .map(w => (
                    <div
                      key={`fav-${w.id}`}
                      onClick={() => handleItemClick(w.id)}
                      className={`w-full text-left px-3 py-2 rounded-lg flex items-center justify-between group transition-all cursor-pointer ${
                        activeTab === w.id 
                          ? "bg-[#2563EB]/20 border border-[#2563EB]/40 text-blue-400 font-medium" 
                          : "text-[#8892a4] hover:bg-[#1a2744] hover:text-white border border-transparent"
                      }`}
                    >
                      <div className="flex items-center space-x-2.5">
                        {renderIcon(w.icon, `text-lg ${activeTab === w.id ? "text-blue-400" : "text-[#8892a4]"}`)}
                        <span className="text-xs font-display">{w.label}</span>
                      </div>
                      <button 
                        onClick={(e) => { e.stopPropagation(); toggleFavorite(w.id); }}
                        className="opacity-0 group-hover:opacity-100 transition-opacity text-amber-400 hover:scale-110"
                      >
                        <Star size={12} className="fill-amber-400" />
                      </button>
                    </div>
                  ))}
              </div>
            </div>
          )}

          {/* Categorized Workspace Menu */}
          <div className="space-y-3">
            {categories.map(cat => {
              const catWorkspaces = filteredWorkspaces.filter(w => w.category === cat);
              if (catWorkspaces.length === 0) return null;

              const isGroupCollapsed = preferences.collapsedGroups.includes(cat);

              return (
                <div key={cat} className="space-y-1">
                  {/* Category Header */}
                  {!isCollapsed ? (
                    <button
                      onClick={() => toggleGroupCollapse(cat)}
                      className="w-full text-left px-2 py-1 flex items-center justify-between text-[10px] font-mono text-[#8892a4] font-bold tracking-wider uppercase hover:text-white"
                    >
                      <span>{cat}</span>
                      {isGroupCollapsed ? <ChevronRight size={12} /> : <ChevronDown size={12} />}
                    </button>
                  ) : (
                    <div className="h-px bg-[#2a3a5c]/50 my-2" />
                  )}

                  {/* Category Menu Items */}
                  {(!isGroupCollapsed || isCollapsed) && (
                    <div className="space-y-0.5 animate-in fade-in duration-200">
                      {catWorkspaces.map(w => {
                        const isSel = activeTab === w.id;
                        return (
                          <div
                            key={w.id}
                            onClick={() => handleItemClick(w.id)}
                            title={isCollapsed ? w.label : undefined}
                            className={`w-full text-left px-3 py-2 rounded-lg flex items-center justify-between group transition-all border cursor-pointer ${
                              isSel 
                                ? "bg-blue-600 border-blue-500 text-white font-semibold shadow-lg shadow-blue-950/20" 
                                : "text-[#8892a4] hover:bg-[#1a2744] hover:text-white border-transparent"
                            }`}
                          >
                            <div className="flex items-center space-x-2.5">
                              {renderIcon(w.icon, `text-lg ${isSel ? "text-white" : "text-[#8892a4] group-hover:text-white"}`)}
                              {!isCollapsed && <span className="text-xs font-display">{w.label}</span>}
                            </div>
                            
                            {!isCollapsed && (
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  toggleFavorite(w.id);
                                }}
                                className={`transition-opacity ${isFavorited(w.id) ? "opacity-100 text-amber-400" : "opacity-0 group-hover:opacity-100 text-[#8892a4] hover:text-amber-400"}`}
                              >
                                <Star size={11} className={isFavorited(w.id) ? "fill-amber-400" : ""} />
                              </button>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Recently Used (if not collapsed) */}
          {!isCollapsed && recentlyUsed.length > 0 && (
            <div className="pt-2 border-t border-[#2a3a5c]/30 space-y-1 animate-in fade-in duration-300">
              <span className="text-[10px] font-mono text-[#8892a4] font-bold tracking-wider uppercase px-2 flex items-center space-x-1">
                <Clock size={10} />
                <span>Recently Opened</span>
              </span>
              <div className="space-y-0.5">
                {recentlyUsed
                  .map(id => registeredWorkspaces.find(w => w.id === id))
                  .filter((w): w is WorkspaceConfig => !!w)
                  .map(w => (
                    <button
                      key={`recent-${w.id}`}
                      onClick={() => handleItemClick(w.id)}
                      className={`w-full text-left px-3 py-1.5 rounded-md flex items-center space-x-2.5 text-xs transition-colors ${
                        activeTab === w.id 
                          ? "text-blue-400 font-medium bg-[#1a2744]/40" 
                          : "text-[#8892a4] hover:text-white hover:bg-[#1a2744]/20"
                      }`}
                    >
                      {renderIcon(w.icon, "text-sm text-[#8892a4]")}
                      <span className="truncate">{w.label}</span>
                    </button>
                  ))}
              </div>
            </div>
          )}

          {/* Layout Controller Toolbar (Satisfies Runtime positioning adjustment) */}
          {!isCollapsed && (
            <div className="pt-3 border-t border-[#2a3a5c]/30 space-y-2">
              <span className="text-[10px] font-mono text-[#8892a4] font-bold tracking-wider uppercase px-2 flex items-center space-x-1">
                <SlidersHorizontal size={10} />
                <span>Layout Position</span>
              </span>
              <div className="grid grid-cols-4 gap-1 px-1">
                {(["left", "right", "top", "bottom"] as DockPosition[]).map(pos => (
                  <button
                    key={pos}
                    onClick={() => setLayout(pos)}
                    className={`py-1 text-[9px] font-mono font-bold uppercase rounded border transition-colors ${
                      preferences.position === pos 
                        ? "bg-blue-600 border-blue-500 text-white" 
                        : "bg-[#121c35] border-[#2a3a5c] text-[#8892a4] hover:text-white"
                    }`}
                  >
                    {pos}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* SMRITI Desk Blocking warning card */}
          {!isCollapsed && (
            <div className="p-3 bg-[#1a2744] bg-opacity-40 rounded-xl border border-[#2a3a5c]/60 text-[10px] text-[#8892a4] leading-relaxed space-y-1 mx-1 mt-3">
              <div className="font-bold text-white uppercase tracking-wider font-display text-[9px] flex items-center space-x-1">
                <span className="material-symbols-outlined text-xs text-rose-500">security</span>
                <span>SMRITI Desk Blocking</span>
              </div>
              <p>ERP Desk accesses are locked down. Desk access strictly restricted to secure SMRITI interfaces (Rule 7).</p>
            </div>
          )}

          </div>
        </SmritiScrollArea>

        {/* Collapse Toggle Trigger */}
        <div className="p-3 border-t border-[#2a3a5c]/60 flex items-center justify-between">
          <button
            onClick={toggleSidebar}
            className="flex items-center space-x-2 text-xs font-mono font-bold text-[#8892a4] hover:text-white transition-colors cursor-pointer"
          >
            <ArrowLeftRight size={13} />
            {!isCollapsed && <span>Toggle Dock Width</span>}
          </button>
          
          {isCollapsed && (
            <button 
              onClick={() => setLayout("top")} 
              className="text-[#8892a4] hover:text-white" 
              title="Switch to Top Menu"
            >
              <SlidersHorizontal size={14} />
            </button>
          )}
        </div>
      </div>
    );
  };

  // 2. RENDER TOP DOCK HORIZONTAL BAR NAVIGATION (Mega Menu / Dropdowns)
  const renderTopNav = () => {
    return (
      <div className="bg-[#16213e] border-b border-[#2a3a5c] flex items-center justify-between px-6 py-2 select-none relative z-20">
        
        {/* Horizontal Links with Dropdowns */}
        <div className="flex items-center space-x-4">
          {categories.map(cat => {
            const catWorkspaces = filteredWorkspaces.filter(w => w.category === cat);
            if (catWorkspaces.length === 0) return null;

            const isOpen = activeDropdownGroup === cat;

            return (
              <div key={cat} className="relative">
                <button
                  onClick={() => setActiveDropdownGroup(isOpen ? null : cat)}
                  className={`px-3 py-1.5 text-xs font-display font-medium rounded-lg flex items-center space-x-1 cursor-pointer transition-colors ${
                    isOpen || catWorkspaces.some(w => w.id === activeTab)
                      ? "bg-blue-600/10 text-blue-400 border border-blue-500/20" 
                      : "text-[#8892a4] hover:text-white hover:bg-[#1a2744]"
                  }`}
                >
                  <span>{cat}</span>
                  <ChevronDown size={12} className={`transform transition-transform ${isOpen ? "rotate-180" : ""}`} />
                </button>

                {/* Dropdown Menu Container */}
                {isOpen && (
                  <>
                    <div 
                      className="fixed inset-0 z-30" 
                      onClick={() => setActiveDropdownGroup(null)} 
                    />
                    <div className="absolute left-0 mt-2 w-56 rounded-xl bg-[#121c35] border border-[#2a3a5c] shadow-2xl p-2 space-y-1 z-40 animate-in fade-in slide-in-from-top-2 duration-150">
                      <div className="px-2.5 py-1 text-[9px] font-mono text-[#8892a4] font-bold uppercase tracking-wider border-b border-[#2a3a5c]/40 mb-1">
                        {cat} Modules
                      </div>
                      {catWorkspaces.map(w => (
                        <button
                          key={w.id}
                          onClick={() => handleItemClick(w.id)}
                          className={`w-full text-left px-2.5 py-1.5 rounded-lg flex items-center justify-between transition-all ${
                            activeTab === w.id 
                              ? "bg-blue-600 text-white font-medium shadow-md shadow-blue-950/20" 
                              : "text-[#8892a4] hover:bg-[#1a2744] hover:text-white"
                          }`}
                        >
                          <div className="flex items-center space-x-2">
                            {renderIcon(w.icon, "text-base")}
                            <span className="text-xs font-display">{w.label}</span>
                          </div>
                          {isFavorited(w.id) && <Star size={10} className="fill-amber-400 text-amber-400" />}
                        </button>
                      ))}
                    </div>
                  </>
                )}
              </div>
            );
          })}

          {/* Quick search inside Top Menu */}
          <div className="relative max-w-xs ml-4">
            <span className="absolute left-2.5 top-2 text-[#8892a4]"><Search size={12} /></span>
            <input
              type="text"
              placeholder="Search workspaces..."
              value={searchTerm}
              onChange={(e) => onSearchChange(e.target.value)}
              className="bg-[#121c35] text-white border border-[#2a3a5c] rounded-lg pl-8 pr-2 py-1 text-xs focus:outline-none focus:border-blue-500 placeholder-[#8892a4]"
            />
          </div>
        </div>

        {/* Pin shortcuts & Layout position buttons */}
        <div className="flex items-center space-x-4">
          {/* Pinned shortcuts */}
          <div className="hidden xl:flex items-center space-x-1.5 text-xs">
            <span className="text-[10px] font-mono text-[#8892a4] font-bold tracking-wider uppercase">PINNED:</span>
            {registeredWorkspaces
              .filter(w => isFavorited(w.id))
              .slice(0, 4)
              .map(w => (
                <button
                  key={`top-fav-${w.id}`}
                  onClick={() => handleItemClick(w.id)}
                  className={`px-2.5 py-1 rounded-md text-xs font-medium flex items-center space-x-1 transition-all ${
                    activeTab === w.id 
                      ? "bg-amber-500/20 text-amber-400 border border-amber-500/30 font-bold" 
                      : "text-[#8892a4] hover:text-white hover:bg-[#1a2744]"
                  }`}
                >
                  {renderIcon(w.icon, "text-xs")}
                  <span>{w.label}</span>
                </button>
              ))}
          </div>

          {/* Dock layout switch panel */}
          <div className="flex items-center space-x-1 border-l border-[#2a3a5c] pl-4">
            <span className="text-[9px] font-mono text-[#8892a4] font-bold mr-1.5">DOCK:</span>
            {(["left", "right", "top", "bottom"] as DockPosition[]).map(pos => (
              <button
                key={pos}
                onClick={() => setLayout(pos)}
                className={`px-2 py-1 text-[9px] font-mono font-bold uppercase rounded border transition-colors ${
                  preferences.position === pos 
                    ? "bg-blue-600 border-blue-500 text-white" 
                    : "bg-[#121c35] border-[#2a3a5c] text-[#8892a4] hover:text-white"
                }`}
              >
                {pos}
              </button>
            ))}
          </div>
        </div>
      </div>
    );
  };

  // 3. RENDER BOTTOM DOCK NAVIGATION (Optimized for Mobile / Touch / Tablet)
  const renderBottomNav = () => {
    // Show 4 core items + a More button
    const coreItems = [
      { id: "dashboard", label: "Dashboard", icon: "dashboard" },
      { id: "pos", label: "POS Billing", icon: "point_of_sale" },
      { id: "sales", label: "Sales", icon: "receipt_long" },
      { id: "item-master", label: "Items", icon: "inventory_2" }
    ];

    return (
      <div className="bg-[#16213e] border-t border-[#2a3a5c] h-16 w-full flex items-center justify-around px-2 py-1 select-none sticky bottom-0 z-30">
        {coreItems.map(item => {
          const isSel = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => handleItemClick(item.id)}
              className={`flex-1 py-1 flex flex-col items-center justify-center space-y-1 transition-all ${
                isSel ? "text-blue-400 font-bold" : "text-[#8892a4] hover:text-white"
              }`}
            >
              {renderIcon(item.icon, `text-xl ${isSel ? "text-blue-400 scale-110" : ""}`)}
              <span className="text-[10px] font-display truncate">{item.label}</span>
            </button>
          );
        })}

        {/* More Options Menu button */}
        <button
          onClick={() => setShowMoreBottomMenu(true)}
          className={`flex-1 py-1 flex flex-col items-center justify-center space-y-1 text-[#8892a4] hover:text-white`}
        >
          <Menu size={20} />
          <span className="text-[10px] font-display">More Modules</span>
        </button>

        {/* Mobile/Touch More Drawer Backdrop Overlay */}
        {showMoreBottomMenu && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex flex-col justify-end">
            <div className="absolute inset-0" onClick={() => setShowMoreBottomMenu(false)} />
            
            {/* Slide-up drawer */}
            <div className="relative bg-[#121c35] border-t border-[#2a3a5c] rounded-t-2xl max-h-[85vh] overflow-y-auto p-5 space-y-6 z-50 animate-in slide-in-from-bottom duration-250">
              <div className="flex items-center justify-between border-b border-[#2a3a5c] pb-3">
                <div>
                  <h4 className="font-display font-bold text-sm text-white">SMRITI Navigation Ledger</h4>
                  <p className="text-[10px] text-[#8892a4]">All operational suites and customization parameters</p>
                </div>
                <button 
                  onClick={() => setShowMoreBottomMenu(false)} 
                  className="p-1 rounded-full bg-[#16213e] text-[#8892a4] hover:text-white"
                >
                  <X size={18} />
                </button>
              </div>

              {/* Categorized list in Mobile Drawer */}
              <div className="space-y-4">
                {categories.map(cat => {
                  const items = registeredWorkspaces.filter(w => w.category === cat);
                  return (
                    <div key={`bottom-drawer-cat-${cat}`} className="space-y-2">
                      <span className="text-[10px] font-mono text-blue-400 font-bold uppercase tracking-wider block">
                        {cat}
                      </span>
                      <div className="grid grid-cols-2 gap-2">
                        {items.map(w => (
                          <button
                            key={`bottom-drawer-item-${w.id}`}
                            onClick={() => handleItemClick(w.id)}
                            className={`p-3 rounded-xl border flex flex-col items-start space-y-2 transition-all ${
                              activeTab === w.id 
                                ? "bg-blue-600 border-blue-500 text-white font-bold" 
                                : "bg-[#16213e] border-[#2a3a5c] text-[#8892a4] hover:text-white"
                            }`}
                          >
                            {renderIcon(w.icon, `text-xl ${activeTab === w.id ? "text-white" : "text-[#8892a4]"}`)}
                            <span className="text-xs font-display font-medium text-left">{w.label}</span>
                          </button>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Layout controls inside mobile menu */}
              <div className="pt-4 border-t border-[#2a3a5c]/60 space-y-2.5">
                <span className="text-[10px] font-mono text-[#8892a4] font-bold uppercase tracking-wider block">
                  Workspace Layout Docking
                </span>
                <div className="grid grid-cols-4 gap-2">
                  {(["left", "right", "top", "bottom"] as DockPosition[]).map(pos => (
                    <button
                      key={`bot-pos-${pos}`}
                      onClick={() => { setLayout(pos); setShowMoreBottomMenu(false); }}
                      className={`py-2 text-[10px] font-mono font-bold uppercase rounded-lg border transition-colors ${
                        preferences.position === pos 
                          ? "bg-blue-600 border-blue-500 text-white" 
                          : "bg-[#16213e] border-[#2a3a5c] text-[#8892a4] hover:text-white"
                      }`}
                    >
                      {pos}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  };

  // Render the matching layout
  if (preferences.position === "top") return renderTopNav();
  if (preferences.position === "bottom") return renderBottomNav();
  return renderSidebarNav();
};
